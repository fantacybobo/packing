import { test, expect } from '@playwright/test'

/**
 * 进入编辑页必须带上图对象标识：编辑的不是「那张图」，而是某个对象的某个版本。
 * mock 后端会真的挡住不带标识的请求（见 src/mocks/handlers.ts 的 scopeError）。
 * 取值与 src/mocks/db.ts 的 DEMO_OBJECT 一致。
 */
const OBJECT = 'object_id=KG-2026-0001&object_version=v3'

/** 图谱页的深链。query 是除标识外的其余参数，例如 'nodes=N01&hop=1' */
const graphUrl = (query = '') => `/graph?${OBJECT}${query ? `&${query}` : ''}`

/** 根路径的深链，用来验重定向 */
const rootUrl = (query = '') => `/?${OBJECT}${query ? `&${query}` : ''}`

test('搜索 → 出图 → 打开文档抽屉', async ({ page }) => {
  await page.goto(rootUrl())

  // 首屏是空态引导
  await expect(page.getByText('在上方输入关键字选择节点，点「搜索」开始')).toBeVisible()

  // 搜索按钮限定在搜索工具栏容器内。按容器取控件比按名字全局取更稳：
  // 页面上随时可能多出一个同名控件，而这一条要验的始终是工具条上的那个。
  const searchBar = page.locator('.search-bar')
  const searchButton = searchBar.getByRole('button', { name: '搜索' })

  // 候选一为空时搜索不可点
  await expect(searchButton).toBeDisabled()

  // 选中候选一
  await page.getByLabel('候选节点 1').click()
  await page.keyboard.type('TASK')
  await page.getByText('TASK PROCESSOR').first().click()

  await searchButton.click()

  // 图渲染出来。
  // 用 heading 角色定位画布上的节点标题：候选框下拉的选项文案里也含
  // 「TASK PROCESSOR」，antd 下拉关闭后其 DOM 节点会带动画延迟卸载，
  // 用 getByText 有时会撞上残留节点造成 strict-mode 冲突；节点标题是唯一的 <h3>。
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  // URL 是单向的：页面里的搜索只重新拉数据，不把参数写回地址栏。
  await expect(page).toHaveURL(graphUrl())

  // 打开文档抽屉
  await page.getByRole('button', { name: '节点文档' }).first().click()
  await expect(page.getByText('NODE DOCUMENT')).toBeVisible()
  await expect(page.getByText(/任务队列可读/)).toBeVisible()
})

test('拖出连线只打开边弹窗，取消后不会留下边', async ({ page }) => {
  // 这条保证（服务器确认前不建边）在 jsdom 里无法测：React Flow 的连线要真实拖拽。
  // Playwright 能真拖，所以放在 E2E 层。
  await page.goto(rootUrl('nodes=N01&hop=2'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const edgeCountBefore = await page.locator('.react-flow__edge').count()

  // 从 N01 第一行状态的右侧 source handle 拖到 N04 第一行状态的左侧 target handle
  // React Flow 12 把节点 id 放在 data-id 上（实测确认，不是 data-nodeid）
  const source = page.locator('.react-flow__node[data-id="N01"] .react-flow__handle-right').first()
  const target = page.locator('.react-flow__node[data-id="N04"] .react-flow__handle-left').first()

  const sourceBox = await source.boundingBox()
  const targetBox = await target.boundingBox()
  if (!sourceBox || !targetBox) throw new Error('handle bounding box not found')
  const sourcePoint = { x: sourceBox.x + sourceBox.width / 2, y: sourceBox.y + sourceBox.height / 2 }
  const targetPoint = { x: targetBox.x + targetBox.width / 2, y: targetBox.y + targetBox.height / 2 }

  // dragTo 只发 down/move/up 三步；React Flow 的连线需要中间移动帧才会触发，
  // 所以这里手动分步，途中经过一个中点，模拟真实拖拽轨迹。
  await page.mouse.move(sourcePoint.x, sourcePoint.y)
  await page.mouse.down()
  await page.mouse.move(
    (sourcePoint.x + targetPoint.x) / 2,
    (sourcePoint.y + targetPoint.y) / 2,
    { steps: 5 },
  )
  await page.mouse.move(targetPoint.x, targetPoint.y, { steps: 5 })
  await page.mouse.up()

  // 弹窗出现，但边还没建
  await expect(page.getByText('NEW EDGE')).toBeVisible()
  expect(await page.locator('.react-flow__edge').count()).toBe(edgeCountBefore)

  // 关掉弹窗后依然没有新边
  // antd Modal 自带的右上角关闭图标在 zhCN locale 下无障碍名也是「关闭」，
  // 与弹窗底部的显式按钮同名，所以限定在 footer 容器内取按钮，避免 strict-mode 命中两个元素。
  await page.locator('.panel__footer').getByRole('button', { name: '关闭' }).click()
  await expect(page.getByText('NEW EDGE')).not.toBeVisible()
  expect(await page.locator('.react-flow__edge').count()).toBe(edgeCountBefore)
})

test('深链直接进入即可还原图', async ({ page }) => {
  await page.goto(rootUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()
  await expect(page.getByRole('heading', { name: 'DECISION GATE' })).toBeVisible()
  await expect(page.getByLabel('跳数')).toHaveValue('1')
})

test('换一批节点后画布重新取景，不会把更大的图裁在视口外', async ({ page }) => {
  // <ReactFlow fitView /> 只在初始化时生效一次，所以「第二次搜索没有重新取景」
  // 在 jsdom 里测不出来：那里没有真实的尺寸测量，viewport 的 transform 恒为初始值。
  await page.goto(rootUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const viewport = page.locator('.react-flow__viewport')
  await expect(viewport).toHaveAttribute('style', /scale/)
  const before = await viewport.getAttribute('style')

  // hop 调到 6：子图从 2 个节点变成 4 个，必须重新 fit
  const hop = page.getByLabel('跳数')
  await hop.fill('6')
  await page.locator('.search-bar').getByRole('button', { name: '搜索' }).click()

  await expect(page.getByRole('heading', { name: 'COMPLETE' })).toBeVisible()
  await expect.poll(() => viewport.getAttribute('style')).not.toBe(before)
})



test('裸根路径落到总览页', async ({ page }) => {
  await page.goto('/')

  await expect(page).toHaveURL('/overview')
  await expect(page.getByRole('complementary', { name: '分类' })).toBeVisible()
})

test('带查询串的根路径仍然去 /graph，并原样带上深链的查询串', async ({ page }) => {
  // 进入编辑页的深链形如 /?object_id=..&object_version=..&nodes=..&hop=..。
  // 一律送去总览的话这些链接会静默失效：页面正常打开，只是打开的是另一个地方。
  await page.goto(rootUrl('nodes=N01&hop=1'))

  await expect(page).toHaveURL(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()
  await expect(page.getByLabel('跳数')).toHaveValue('1')
})

test('顶栏导航：回得了总览，且图谱编辑页不摆在导航里', async ({ page }) => {
  await page.goto(graphUrl())

  const nav = page.getByRole('navigation', { name: '主导航' })

  // 顶栏进去的地址不带图对象标识，那样的编辑页搜什么都会被后端拒。
  // 所以导航里没有图谱页 —— 进编辑页只有总览列表上的「编辑」一条路。
  await expect(nav.getByRole('link')).toHaveCount(1)
  await expect(nav.getByRole('link', { name: '图谱' })).toHaveCount(0)

  // 键盘可达：导航是链接不是按钮，Tab 得到、回车能开
  await nav.getByRole('link', { name: '总览' }).focus()
  await expect(nav.getByRole('link', { name: '总览' })).toBeFocused()
  await page.keyboard.press('Enter')
  await expect(page).toHaveURL('/overview')
  await expect(nav.getByRole('link', { name: '总览' })).toHaveAttribute('aria-current', 'page')

  // 浏览器后退，说明用的是真实的历史记录而不是内部状态切换
  await page.goBack()
  await expect(page).toHaveURL(graphUrl())
})

test('顶栏品牌区的分割线与总览页侧边栏的右边框对齐成一条竖线', async ({ page }) => {
  await page.goto('/overview')

  // 两处共用 --sidebar-width（见 tokens.css）。各写一份 232px 的话，
  // 这条本该贯通的竖线迟早会错开一两像素 —— 而那只有量出来才看得见。
  const brand = await page.locator('.top-bar__brand').boundingBox()
  const side = await page.locator('.overview__side').boundingBox()

  expect(brand).not.toBeNull()
  expect(side).not.toBeNull()
  expect(brand!.x).toBe(side!.x)
  expect(brand!.x + brand!.width).toBe(side!.x + side!.width)
})

test('侧边栏只属于总览页，不会跟到图谱页上', async ({ page }) => {
  await page.goto('/overview')
  await expect(page.getByRole('complementary', { name: '分类' })).toBeVisible()

  await page.goto(graphUrl())
  await expect(page.getByRole('complementary', { name: '分类' })).toHaveCount(0)
})

test('分类树：父节点只展开，叶子才刷新右侧列表，全程不动 URL', async ({ page }) => {
  await page.goto('/overview')

  const side = page.getByRole('complementary', { name: '分类' })

  // 还没选分类时列表区明说要先选 —— 和「这个分类下没有图谱」是两句不同的话
  await expect(page.getByText(/从左侧选择一个分类/)).toBeVisible()

  // 父节点：只展开，右边纹丝不动
  await side.getByRole('button', { name: '运营' }).click()
  await expect(side.getByRole('button', { name: '运营' })).toHaveAttribute('aria-expanded', 'true')
  await expect(page.getByText(/从左侧选择一个分类/)).toBeVisible()
  await expect(page.getByRole('table')).toHaveCount(0)

  // 叶子：这才出列表
  await side.getByRole('button', { name: '履约' }).click()
  await expect(page.getByRole('table').getByRole('row')).toHaveCount(4) // 表头 + 3 行
  await expect(side.getByRole('button', { name: '履约' })).toHaveAttribute('aria-current', 'true')

  // 整个过程地址一个字符都没变。这是产品定的：选分类是页内状态，不进 URL
  await expect(page).toHaveURL('/overview')
})

test('总览页的「编修」在新标签页打开，并带上这一行的图对象标识', async ({ page, context }) => {
  await page.goto('/overview')

  const side = page.getByRole('complementary', { name: '分类' })
  await side.getByRole('button', { name: '运营' }).click()
  await side.getByRole('button', { name: '履约' }).click()
  await expect(page.getByRole('table')).toBeVisible()

  const [opened] = await Promise.all([
    context.waitForEvent('page'),
    page.getByRole('link', { name: /^编修 供应链履约图谱 v3/ }).click(),
  ])

  await expect(opened).toHaveURL(graphUrl())
  await expect(opened.getByText('在上方输入关键字选择节点，点「搜索」开始')).toBeVisible()

  // 总览那个标签页原封不动，选中的分类还在 —— 这是「不写 URL」能成立的前提
  await expect(page).toHaveURL('/overview')
  await expect(side.getByRole('button', { name: '履约' })).toHaveAttribute('aria-current', 'true')
})

test('连线终点画出箭头，方向看得出来', async ({ page }) => {
  // markerEnd 生成的是 <defs> 里的 SVG marker，jsdom 不做 SVG 渲染，
  // 「箭头真的存在于 DOM 里并被边引用」只能在真浏览器里验。
  await page.goto(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const edgePath = page.locator('.react-flow__edge-path').first()
  const markerUrl = await edgePath.getAttribute('marker-end')

  // React Flow 把 marker 的参数编进 id 里，形如
  //   url('#1__color=#51687e&height=18&type=arrowclosed&width=18')
  // 引号可有可无，所以这里按正则取 id，不按固定长度切。
  const markerId = markerUrl?.match(/^url\(['"]?#(.+?)['"]?\)$/)?.[1]
  expect(markerId, `marker-end 没有指向任何 marker：${markerUrl}`).toBeTruthy()

  expect(markerId).toContain('type=arrowclosed')

  // 引用得指向真实存在的 marker，否则只是一个悬空的 url(#...)，画面上什么都没有。
  // 用属性选择器而不是 #id：这个 id 里有 # 和 &，拼进 CSS 选择器会解析失败。
  const marker = page.locator(`marker[id="${markerId}"]`)
  await expect(marker).toHaveCount(1)

  // 箭头与连线必须同色。这个颜色天然存在两份副本：连线的 stroke 来自 CSS 的
  // var(--color-edge)，而箭头是 React Flow 生成进 <defs> 的 marker、取不到 CSS class，
  // 只能由 theme.ts 的 EDGE_COLOR 从 JS 传进去。比对浏览器算出的实际颜色，
  // 而不是两个源文件里的字面量 —— 后者只能证明字符串相等，证明不了画面上是一个颜色。
  const lineColor = await edgePath.evaluate(el => getComputedStyle(el).stroke)
  const arrowColor = await marker.locator('polyline, path').first()
    .evaluate(el => getComputedStyle(el).fill)
  expect(arrowColor, '箭头颜色应与连线一致').toBe(lineColor)
})

test('两个候选节点各自按绿、蓝高亮，选中时被黄色盖掉', async ({ page }) => {
  await page.goto(graphUrl('nodes=N01,N04&hop=3'))
  await expect(page.getByRole('heading', { name: 'COMPLETE' })).toBeVisible()

  const cardOf = (title: string) =>
    page.locator('.status-node').filter({ has: page.getByRole('heading', { name: title }) })

  // 断言浏览器实际算出来的边框色，而不是内联的 --node-highlight 变量：
  // 变量写对了但 CSS 没消费它时，用户依然看不到任何颜色。
  await expect(cardOf('TASK PROCESSOR')).toHaveCSS('border-color', 'rgb(74, 222, 128)')  // 候选 1：绿
  await expect(cardOf('COMPLETE')).toHaveCSS('border-color', 'rgb(96, 165, 250)')        // 候选 2：蓝
  await expect(cardOf('DECISION GATE')).toHaveCSS('border-color', 'rgb(35, 52, 66)')     // 非候选：中性

  // 标题文字必须和边框同色，否则「这张卡属于哪个候选」会有两个互相矛盾的信号
  const titleOf = (t: string) => cardOf(t).locator('.status-node__title')
  await expect(titleOf('TASK PROCESSOR')).toHaveCSS('color', 'rgb(74, 222, 128)')
  await expect(titleOf('COMPLETE')).toHaveCSS('color', 'rgb(96, 165, 250)')
  await expect(titleOf('DECISION GATE')).toHaveCSS('color', 'rgb(233, 241, 248)')  // 非候选：常规文字色

  // 选中候选 1：黄色必须盖掉它原本的绿，边框和标题一起变
  await cardOf('TASK PROCESSOR').locator('.status-node__head').click({ position: { x: 60, y: 10 } })
  await expect(cardOf('TASK PROCESSOR')).toHaveCSS('border-color', 'rgb(251, 191, 36)')
  await expect(titleOf('TASK PROCESSOR')).toHaveCSS('color', 'rgb(251, 191, 36)')
  // 没被选中的候选 2 保持蓝色，说明黄色只作用在选中项上，不是把全场都刷成黄的
  await expect(cardOf('COMPLETE')).toHaveCSS('border-color', 'rgb(96, 165, 250)')
  await expect(titleOf('COMPLETE')).toHaveCSS('color', 'rgb(96, 165, 250)')
})

test('卡片的真实高度构成与 layout.ts 的常量一致', async ({ page }) => {
  // dagre 用 estimateNodeHeight 给节点定位，而那个公式是照着 graph.css 手写的一串常量。
  // 两边一旦漂移，jsdom 完全测不出来 —— 那里没有真实的盒模型计算。
  // 这条用例就是当初那个「每行多算 1px」的 bug 唯一能被自动抓到的地方：
  // 全局 box-sizing: border-box 让 height: 36px 已经含了 border-top，不额外占高度。
  await page.goto(graphUrl('nodes=N01,N04&hop=3'))
  await expect(page.getByRole('heading', { name: 'COMPLETE' })).toBeVisible()

  // offsetHeight 不受 React Flow 视口缩放影响，getBoundingClientRect 会
  const geometry = await page.evaluate(() =>
    [...document.querySelectorAll('.status-node')].map(card => {
      const el = card as HTMLElement
      return {
        title: card.querySelector('.status-node__title')!.textContent,
        rowCount: card.querySelectorAll('.status-node__row').length,
        cardH: el.offsetHeight,
        headH: (card.querySelector('.status-node__head') as HTMLElement).offsetHeight,
        rowsH: (card.querySelector('.status-node__rows') as HTMLElement).offsetHeight,
      }
    }),
  )
  expect(geometry.length).toBeGreaterThan(0)

  const ROW_HEIGHT = 36   // layout.ts 的同名常量
  const CARD_BORDER_Y = 2 // layout.ts 的同名常量

  for (const g of geometry) {
    // 状态区高度恰好是行数乘行高：没有行间距、没有容器内边距、分隔线不额外占高度。
    // 这同时守着「状态行通栏」这个前提 —— 容器一旦被加回 padding，这里立刻会红。
    expect(g.rowsH, `${g.title} 的状态区高度`).toBe(g.rowCount * ROW_HEIGHT)
    // 整卡 = 上下外框 + 标题区 + 状态区，中间没有任何别的东西
    expect(g.cardH, `${g.title} 的整卡高度`).toBe(CARD_BORDER_Y + g.headH + g.rowsH)
  }
})

test('URL 缺少图对象标识时，接口被拒且界面明说原因', async ({ page }) => {
  // 编辑的是「某个对象的某个版本」下的图。标识漏带时后端若宽容地按默认版本
  // 回一份数据，界面看起来完全正常，用户却在改另一个版本 —— 所以这必须是硬错误。
  // 这条用例走的是完整链路：URL → useGraphObjectRefSync → api/client → mock handler。
  await page.goto('/graph?nodes=N01&hop=1')

  await expect(page.getByText(/缺少图对象标识/)).toBeVisible()
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toHaveCount(0)
})

test('边标签靠近箭头，但不压在箭头上', async ({ page }) => {
  // 标签位置是真实的盒模型测量，jsdom 完全测不出来：那里没有布局。
  // 摆法是代码里的内置常量（lib/edgeLabel.ts 的 EDGE_LABEL_PLACEMENT），界面上没有开关。
  await page.goto(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'DECISION GATE' })).toBeVisible()

  const label = page.locator('.priority-edge__label').first()
  const sourceCard = page.locator('.react-flow__node[data-id="N01"]')
  const targetCard = page.locator('.react-flow__node[data-id="N02"]')

  const centreX = async (locator: typeof label) => {
    const box = await locator.boundingBox()
    if (!box) throw new Error('bounding box not found')
    return box.x + box.width / 2
  }

  // 标签落在靠近箭头（也就是 to 侧节点）的那一半 —— 挤在中点时交叉的边会互相遮挡
  const midpoint = ((await centreX(sourceCard)) + (await centreX(targetCard))) / 2
  expect(await centreX(label), '标签应偏向 to 侧').toBeGreaterThan(midpoint)

  // 但不能压在箭头上：右边缘要停在 to 侧卡片的左边缘之前
  const labelBox = (await label.boundingBox())!
  const targetBox = (await targetCard.boundingBox())!
  expect(labelBox.x + labelBox.width, '标签右缘不应越过 to 侧卡片').toBeLessThanOrEqual(targetBox.x)
})

test('搜索下拉只展示 entity 与 metrics，不摆 node id', async ({ page }) => {
  await page.goto(graphUrl())

  await page.getByLabel('候选节点 1').click()
  await page.keyboard.type('TASK')

  const row = page.locator('.search-bar__option').first()
  await expect(row).toContainText('TASK PROCESSOR')
  await expect(row).toContainText('从队列拉取待处理任务')
  // node_id 在画布卡片上从不显示，下拉里也不该出现
  await expect(row).not.toContainText(/N\d{2}/)
})

test('编辑边的弹窗说的是实体名，不是 node / status id', async ({ page }) => {
  await page.goto(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'DECISION GATE' })).toBeVisible()

  // 点标签就等于点这条边：标签压在连线上，不接管点击的话它只会把点击吃掉
  await page.locator('.priority-edge__label').first().click()

  const dialog = page.getByRole('dialog')
  await expect(dialog.getByText('EDIT EDGE')).toBeVisible()
  // 卡片上从不显示 id，弹窗里摆 N01-ST01 → N02-ST01 用户对不上任何东西
  await expect(dialog.getByText('TASK PROCESSOR')).toBeVisible()
  await expect(dialog.getByText('DECISION GATE')).toBeVisible()
  await expect(dialog.getByText(/N01-ST01/)).toHaveCount(0)
})

test('删除节点与删除状态的二次确认用同一句关于边的文案', async ({ page }) => {
  await page.goto(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const card = page.locator('.react-flow__node[data-id="N01"]')
  await card.getByRole('button', { name: '编辑节点' }).click()
  await page.getByRole('button', { name: '删除节点' }).click()

  // 两个破坏性操作共用同一句写死的文案。刻意不报数 —— 画布只加载了本次查询范围内的
  // 连线，据此算出来的边数是错的（默认数据 + hop=1 就能撞上：说 3 条，实际删 8 条）。
  await expect(page.getByText('此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。')).toBeVisible()

  // 取消不该动任何东西
  await page.getByRole('button', { name: '再想想' }).click()
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()
})

test('删除状态时，保存前明说会连带删边，但不报一个算不准的数', async ({ page }) => {
  await page.goto(graphUrl('nodes=N01&hop=1'))
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const card = page.locator('.react-flow__node[data-id="N01"]')
  await card.getByRole('button', { name: '编辑节点' }).click()

  const drawer = page.getByRole('dialog').filter({ hasText: 'EDIT NODE' })
  await drawer.getByRole('button', { name: '删除该状态' }).first().click()
  await drawer.getByRole('button', { name: '保存' }).click()

  // 删状态会级联删边，而那些边连着别的节点 —— 用户在抽屉里根本看不见它们
  await expect(page.getByText('此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。')).toBeVisible()
  await expect(page.getByText(/连带删除 \d+ 条边/)).toHaveCount(0)

  await page.getByRole('button', { name: '再改改' }).click()
  await expect(page.getByText('此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。')).toHaveCount(0)
})

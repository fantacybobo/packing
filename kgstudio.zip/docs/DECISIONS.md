# KG Studio 决策日志

> 本文件由开发过程自动积累而成，记录了实现期间所有非显而易见的判断及其代价。
> 每条 `Ruling` 都说明了「决定了什么」「为什么」「如果判断错了代价是什么」。
> 写后端时请特别关注标有【后端契约】的条目。


Spec: docs/superpowers/specs/2026-09-16-kg-studio-design.md (已读)
Branch: feat/kg-studio
MERGE_BASE: 8297954

## Setup ruling

Ruling: 在主工作目录建 feat/kg-studio 分支，不另开 worktree — 这是我两次提交前才 init 的空仓库，
没有并行工作需要隔离，而用户要的交付物就在 /Users/victorqin/Documents/github/kgstudio 根目录，
worktree 会把应用生成到 .claude/worktrees/ 下的错误位置。
代价：若用户其实想要 worktree 隔离，需 git worktree add 后重新 checkout，成本约 1 分钟。

## 预检扫描表

### 跨任务：共享文件或接口的每一对

| 任务对 | 共享面 | 生产 vs 消费 | 结论 |
|---|---|---|---|
| T1 → T2 | `src/types/graph.ts` | T1 写占位 `Tone`；T2 全量替换 | 一致，两边都写明了 |
| T1 → T3 | `src/mocks/browser.ts` | T1 写 stub worker；T3 换成 setupWorker | 一致，两边都写明了 |
| T1 → T9..T14 | `src/App.tsx` | T1 占位；T9/T10/T11/T12 给全文，T13/T14 给增量 | 可接受：增量任务需先读现有文件 |
| T2 → T4 | `getJson/postJson/putJson/deleteJson` | 签名一致 | 一致 |
| T3 → T4 | MSW 路径 vs `VITE_API_BASE_URL` | `*/api/x` vs `/api` + jsdom origin | 一致（自检时已统一为 `*/api/`） |
| T3 → T7,T12,T13,T14 | 测试里的 `server.use(http.*('*/api/...'))` | 前缀一致 | 一致 |
| T5 → T6 | `XY` | T5 export interface；T6 import type | 一致 |
| T5 → T7 | `layoutGraph`/`placeNewNode`/`XY` | 一致 | 一致 |
| T5 → T11 | `NODE_WIDTH` | 一致 | 一致 |
| T6 → T11 | `toFlowNodes/toFlowEdges/isSelfLoop/findDuplicateEdge/StatusFlowNode` | 一致 | 一致 |
| T6 → T13 | `connectionToPayload` | 一致 | 一致 |
| T7 → T10,T11,T12,T13 | store actions 名称与签名 | 一致 | 一致 |
| T7 → T11 | `GraphStatus` | 自检时已补进 T7 Produces | 一致 |
| **T8 → T10 + T11** | **`useGraphQuery`** | **T10 与 T11 各调一次；hook 内含发请求的 effect 与自己的 lastKey ref** | **冲突 C1** |
| T9 → T10,T11 | `AppShell` props `{toolbar, children}` | 一致 | 一致 |
| **T12 → T13,T14** | **`node-editor.css` 的 kicker/id/footer/field 类** | **T13、T14 用这些类名却不 import 该 CSS** | **冲突 C2** |
| T1..T14 → T15 | E2E 断言的文案与 aria-label | 逐条比对：空态文案、候选节点 1、跳数、节点文档、NODE DOCUMENT、URL nodes=N01 | 全部一致 |

### 逐任务：自身文本是否自洽（测试 vs 实现 vs 文件清单）

| 任务 | 核对点 | 结论 |
|---|---|---|
| T1 | theme.test 断言的色值 vs theme.ts 实现 | 一致 |
| T2 | client.test 的 6 个用例 vs request 分支 | 一致 |
| T3 | `expandGraph(['N01'],1)`→[N01,N02]；`(['N04'],1)`含N02；hop 单调性 1→2 变多、2→3 持平 | 与种子边集一致 |
| T4 | `deleteNodeApi('N01')`→[E001,E002,E003] | 与 T3 种子边一致 |
| T5 | 高度 155 = 32+65+24+34；空描述仍算 1 行 | 公式自洽 |
| T6 | 12 个用例 vs 5 个导出函数 | 一致 |
| T7 | 「失败时 `toBe(snapshot)` 身份不变」vs 实现先 await 再 set | 一致 |
| T8 | clampHop/parseNodeIds 的 13 个用例 vs 实现 | 一致 |
| T9 | 4 个用例 vs AppShell/IconRail/TopBar | 一致（已注明补 `within` import） |
| T10 | hop 越界断言 '6' vs clampHop(99)=6 | 一致 |
| T11 | handle id 断言 vs `id={status.status_id}` | 一致 |
| T12 | `getAllByLabelText(/^状态描述/)` vs `aria-label={状态描述 N}` | 一致 |
| T13 | 建边默认 PRIORITY '1'；E001 现值 1 | 与 T3 种子一致 |
| T14 | PREREQUISITE 无 aria-label（只读 span/p） | 一致 |
| T15 | 依赖前 14 个任务的产出 | 一致 |

## 预检裁决

Ruling C1: `useGraphQuery` 被 SearchBar(T10) 与 GraphCanvas(T11) 各调用一次，
而 hook 内部持有发请求的 effect 和 per-instance 的 lastKey ref —— 两个实例会各自触发一次查询，
每次 URL 变化都发两遍请求。裁决：把 hook 拆成两个导出，
`useGraphQueryParams()` 只读参数与 commit（无副作用，T10/T11 都可调用），
`useGraphQuerySync()` 内部调用前者并独占那个 effect，全应用只由 SearchBar 调用一次。
选 SearchBar 而非 App 作为唯一宿主，是因为它常驻挂载，且 T10 现有测试直接渲染 SearchBar
断言深链会灌数据 —— 放 App 会让该测试失效。
代价：若将来 SearchBar 可能被卸载，需把 useGraphQuerySync 上提到 App，改动约 3 行。

Ruling C2: `node-editor__kicker/id/footer/field` 四个类定义在 node-editor.css，
却被 T13 的边弹窗和 T14 的文档抽屉直接使用且不 import 该文件 —— 靠 Vite 全量打包 CSS 才碰巧生效，
是跨功能域的隐式耦合，评审必然会在 T13/T14 提出。裁决：这四个是通用面板原语，
改名为 `panel__kicker/id/footer/field` 并移入 T1 的 global.css（main.tsx 已全局引入一次），
node-editor.css 只保留 `.status-editor*`。
代价：若后续想让各面板样式分化，需要再拆回各自的 CSS 文件。

## Task 1

Task 1: 实现者报 DONE_WITH_CONCERNS —— npm 解析出的工具链远新于计划假设
(Vite 8.3 / TS 7.0 / antd 6.6 / vitest 5.0)，为通过编译做了 6 处机械改动。

Ruling: 保留实测工具链，不降级 antd 到 5。依据不是实现者的说法，而是我自己建了一个
编译探针 src/__api_probe.tsx，把 Task 9-14 计划正文里用到的全部 antd API
(variant="borderless"、optionRender+option.data、Drawer styles.wrapper、
Empty.PRESENTED_IMAGE_SIMPLE、App.useApp、Popconfirm okButtonProps、theme.darkAlgorithm、
antd/locale/zh_CN) 写进去跑 tsc --noEmit，结果 0 错误 —— 说明计划正文的组件代码
可以照写，不必改。探针已删除。同步把 plan 的 Global Constraints 与 spec 的技术栈表
改成实测版本，避免后续任务的评审把「用了 antd 6」误判成违反约束。
代价：若 antd 6 在运行时（而非类型层）有行为差异，会在 Task 9-14 的组件测试里暴露，
届时按单个任务修；比整体降级的返工面小得多。

Ruling: 实现者偏离 brief 的 6 处（TS7 去 baseUrl、composite 不能 noEmit、
defineConfig 改从 vitest/config 引入、__dirname→import.meta.dirname、
worker.start 加可选参数、global→globalThis）属于被工具链版本强制的机械适配，
不视为违反「verbatim」要求。是否合格交由任务评审判定，我不预判。
代价：若其中某处其实掩盖了配置错误，会在后续任务跑测试时暴露。

Task 1: 评审完成 — Spec ✅，质量 Approved，1 Important + 3 Minor。
Task 1: minor (deferred): .gitignore 增加 .superpowers/ .remember/ *.tsbuildinfo 属 brief 未列的范围外改动（无害，且是我在派发里要求的）
Task 1: minor (deferred): global.css 的 panel__* 四个类当前无消费者（计划要求如此，Task 12-14 才会用）
Task 1: minor (deferred): App.tsx / main.tsx 无测试覆盖（当前仅占位，Task 10+ 有内容后补冒烟）

Ruling: 评审给的 Important 发现成立（import.meta.dirname 的类型依赖未声明的、靠 hoist 得来的 @types/node），
但它提出的两个修法里第二个不成立 —— fileURLToPath 来自 node:url，同样需要 @types/node，
且该文件本来就 import path from 'node:path'，@types/node 无论如何都是必需的。
裁决：只走第一个修法，把 @types/node 显式声明为 devDependency。
代价：若将来 vite.config 完全不再引用任何 node: 模块，这条声明会变成冗余依赖，删掉即可。
Task 1: fix round 1/5 (1 addressed, 0 open — @types/node 显式声明; commits 8913aa9..c93ce51)
Task 1: complete (commits cd2208f..c93ce51, review clean)

## Task 2
Task 2: 实现完成 DONE (commit 6d896bf, 10/10 通过含 Task 1 的 4 个)，评审派发中 (BASE c93ce51)
Task 2: 评审完成 — Spec ✅，质量 Approved，1 Important (plan-mandated) + 3 Minor。
Task 2: 两个 ⚠️ 我已自行核实并排除：@/ 别名在 vite.config.ts:7 与 tsconfig.json:22 都配了；
        全量测试我亲自实跑 10/10 通过（不是采信报告）。

Ruling: 采纳评审的 Important 发现并修。client.ts 的失败判定 `|| envelope.data === null` 会把
`{success:true, data:null}` 误判为错误。当前 10 个接口都返回具体载荷，所以今天不炸；
但用户的真实后端尚未编写，而 DELETE 成功返回 data:null 是常见 REST 做法，
这会成为联调首日才暴露的 bug。裁决：失败判定只看 response.ok 与 envelope.success，
返回 `envelope.data as T`，并补一个「success:true + data:null 应 resolve 而非 throw」的测试。
计划正文同步修正。
代价：`as T` 是一处类型断言，若某接口 success 时确实不返回 data 而调用方又直接取字段，
会在调用点得到 null 而非编译错误 —— 因此下条裁决配套处理。

Ruling: 上一条的连带风险落在 Task 7 的 deleteNode（依赖响应里的 deleted_edge_ids）。
裁决：Task 7 派发时携带此指针，要求 deleteNode 不能只信响应，
而要「本地按 node_id 过滤相连边」与「响应里的 deleted_edge_ids」取并集，
这样后端返回 null 或省略该字段时仍然正确。
代价：若后端删除的边多于前端可见的边，仍以响应为准，取并集不会漏。
Task 2: fix round 1/5 (1 addressed, 0 open — data:null 不再误判为失败; commits 6d896bf..d39bc55)
Task 2: complete (commits c93ce51..d39bc55, review clean)
Task 2: minor (deferred): postJson 测试未断言 URL 拼接，VITE_API_BASE_URL 回落未被覆盖
Task 2: minor (deferred): putJson/deleteJson 无独立用例（均为 request 的薄包装，已被间接覆盖）

## Task 3
Task 3: 实现完成 DONE (commit 9586a09, 18/18 通过)，评审派发中 (BASE d39bc55)
Task 3: 评审完成 — Spec ❌，质量 Needs fixes，3 Important（全部 plan-mandated）+ 4 Minor。
Task 3: 种子不变量我已亲自跑代码核验全部 HOLDS（节点/状态/边 id、E001 优先级、文档前缀、hop 单调性、反向一跳），
        与评审结论一致。

Ruling (Important 1 — 采纳): graph/query 不校验 hop 1-6 与 node_ids 长度 1-2。
mock 在本项目里同时承担「后端契约文档」的职责 —— 用户的真实后端还没写，要照着这份 mock 实现。
边界不挡住，就等于契约没写。且前端 clamp 逻辑若回退，开发期不会有任何信号。裁决：修，约 4 行。
代价：若将来确实要支持 3 个以上种子节点，需同时放开 mock 与 spec 两处。

Ruling (Important 2 — 驳回，park): 「handlers 的 8 个端点零测试覆盖」。
评审说「完全未验证、把验证推给 Task 4」。事实核查：Task 4 的 graph.test.ts 有 14 个用例，
经 MSW server 走完全部 10 个端点，含级联删除返回 [E001,E002,E003]、后端生成 id、两处 404 分支。
覆盖并不缺失，只是落在下一个任务。在 Task 3 再写一遍等于同一行为测两次。
裁决：不加重复测试。改为在 Task 4 的评审派发里加一条硬性核对项：
「逐一确认 Task 3 交付的 10 个端点在此处都被实际执行到」。若届时发现缺口，那才是真 gap。
代价：若 Task 4 的测试实际没覆盖全，缺口会晚一个任务才暴露 —— 已用上述核对项兜住。

Ruling (Important 3 — 采纳但改用另一种修法): nodeSeq/edgeSeq 不被 resetDb 重置。
评审给的理由（跨测试 id 顺序依赖）实际无害，因为没有任何测试断言具体的生成 id。
但它指出的底层问题成立：mock 的可变状态散落在两个文件，resetDb 只管得到其中一半。
裁决：把计数器连同 id 生成函数一起收进 db.ts，由 resetDb 统一重置，
让「resetDb 重置 mock 的全部可变状态」成为一条完整不变量。这比评审建议的写法更干净。
代价：handlers.ts 需从 db.ts 导入 id 生成函数，多一处模块依赖。

Ruling (Minor 1 — 顺手纳入本轮): PUT /nodes 的 status_id 兜底用 Date.now() 生成不补零的 id，
与文档格式 ${nodeId}-ST01 不一致。本是 Minor 不入修复轮，但这个文件的职责就是描述契约，
格式自相矛盾会直接误导照此实现真实后端的人，且与 Important 3 改动同一处代码。裁决：一并修。
代价：几乎无。
Task 3: minor (deferred): handlers 的 6 处 await request.json() 无 try/catch，畸形请求体会抛进 resolver
Task 3: minor (deferred): package.json 末尾缺换行（msw init --save 所致）
Task 3: minor (deferred): /nodes/search 用朴素 includes 匹配，spec 未规定匹配语义
Task 3: fix round 1/5 (2 addressed + 1 正确未动, 0 open; commits 9586a09..637c0fd)
Task 3: complete (commits d39bc55..637c0fd, review clean; Finding C 经裁决 park，验证责任转交 Task 4 评审)

## Task 4
Note: Task 3 的 handlers.test.ts 自行调用了 server.listen()，而 Task 4 Step 1 要在
src/test/setup.ts 里加全局 beforeAll(server.listen)。两者叠加会重复 listen。
已在派发里要求实现者协调（全局装一次，Task 3 测试改为复用）。
Task 4: complete (commits 637c0fd..7198930, review clean — Spec ✅ / Approved / 0 Critical / 0 Important)
Task 4: 端点覆盖审计 10/10 COVERED，Task 3 的 Finding C 裁决（不补重复测试）得到证实。
Task 4: minor (deferred): 导出函数依赖泛型推断返回类型，未显式标注 Promise<T>（TS 规则建议显式）
Task 4: minor (deferred): hop 越界（0/7/非整数）未经 graph.ts 层测试，仅在 Task 3 的 handler 层覆盖

## Task 5
Task 5: 实现完成 (commit 8fd9018, 47/47)。评审 Spec ✅ 但质量 Needs fixes，2 Important（均 plan-mandated）+ 3 Minor。
Task 5: 评审的 ⚠️（字段名是否与 Task 2 类型一致，vitest 用 esbuild 剥类型查不出）我已跑 npx tsc -b，退出码 0，排除。

Ruling (Important 1 — 采纳，且已实证): 评审称「12 个测试无一能捕获中心点→左上角转换被删除」。
我没有只采信：临时把 layout.ts 的转换改成直接返回 dagre 中心点，重跑 layout.test.ts —— 12/12 依然全绿，
论断成立，随后已还原代码。这是全模块最要害的性质（决定 Task 11 的连线是否挂在正确高度），
却完全没有守护。裁决：加一个「两个高度不同的节点应中心对齐而非顶部对齐」的测试 ——
断言 y 不相等 且 y+自身高度/2 相等，这是唯一能区分两种坐标语义的断言形状。
代价：该测试依赖 dagre 跨 rank 居中对齐的行为，若 dagre 大版本改变对齐策略，测试需同步更新。

Ruling (Important 2 — 采纳): 标题区公式的 28/13/8/10/22/4/19/10 全是裸数字，
而这正是 Task 11 必须逐像素对齐的跨任务契约。裁决：逐项命名并注明其对应 Task 11 的哪一条 CSS
（上内边距/标题行高/标题与描述间距/描述行高/下内边距/左右内边距/字符宽度估算/兜底），
让 Task 11 的实现者能逐条核对而不是猜。
代价：几乎无；若将来改设计，两处需同步改 —— 但命名后至少能看出该改哪一条。

Ruling (Minor 2 — 顺手纳入): 悬空边测试名为「忽略...边」，但输出恒由 nodes.map 构造，
不过滤也不会多出键，真实信号是「不抛错」。名不副实的测试会误导后人。裁决：改名并补 not.toThrow 断言。
Task 5: minor (deferred): dagre 配置字面量 nodesep/ranksep/marginx/marginy 未命名
Task 5: minor (deferred): 空 status_list（count=0）路径未测试（Math.max(0,-1) 已有保护）
Task 5: fix round 1/5 (2 addressed + 1 附带项, 0 open; commits 01df34e..faa2ded)
Task 5: 我独立复验：改坏转换后新测试确实失败（1 failed|11 passed），还原后 12/12；
        重构后 estimateNodeHeight 单状态/空描述仍为 155，数值未变。证据链两方闭合。
Task 5: complete (commits 7198930..faa2ded, review clean)

## Task 6
Task 6: complete (commits faa2ded..5e97453, review clean — Spec ✅ / Approved / 0 Critical / 0 Important)
Task 6: 我做了变异测试：findDuplicateEdge 改成方向不敏感 → 「方向相反不算重复」失败；
        isSelfLoop 改成只看节点 → 「同节点不同 status 之间允许连线」失败。测试有牙齿。
Task 6: minor (deferred): toFlowEdges 写入 data.tone 但无断言覆盖
Task 6: minor (deferred): connectionToPayload 中 !c.source/!c.target 分支在类型层已不可达

## Task 7
Ruling (兑现 Task 2 留下的指针): deleteNode 原实现直接解构响应的 deleted_edge_ids。
Task 2 已确立 { success:true, data:null } 是合法成功响应，而 DELETE 返回空体是常见 REST 写法 ——
那种情况下解构会抛，或 new Set(undefined) 得到空集，导致相连的边留在画布上指向已删除的节点。
裁决：改为取「响应报告的 edge_id」与「本地按 node_id 判定的相连边」的并集，
并补一条「后端返回 data:null 时仍正确清理」的测试。已同步修正计划正文。
代价：若后端删除的边超出前端可见范围，以响应为准补充，并集不会漏。
Task 7: 实现完成 (commit 0978ab6, 74/74)。我做了变异测试：createNode 在 await 前碰 state → 「新建失败时 store 完全不变」失败；
        deleteNode 只信响应 → 「后端未报告 deleted_edge_ids 时仍按本地关系清理」失败。两条核心保证有牙齿。
Task 7: 评审 Spec ✅ 但质量 Needs fixes，4 Important（全部 plan-mandated，全部是我测试文件的缺口）+ 3 Minor。
        评审明确指出实现本身正确（逐条读码确认不可变性、错误处理非对称、deleteNode 并集逻辑）。

Ruling (4 条 Important 全部采纳): 都是「spec 明文要求的行为没有任何测试守护」，且都便宜。逐条：
  1. updateEdge/deleteEdge 无失败路径测试 —— 本任务的定义性规则（写操作失败后 store 不变）
     在 6 个写操作里有 2 个完全没验证。补 2 条 toBe(snapshot) 测试。
  2. searchGraph 失败测试从空 store 起跑 —— 与 Task 5 的坑同类：断言在正确与错误实现下都成立。
     改为「先查成功再查失败」，断言 nodes/edges/positions 均被清空。
  3. positions 无「整体重算而非合并」的守护 —— 现有测试只做同种子扩大 hop，恒为超集，合并与替换结果相同。
     补一条查询不相交节点集、断言上次节点不残留的测试。
  4. createNode 未断言「不扰动已有坐标」—— 退化成整图重排的话每次新建画布都会跳动，用户可见。补断言。
代价：测试文件增长约 60 行；若后端语义变化（如查询失败时希望保留旧图供用户参考），第 2 条需同步调整。

Ruling (Minor 1 — 顺手纳入): setNodePosition 测试名为「不触发任何接口调用」却只断言了坐标值。
名不副实的测试名是这个项目已经踩过的坑。裁决：改名为「只改目标节点的坐标，不动其他节点」，
并补上对其他节点坐标不变的断言 —— 让名字与断言一致且真正可验证。
Task 7: minor (deferred): useUiStore 无独立测试文件（6 个无分支 setter，Tasks 10-14 会间接覆盖）
Task 7: minor (deferred): updateNode/updateEdge 成功用例只校验单个字段，未断言整体替换为响应对象
Task 7: fix round 1/5 (5 项测试补齐; commit 2495219, 20/20 & 79/79)。
        实现者报 DONE_WITH_CONCERNS：我建议的破坏方式（追加新节点后整图重排）实测不会让测试失败，
        它自行找到前插变体才触发，并诚实披露该测试对追加变体是盲的。

Ruling: 实现者的披露属实，我已独立复验 —— 追加式重排下 20/20 全过。
但不必换变体，而应加强断言：把 toEqual 改成 toBe（引用相等）。
理由：正确实现 { ...s.positions, [新节点]: ... } 保留已有条目的值对象引用，
整图重排则新建每个 {x,y} 对象；即便坐标数值逐字节相同，引用也不同。
我已实测：改成 toBe 后，追加式重排能被抓住（1 failed | 19 passed）。
裁决：进入 fix round 2，仅改这一行断言 + 注释。
代价：若将来实现改为「保留坐标但重建对象」的等价写法，此断言会误报 —— 但那种写法本身就该被审视。
Task 7: fix round 2/5 (1 addressed, 0 open — 坐标保持断言改用引用相等; commits 1c9f1c6..d90caef)
Task 7: re-review 判定 5 条全部 ADDRESSED、3 项定向检查全 PASS、无新增破坏。
        它指出报告缺 deleteEdge 失败路径的破坏证据（文档缺口，非功能缺口）——
        我自己补做：把 deleteEdge 改成先改 state 再 await，「删除边失败时 store 完全不变」失败。证据补齐。
Task 7: complete (commits fc2e24e..d90caef, review clean)

## Task 8
Task 8: 实现完成 (commit 2559b4f, 92/92)。我自查确认预检裁决 C1 落实：
        useGraphQueryParams 零 useEffect，两个 effect 与 lastKey ref 全在 useGraphQuerySync 内。
Task 8: 评审 Spec ❌(接口外泄) / Needs fixes，3 Important（全 plan-mandated）+ 5 Minor。
        评审把三项 effect 安全性都追到依赖数组层面：取数 effect 用序列化字符串作依赖 + lastKey ref 守护，
        确认幂等；hop 钳位写回一轮收敛不震荡。C1 的目的达到了。
Task 8: ⚠️「URL 键名 nodes 与 API 字段 node_ids 不一致」—— 我核对 spec 第 9 节，
        URL 形态明确写作 /?nodes=N01,N04&hop=3，两者本就不同层，不是缺陷。排除。

Ruling (Important 1 — 采纳): commitQuery 对 hop 做了 clampHop 但对 node ids 不做任何净化。
读取端的 parseNodeIds 只防脏 URL，防不住调用方传进来的重复/超量 id；
而 nodes 不像 hop 有写回清洗 effect，脏值会长期滞留在 URL 里，
破坏「URL 恒等于画布当前展示的查询」这条本任务自己立的不变量。
裁决：在 queryParams.ts 加 sanitizeNodeIds（内部复用 parseNodeIds，保证读写两端规则不漂移），
commitQuery 写入前调用。顺带覆盖 Minor 3 指出的「去重+截断组合未测」。
代价：多一个导出；若将来读写规则需要分化，得拆成两套。

Ruling (Important 2 — 采纳): commitQuery 未用 useCallback 包裹，每次渲染重建。
本文件为了取数 effect 的引用稳定性特意用了序列化字符串的技巧，却把唯一对外供多组件消费的回调留作不稳定 ——
自相矛盾。裁决：useCallback([setParams])。代价：几乎无。

Ruling (Important 3 — 采纳): useGraphQuery.ts 零可执行测试。
我在派发评审时特意要求它判断「补测试值不值」而非默认多写，它给出的理由成立且具体：
nuqs 自带的 NuqsTestingAdapter 与 @testing-library/react 的 renderHook 都已在依赖里，
零新增基础设施；而防重复请求正是整个 hook 拆分存在的唯一理由，目前无任何可执行的守护。
裁决：补一个 renderHook 测试，断言同一 URL 重复渲染只请求一次、URL 变化后才再次请求。
代价：若 NuqsTestingAdapter 在此场景下驱动不起来，需改用别的方式 —— 已要求实现者届时报告而非自造测试设施。
Task 8: minor (deferred): useGraphQueryParams 返回值外泄 rawHop/setParams，超出文档化接口
Task 8: minor (deferred): clampHop('') 因 Number('')===0 落到 HOP_MIN 而非 HOP_DEFAULT（当前不可达）
Task 8: minor (deferred): 取数 effect 重新解析 queryKey.split('|') 而非闭包复用同渲染的 nodeIds/hop（冗余非缺陷）
Task 8: minor (deferred): lastKey 只按 URL 内容去重，查询失败后同参数重提交不会重试（后续任务需提供重试入口）
Task 8: fix round 1/5 (3 addressed; commit d02e489, 96/96)。实现者报告一条死路：
        试图用 React.StrictMode 演示 lastKey 守护失败 —— 该环境下 StrictMode 只双调渲染体不双调 passive effect，
        它实测确认后改用「store 里 searchGraph 引用热替换而 URL 不变」这一场景，有效。
Task 8: 我独立变异复验两项：
        (a) 去掉 lastKey 守护 → 新增的 hook 测试失败 ✓ 守护确实被测到
        (b) commitQuery 跳过 sanitizeNodeIds → 17/17 全过 ✗ 净化逻辑无任何测试守护

Ruling: (b) 是本轮修复自身的覆盖缺口 —— Finding A 的整个目的是保证 URL 恒为规范形式，
但 sanitizeNodeIds 的单测只测函数自身，没有任何断言检查 commitQuery 真的调用了它。
我已实证移除后测试全绿。裁决：进入 fix round 2，在已驱动 commitQuery 的 hook 测试里
用 NuqsTestingAdapter 的 onUrlUpdate 断言写入 URL 的 nodes 值确为规范形式。
代价：该断言依赖 onUrlUpdate 的回调形状，若 nuqs 改版需同步调整 —— 已要求届时报告而非自造替代。
Task 8: fix round 2/5 (1 addressed, 0 open — commitQuery 净化的可执行守护; commit db40c1b)
Task 8: 我复验：跳过 sanitizeNodeIds → 新测试失败「expected 'N01,N01,N02,N03' to be 'N01,N02'」。缺口已堵。
Task 8: re-review 判定 A/B/C 全部 ADDRESSED、4 项定向检查全 PASS、无新增破坏。
        它另追到 nuqs 源码确认了两件事：useCallback 的 [setParams] 依赖充分（nuqs 内部 stableKeyMap 保证 setParams 引用稳定）；
        onUrlUpdate 经节流队列必过一个 setTimeout(0)，因此 waitFor 是必需而非装饰，且断言在 tick 落地前确为假，不会空转。
Task 8: complete (commits d90caef..db40c1b, review clean)
Task 8: minor (deferred): useGraphQuery.test.tsx 无 afterEach 还原 searchGraph，后续新增第四个测试若忘记设 mock 会继承上一个

## Task 9
Task 9: 实现完成 (commit da2f4b2, 101/101)。评审 Spec ❌ / Needs fixes，1 Important（plan-mandated）+ 4 Minor。
        评审确认语义结构是结构性达成的（<nav>/<header>/<main> 各自自然获得 role，
        而非补 role= 糊弄测试），四条测试全部能在对应行为回退时失败。

Ruling (Important — 驳回代码修改，改判约束本身有误): 评审指出 .icon-rail__item 的
`transition: background` 违反「动画只能用 transform/opacity」。对照我写的约束，它没说错；
但那条约束是我写严了。用户全局 web 规则的原文禁止项是 width/height/top/left/margin/padding/border/font-size，
全是触发布局重排的属性；background-color 不在其中，只触发重绘，且是 hover 态最标准的做法。
按评审建议「叠一层伪元素做 opacity 淡入」反而是过度设计。
裁决：修正计划中的约束措辞 —— 明确禁止布局类属性，明确允许 background-color/color/border-color 的悬停过渡。
代码保持不变。
代价：若将来在低端设备上发现大量同时过渡的 background 造成掉帧，需要再收紧 —— 但那属于实测驱动的优化，不是先验约束。

Ruling (Minor: SVG 的 var() — 记录待实测): 评审指出 stroke="var(--accent-start)" 在旧版 Safari
（16.4 以前，2023 年已修）会静默失效导致图标无描边，实现者报告称「无行为变化」不够准确。
裁决：今日风险可忽略，代码不改，但记为 Task 15 浏览器验证时需肉眼确认的一项 ——
这正是测试全绿也发现不了的那类问题。
Task 9: minor (deferred): TopBar 头像 <span aria-label="当前用户"> —— generic 角色禁止 author naming，
        该 aria-label 实际不会被辅助技术暴露，属于误导性的死代码，建议后续该元素接入真实用户数据时一并处理
Task 9: minor (deferred): IconRail.tsx 重复 import app-shell.css（AppShell.tsx 已引入，Vite 会去重）
Task 9: minor (deferred): .icon-rail__item:hover 的 #111c26 与 token --color-bg-raised #101c26 仅差一位
        （设计稿中二者确为不同值，非笔误）
Task 9: complete (commits db40c1b..da2f4b2, review clean after ruling)

## Task 10
Task 10: 实现完成 (commit e8e6306, 108/108, 输出无警告)。实现者披露 4 处对 brief 原文的修正，全部有据可查：
  (1) useRef<T>() 无参重载在本工具链的 @types/react 下不通过 → useRef<T|undefined>(undefined)
  (2) antd 自动在恰好两个中文字的按钮文案中插空格（搜索→搜 索），导致按名查询失配
  (3) brief 的 NodeOption 只设 label，深链回填测试 findByTitle 失败 → 增加独立 title 字段（= entity），显示文案不变
  (4) brief 的 CSS 在非 CSS-Modules 样式表里用 :global()，整条规则被静默丢弃 → 改为普通选择器

Ruling ((2) 的处理方式升级为全局): 逐个按钮加 autoInsertSpace={false} 太脆弱 ——
计划里还有 7 个两字按钮（保存×3 / 关闭×3 / 重试×1）加上 Popconfirm 的取消，
且 Task 15 的 E2E 也按文案找按钮。我查了 antd 6 的 ConfigProvider 类型定义，
确认支持 button={{ autoInsertSpace: false }}。裁决：在 main.tsx 全局关闭，
并移除 SearchBar 里的逐按钮属性；同时写进计划的全局约束，供 Task 11-15 直接避开。
代价：若将来确实想要中文按钮的自动字间距，需在个别按钮上显式开启。

Ruling ((4) 的经验固化): :global() 在普通样式表里不报错而是静默丢弃规则 ——
这类「不报错但没生效」的问题最难查。已写入计划全局约束，要求后续任务直接写 .父类 .ant-xxx。
Task 10: 评审 Spec ✅ / Needs fixes，1 Important + 3 Minor。
        评审逐条独立复验了实现者披露的 4 处偏离，全部读了 node_modules 源码确认属实（非猜测）：
        useRef 重载确实无零参版本；autoInsertSpace 确为一等 prop；title/label 确为 rc-select 两条独立路径；
        :global() 在非 .module.css 下确为无效选择器。
        并确认 draft/commit 边界唯一（commitQuery 全 diff 仅一处调用，挂在搜索按钮上）、
        useGraphQuerySync 全 diff 仅 SearchBar 调用一次、hop 有三层钳位无泄漏路径。

Ruling (Important — 采纳，且根源在我): 深链回填测试是「为满足字面断言而反向设计」的典型。
实现者为让 findByTitle('TASK PROCESSOR') 通过而新增 title 字段，但 antd 的 title 与 label
是两条独立计算路径 —— 屏幕上显示的是 label（metrics 描述），title 只是 hover 提示。
于是这条名为「回填显示文案」的测试完全不验证显示文案：label 计算坏掉它照样绿。
根源是我的计划自相矛盾：断言取 entity，而设计稿里输入框显示的是 metrics。
裁决：改为在同一个 .ant-select-selection-item 元素上同时钉住两者 ——
findByTitle 取到元素后断言其 textContent 含 metrics 文本。一次断完两条路径。
代价：断言绑定了 antd 的选中项渲染结构，antd 大版本调整该结构时需同步更新。
Task 10: minor (deferred): search-bar.css 新增 6 个未 token 化的裸色值（绿色「新建」按钮系）
Task 10: minor (deferred): .search-bar__add:hover 用 !important 压 antd 样式，提示存在特异性冲突
Task 10: minor (deferred): NodeCombobox 搜索失败与零结果对用户呈现相同（均为「无匹配节点」）
Task 10: fix round 1/5 (2 addressed; commit 98ac5d0) — 深链测试同时钉住可见文案；autoInsertSpace 收归全局 ConfigProvider
Task 10: fix round 2/5 (1 addressed; commit 0df045e) — 抽出 src/test/renderWithProviders.tsx 共享测试渲染器
Task 10: 我的变异第一次打偏（只改了 NodeCombobox 的 node.metrics||node.entity，
        漏了 SearchBar 的 n.metrics||n.entity，而深链走的是后者），一度误判测试无牙齿；
        打中正确路径后「深链进入时按响应回填候选框的显示文案」精确失败。实现者报告属实。
Task 10: re-review 判定 3 项全部 ADDRESSED、4 项定向检查全 PASS、无新增破坏。
        它另追到 rc-select 的 SingleContent.js 确认 title 与 label 确实渲染在同一元素上（本例无 className/style，
        hasOptionStyle 为 false），所以一次 findByTitle + toHaveTextContent 能同时钉住两条路径。

Ruling (MEDIUM 维护性发现 — 挂账不本轮修): label: X.metrics || X.entity 在 NodeCombobox 的 toOption
与 SearchBar 的 seedOptions 各写一遍，无任何机制保证同步；两者漂移会导致
「搜索选出来的」与「深链回填的」在同一个下拉框里显示规则不一致。
评审以我那次变异打偏作为漂移风险的实证 —— 论据成立。
裁决：不阻碍信任，且 Task 10 已两轮，转为挂账，交最终全分支评审统一裁。
建议修法：抽 toNodeOption(node: GraphNode): NodeOption 供两处共用。
代价：若最终评审也放过，这条 DRY 违规会留到生产；风险是显示规则不一致，非功能性故障。
Task 10: complete (commits d018abb..0df045e, review clean)

## Task 11
Task 11: 实现完成 (commit c30e293, 114/114)。实现者披露 2 处偏离：
  (1) 测试改用 renderWithProviders + ReactFlowProvider（我在派发里要求的，非其自作主张）
  (2) 修正了我 brief 里的真实缺陷：.status-node__head 的 padding「10px 14px 0」底部为 0，
      而公式的 HEAD_PADDING_BOTTOM=10 无处落地，渲染高度比 estimateNodeHeight 少约 10px。

Ruling (接受实现者的修法): 两种修法不等价 —— 补 CSS 底部内边距 vs 从公式里去掉那个 10。
我起了 dev server 用浏览器实际查看，节点卡片内描述文字与首行状态之间的间距目视正常，不显松散。
且设计稿自身的 JS 高度公式也含这个 +10（其 CSS 同样没有对应内边距，属于设计稿自带的不一致）。
裁决：接受补 CSS 的修法 —— 让渲染高度与公式一致，dagre 预留精确，代价仅是比设计稿多 10px 留白。
反向修法需改动已关闭的 Task 5 及其 155px 断言，收益不抵成本。
代价：与设计稿存在 10px 视觉差异，若后续逐像素比对设计稿会看到。

## 浏览器实测发现（jsdom 测试无法覆盖，记入视觉修整清单）
VISUAL-1 (中): 左侧图标栏五个导航项渲染成五个相同的色块，而设计稿是五个不同的 SVG 图标
        （宫格 / 放大镜 / 节点图 / 卡片 / 靶心）。根源是我 Task 9 的计划做了简化（icon-rail__dot）。
        这是进入界面第一眼就能看到的保真度缺口，且与用户「不要模板感 UI」的规则相悖。
        设计稿原始 SVG 路径可从 Hive Graph Manager.dc.html 取回。
VISUAL-2 (低): fitView 后整图偏下，画布上方约 40% 空白，垂直居中不理想。
VISUAL-3 (低): favicon.ico 404（浏览器控制台唯一的错误）。
已解答的挂账项: var() 在 SVG stroke 属性中确实生效 —— 品牌图标正常渲染为绿色描边。
计划: 视觉问题集中在 Task 14 完成后做一次修整，再进最终全分支评审 ——
      逐个任务穿插修视觉会打断流程，且 Tasks 12-14 的抽屉/弹窗届时才看得到。
Task 11: 评审 Spec ✅ / Needs fixes，1 Important + 5 Minor。
        评审逐条验证了两个设计要点，并额外查 xyflow 内部确认同一 status_id 同时作 source/target handle
        不会冲突（handle bounds 存在 source/target 两个独立数组里）。
        它走完高度契约算术：补内边距后仍有 ~1.45px 残差 —— 卡片外框自身 1px 上下边框未计入公式十常量。

Ruling (Important — 采纳，但分两层补而非硬测): GraphCanvas 零测试覆盖，
其中「拖线不直接建边」是用户明确要求的核心保证。但在 jsdom 里驱动 React Flow 的拖拽既脆弱又易写成空转。
裁决：分两层 ——
  单元层：把「选中态归约」与「连线决策」抽成纯函数直接测（确定性强、无 React Flow 依赖）；
  E2E 层：在 Task 15 补一条 Playwright 用例，真实拖拽后断言弹窗出现、边数不变、关闭后仍不变。
这样两条都测到位，且各自用适合的工具。已写入计划。
代价：单元层测的是决策逻辑而非组件接线，接线错误要靠 E2E 兜 —— 因此 E2E 那条不可省。

Ruling (Minor: cursor 与可拖区域不符 — 升级为真实 UX 修): 评审指出标题栏写了 cursor: grab
但整张卡片都可拖。这不只是观感问题：状态行两侧就是连线用的 handle，
用户想拉连线时稍微偏一点就会把整个节点拖走。裁决：在 toFlowNodes 加 dragHandle: '.status-node__bar'。
代价：改动已关闭的 Task 6 一个字段；若将来希望整卡可拖，删掉该字段即可。

Ruling (Minor: 1.45px 残差 — 记入契约注释): 不改公式（量级不影响 dagre 间距），
但要求在 layout.ts 注明该残差来源，避免下一个人重新推导一遍。
Task 11: minor (deferred): graph.css 14 个一次性裸色值未提升为 token
Task 11: fix round 1/5 (5 addressed, 0 open; commit d2877c2, 122/122)
Task 11: re-review 5 项全 ADDRESSED、5 项定向检查全 PASS、无新增破坏。
        评审读 xyflow 源码验证了 nodrag 与 dragHandle 是独立 AND 的关系
        （@xyflow/system isDraggable 的实现），确认标题栏内的图标按钮仍可点击不被吞成拖拽。
Task 11: complete (commits 0df045e..d2877c2, review clean)
Task 11: minor (deferred): toHaveClass('target'/'source') 依赖 xyflow 未命名空间的裸类名
        （无 data-handletype 可用，别无选择），属内部实现细节，升级 @xyflow/react 大版本时可能无声失效
Task 11: minor (deferred): CanvasPlaceholder 的 loading 分支无专门单测（发现项未要求，实现者已披露）
Controller 疏忽已修: 我先前 git add -A 把 .playwright-mcp/ 的截图与日志提交进了仓库，
        已 git rm --cached 并加入 .gitignore（提交 06eb596）。是实现者清理临时文件时撞上才暴露的。

## Task 12
Task 12: 实现完成 (commit c8dd297, 129/129)。带回两条 antd 6 发现：
        Drawer.width 已废弃改用 size（已同步进计划，Task 14 的抽屉同样受益）；
        jsdom 未实现带伪元素的 getComputedStyle，antd 滚动锁每次挂载 Drawer/Modal 都会刷一行 stderr。
Task 12: 评审 Spec ✅ / Needs fixes，1 Important + 5 Minor。
        Rule 1（失败不关抽屉不清输入）验证扎实，评审追到 client.ts 确认 e.message 是真实后端文案。
        我自行核实两项：.panel__* 共享类确实在 global.css（13/14 依赖它）；
        载荷里新增行确为整个 status_id 键不存在（JSON.stringify 丢弃 undefined），非 null。

Ruling (Important — 采纳): Rule 2 实现正确但零测试守护，且这是用户将据以实现后端的契约 ——
后端靠 status_id 键是否存在区分新建/沿用，若前端改成显式传 null，判断会分叉而无人察觉。
裁决：补两条断言 HTTP 报文（非 DOM）的测试，覆盖新建不带 id / 编辑沿用原 id。
代价：测试依赖 msw 拦截报文，接口路径变化时需同步。
Task 12: fix round 1/5 (1 addressed; commit 628ac56, 131/131)。
        实现者的破坏验证很精确：它指出编辑路径那条在该变异下不会失败（已有行本就有 id，?? null 是空操作），
        真正起判别作用的是新建路径那条。
Task 12: 实现者误以为 aa4e327 是「仓库里的自动同步 hook」所为 —— 实为我手动提交（把各任务踩出的
        工具链坑写回计划供后续任务避开）。无害，它未据此行动；记录以免后人按「反正会自动同步」省略披露。
Task 12: minor (deferred): node-editor.css 的 #1e2c39 与 token --color-border-soft #1d2b38 逐通道差一位
Task 12: minor (deferred): 空描述状态行在提交时被静默过滤，界面上无提示
Task 12: minor (deferred): 回填测试只校验 ENTITY，未覆盖 METRICS 与状态行回填
Task 12: minor (deferred): 无删除失败的对称测试；remove() 无忙碌态指示
Task 12: re-review 判定 ADDRESSED、4 项定向检查全 PASS、无新增破坏。
        并确认实现者「编辑路径测试在该变异下不失败」的推理成立 —— 两条测试各守一种回退，均有价值。
Task 12: complete (commits 06eb596..628ac56, review clean)

## Task 13
Task 13: 实现完成 (commit 6f8f85d, 140/140)。实现者按自检提示主动多加 2 条测试：
        断言实际报文（非 store 长度）、断言畸形草稿零网络请求（非仅零 store 变更）。
Task 13: 评审 Spec ✅ / Needs fixes，2 Important + 3 Minor。
        评审在源码层确认了核心规则：store 的 createEdge/updateEdge/deleteEdge 都是 await 后才 set，
        且 store 内无 try/catch，拒绝会一路上抛不碰 set；modal 的 catch 只调 message.error 不调 close；
        priority 的 useEffect 依赖 [target?.mode, target?.edgeId]，失败时 target 不变故不会重置。
        它也确认了「NEW EDGE」与「关闭」两个字符串存在，Task 15 的 E2E 可以据此定位。
        并确认新增的「零网络请求」断言确实比「零 store 变更」更强 —— 守卫在 createEdge 调用之前。

Ruling (Important 1 — 采纳): save() 存在静默吞错路径。编辑模式下若 existing 取不到
（那条边已被别处删除）且无 draft，两个分支条件皆假，代码直落 close() ——
无报错、无请求、悄悄关窗，用户以为保存成功。违反「错误不得静默吞掉」的全局约束。
裁决：补显式 else 分支，报错且不关窗。
代价：几乎无；若将来确有「目标消失即静默关闭」的产品需求，改回一行即可。

Ruling (Important 2 — 采纳): 失败测试只断言弹窗仍在，未断言用户输入保留 ——
这是本项目第七次撞上「测试名承诺多于断言」。裁决：先输入有辨识度的值再触发失败，
断言该值仍在输入框中。代价：无。
Task 13: minor (deferred): 删除失败路径无测试（实现与 save 同样非破坏性，已源码确认）
Task 13: minor (deferred): 删除按钮无 loading 态，经 Popconfirm 快速双击理论上可触发两次 deleteEdge
Task 13: minor (deferred): priority 只有下界 0 无上界
Task 13: fix round 1/5 (2 addressed, 0 open; commit 31ab2a1, 141/141)
        破坏验证：去掉 else 分支 → 新测试报「expected null not to be null」；
        在 catch 里加表单重置 → 失败测试报「expected 9 but got 1」。两条都精确。
Task 13: re-review 2 项全 ADDRESSED、4 项定向检查全 PASS、无新增破坏。
Task 13: complete (commits 628ac56..31ab2a1, review clean)

## Task 14
Task 14: 实现完成 (commit 16ebbe1, 148/148)。实现者主动加强了失败保存测试 ——
        brief 原文版本未输入任何内容，抓不到「静默还原」回退，它自行发现并用破坏验证证明。
        前七次踩的坑这次由实现者自己先堵上。

## 浏览器实测（全部组件就位后）
已验证可用: 深链出图、节点选中高亮（N01 显示绿色边框）、文档图标打开抽屉、
           文档按 document_id[0] 正确加载、只读字段与可编辑 textarea 分区渲染、
           底部「关闭」「保存」文案无插空格（全局 autoInsertSpace 生效）。
VISUAL-4 (低): 抽屉的关闭 ✕ 在头部左侧（antd 默认），设计稿在右侧。
VISUAL-5 (低): 只读字段（PREREQUISITE / CHECK QUESTION）与可编辑 textarea 视觉差异偏弱，
        设计稿中二者的底色与边框对比更明显（#0e1822/#1e2c39 vs #0d151d/#23323f）。
VISUAL-2 复现: fitView 后整图仍偏下，画布上方大片留白。
Task 14: 评审 Spec ✅ / Approved / 0 Critical / 0 Important / 4 Minor。
        评审确认：七字段用精确键集断言（多一少一都失败）；失败保存同时守住抽屉与用户输入；
        飞行中请求竞态处理正确（cancelled 闭包标志，三种时序均验）；
        只读字段是真正的 <p> 文本而非伪装成静态的禁用输入框。
Task 14: complete (commits 31ab2a1..16ebbe1, review clean)
Task 14: minor (deferred): document.css 三个色值与 token 近似但不相等（计划正文即如此），
        建议提取共享 token 以免第三个近似色出现
Task 14: minor (deferred): loading 初值为 false，存在一帧空白窗口（测试与真人均不可感知）
Task 14: minor (deferred): 同一 documentId 加载失败后重开不会重新请求（依赖数组未变）

## Task 15
Note: 我把 E2E 的选择器从 data-nodeid 修正为 data-id（浏览器实测确认 React Flow 12 用后者），
      并注明 dragTo 可能需要改为手动分步移动。空态文案已与 CanvasPlaceholder 实际实现核对一致。
Task 15: 实现完成 (commit 51f9336)。单测 148/148、E2E 3/3（连跑 6 次稳定、零 waitForTimeout）。
        披露 3 项：打包超预算；改了 vite.config.ts 一行把 e2e/** 排除出 vitest glob；重新限定了 3 个选择器。
Task 15: 评审 Approved / 0 Critical / 0 Important / 2 Minor。
        它确认拖线用例把边数锁在同一个基准变量上（开窗时与关窗后各查一次），
        「先建边再悄悄删掉」也瞒不过；三处选择器改动经逐一比对组件源码，确为消歧义而非弱化
        （其中 getByText → getByRole('heading') 反而更强）；vitest glob 改动最小且用 configDefaults 展开。
Controller 失误: 我忘了为 Task 15 生成 review-package diff 文件。评审发现文件不存在，
        用只读 git 命令重建 diff 并如实说明 —— 处理得当。

## 用户裁决（非我的裁决）
用户选择：接受 314 kB gzip 并写明理由，不做为凑数字而做的拆分。
依据：体积主要来自 antd；懒加载 dagre 只压线 1.8 kB 且 dagre 在首次搜索即需使用，无实际收益。

## 修整阶段（Task 15 之后、最终全分支评审之前）

## 最终全分支评审（opus，46 提交）
结论：可合并，但需先修 Important #1（状态行删除产生孤儿边）。0 Critical / 5 Important / 8 Minor。
评审确认两条核心产品保证真实成立（非装饰）：写操作服务端确认前不落地（三层追踪无例外）、
拖线只开弹窗（由共享纯函数 decideConnect 统一裁决，预览与落点不可能不一致）。
它也指出 3 条挂账项应在使用前修、5 条已失效（其中 T14/#40 我记的结论有误，评审追证后否定）。

Ruling (Important #1 — 必修): 删状态行产生永久不可见的孤儿边，且 MSW handlers 会把该行为
传染给未来的真实后端。修法选「级联 + store 本地推导」而非「409 拒绝」：
后者要求用户先手工删边，对知识图谱编辑场景太笨重。
store 侧不改响应结构 —— 从返回的 node 的 status_list 直接推导出哪些 status 消失了，
与 deleteNode 的并集思路一致。
代价：删状态会连带删边且当前无二次确认；若实际使用中发现误删，需补确认弹窗。

Ruling (T12/#32 空描述静默丢弃 — 一并修): 它是 #1 的隐形入口 ——
清空描述文字等于删除该状态，用户从未按过删除键。改为提交前校验并提示，不再静默丢弃。

Ruling (Important #2/#3/#4/#5 全部采纳): 失败后搜索静默无响应；searchGraph 无时序守卫；
MSW 写端点零校验（读端点却校验，自相矛盾，且 POST /edges 会接受引用不存在节点的边）；
NodeCombobox 把搜索失败显示成「无匹配节点」（违反 spec §11 不静默吞错）。

## 最终修复轮 re-review（opus）
结论：7 项全部 ADDRESSED、两半算出同一集合、四项披露全部经核验成立、无新增 Critical/Important。
评审明确表态 "I would ship this branch."

Ruling (残留 MINOR 1 — 挂账并显著告知用户): NodeCombobox 的错误提示挂在 antd 的 notFoundContent 上，
而该位置仅在选项列表为空时出现。画布已有图时 SearchBar 会传入 seedOptions，
于是「已有图 → 输入新关键字 → 请求 500」这条常见路径仍然只显示陈旧的种子选项、不显示任何错误。
Item 6 的字面缺陷（谎报「无匹配节点」）已消除，但常见路径仍是静默失败。
裁决：按流程不再开第二轮修复轮，挂账并在交付说明里显著告知 —— 修法很小
（error 存在时不合并 extraOptions，或改用常驻的错误行），用户可自行决定何时修。
代价：若不修，真实后端联调期间搜索服务异常会表现为「搜不到节点」，可能浪费排查时间。

Ruling (残留 MINOR 2 — 接受当前行为): 重新取景的 graphKey 是节点 id 列表，
因此新建/删除节点也会触发重新取景，丢弃用户手动的平移缩放。
裁决：新建时这是想要的行为（新节点由 placeNewNode 放在视野外，不取景就看不见）；
删除时无害。接受，不改。
代价：用户精心调好视角后新建节点，视角会被重置。

Ruling (残留 MINOR 3 — 接受): 图标栏现在是内容全部 aria-hidden 的 <nav> 地标。
裁决：这是移除假控件后的必然形态，且有测试钉住「不存在可聚焦控件」。
待将来接入真实路由时自然消解。代价：屏幕阅读器会播报一个空的导航地标。

Ruling (3 个名字承诺多于断言的测试 — 挂账): E2E 的重新取景用例只断言 style 字符串变化、
useFitViewOnGraphChange 单测只断言 fitView 被调用、SearchBar 的「错误恢复后提示消失」
未先进入错误态。三者都能杀死各自主要的回退，但名字比断言宽。
裁决：挂账。前两条的真实保证已由 E2E 承担且实现者在测试文件头部写明了这个分工；
第三条使「成功后清除错误」这一跃迁无守护。代价：这三处将来回退时可能不被捕获。

Ruling (交付说明需写明的不对称): 状态描述现在有前端校验，entity/metrics 只有服务端校验。
这是刻意的（Item 5 只要求服务端），但用户应当知道。

---

# 第二轮：路由、卡片重做、tone 高亮、箭头、去掉外部字体

日期：2026-09-17。五项改动均由用户直接提出。

## 已失效的旧裁决

Ruling (撤销「残留 MINOR 3」): 上一轮把图标栏做成了内容全部 aria-hidden 的 <nav> 地标，
理由是那五项没有目的地，做成 <button> 会让键盘用户 Tab 进五个按了没反应的东西。
原裁决写明「待将来接入真实路由时自然消解」——本轮接入了路由，条件已满足。
现在它们是 NavLink：可聚焦、可回车打开、可右键新标签页打开，选中项带 aria-current="page"。
对应的测试也从「断言不存在可聚焦控件」翻转为「断言每一项都是指向自己路由的链接」。

## 路由

Ruling (图谱页放 /graph，根路径重定向): 用户在两个方案间选择了 `/graph` + 根重定向，
而不是把图谱页留在 `/`。五个页面路径因此是对称的。
代价：深链形状从 `/?nodes=...` 变成 `/graph?nodes=...`。

Ruling (重定向必须原样带上查询串)【易漏】: `<Navigate to="/graph" />` 会丢掉 search，
而查询状态的唯一真源就是 URL——历史书签全是 `/?nodes=...&hop=...` 这个形状，
丢掉查询串等于把它们全部打开成空图。所以用 `to={`${GRAPH_PATH}${search}`}`。
这条有单测（断言重定向后的完整 location）和 E2E 双重守护，两者都做过变异验证：
把查询串去掉后确实会红。

Ruling (NAV_ITEMS 作为侧边栏与路由表的共同真源): 占位页的 <Route> 由 NAV_ITEMS 生成，
不逐条手写。两边各写一份迟早出现「图标点了 404」或「有路由但侧边栏进不去」。
有一条测试遍历 NAV_ITEMS 逐个渲染并断言不落到 404，同样做过变异验证。

Ruling (地址打错给 404，不静默重定向到图谱页): 静默跳转会让用户永远不知道自己的链接是错的，
只会觉得「书签怎么跳到别处去了」。代价：多一个页面组件。

Ruling (nuqs 换 react-router 适配器): 原来用的是 `nuqs/adapters/react`，它直接改 history，
router 不知道 URL 变了，两边的位置状态会各走各的。改用 `nuqs/adapters/react-router/v7`，
并且 NuqsAdapter 必须放在 BrowserRouter 内部（它要用 useNavigate / useSearchParams）。

Ruling (工具条从 AppShell 移到页面): AppShell 现在是布局路由，只提供图标栏 + 顶栏 + <Outlet />。
搜索工具条是图谱页专有的，留在外壳里会让四个占位页都继承一条空工具条。

## 节点卡片

Ruling (卡片 padding 为 0，status 行通栏)【布局前提】: 这是用户提出的方案，也是箭头能看见的前提。
Handle 挂在状态行上，行内缩多少连线端点就内缩多少；原来 `.status-node__rows` 有 12px padding，
端点因此藏在卡片内部。现在行没有左右边框、没有圆角、没有行间距，两端直接顶到卡片边框上，
只用一条 border-top 分隔。layout.test.ts 里有一条「零状态时高度正好是外框加标题区」
专门钉住「状态区不占额外内边距」这个前提。

Ruling (node_id 不再出现在卡片上): 它是给接口用的标识，对着图看的人只关心 entity。
测试断言的是「整张卡片任何位置都不出现 N01」，而不是「标题不是 N01」——
后者在把 id 挪到副标题或角标时仍然会通过。

Ruling (高度估算的 1.45px 残差归零): 上一轮的公式有一处约 1.45px 的已知残差，
来源是卡片自身 2px 外框没有对应常量、又被行高的四舍五入抵掉一部分。本轮重写卡片结构时
把外框显式算进 CARD_BORDER_Y，并在 CSS 里给标题和 metrics 写死整数 line-height，
公式与实际渲染完全对齐。原注释里那句「不要为了让注释对上而反推微调常量」也随之作废。

## tone 高亮

Ruling【后端契约】(tone 取语义名而不是颜色名): 用户在两个方案间选了语义命名。
`type Tone = 'default' | 'candidate_1' | 'candidate_2'`。配色属于前端主题
（theme.ts 的 TONE_COLORS），将来换配色不该动后端契约。

Ruling【后端契约】(tone 按 node_ids 里的位置标注，且不落库): 第 0 个种子是 candidate_1，
第 1 个是 candidate_2，其余 default。依据是位置而不是节点自身属性——同一个节点换个候选位
就换个颜色。tone 只出现在查询响应里，绝不写回 db：一旦落库，换一组候选再搜时上一轮的
绿 / 蓝会残留在卡片上。mock 里有一条专门的测试钉住这点。

Ruling (选中的黄色优先于 tone): 用户明确要求。选中是用户此刻的操作焦点，tone 只是这次查询的
来源标记，前者盖住后者。判定收在 `nodeHighlight(tone, selected)` 这个纯函数里。
测试用候选节点而不是 default 节点验证覆盖——拿 default 测「黄色覆盖」等于什么都没测。

Ruling (tone 是不可信输入): 类型系统挡不住 JSON 里冒出来的第四个值。nodeHighlight 对
未知 tone 退回 default，避免 undefined 流进 style 直接抹掉边框色。

Ruling (高亮走 CSS 变量而非内联 borderColor): 边框、外发光、选中时的标题色都要用同一个颜色，
逐个写成内联样式会把同一个决定散到三处。E2E 断言的是浏览器算出的 border-color 而不是变量本身——
变量写对了但 CSS 没消费它，用户还是看不到颜色。

## 连线箭头

Ruling (箭头缺失的主因是没有 markerEnd，不是 padding 遮挡): 用户怀疑是卡片 padding 把箭头挡住了。
实际上 `toFlowEdges` 压根没设 `markerEnd`，React Flow 没有 marker 就完全不画箭头。
padding 确实也是一个真实问题（端点内缩 12px），但它不是箭头看不见的原因。两个都已修。

Ruling (箭头颜色只能从 JS 传): marker 由 React Flow 生成进 <defs>，取不到 `.priority-edge`
上的 stroke。于是同一个颜色天然存在 CSS 与 TS 两份（tokens.css 的 `--color-edge` 与
theme.ts 的 `EDGE_COLOR`），用一条测试读 CSS 文件把两者钉在一起。

## 字体与外部资源

Ruling (剔除 Google Fonts，改用系统字体栈): 用户要求构建产物不依赖任何联网资源。
删掉 index.html 的三行 link，tokens.css 改为各平台自带字体，antd 主题用 `var()` 指回
同一处而不是另存一份字体栈。已确认 dist 产物里不含任何外部域名。

Ruling (把「不引用外部资源」变成会红的测试): code review 守不住这条——一个指向
Google Fonts 的 <link> 在能联网的开发机上看不出任何异常，只有到了离线 / 内网环境才会
退化成默认字体。测试扫描 index.html 的 href/src 与所有 CSS 的 @import/url()。
已做变异验证：把 Google Fonts 塞回去确实会红。

## 工程

Ruling (dev server 独占 5273 且 strictPort): 本机另一个项目（mage）占着 5173，
Vite 默认静默顺延到 5174，而 playwright.config 的 `reuseExistingServer` 又会复用
5173 上那台服务——结果是 E2E 在测别人的应用，报错信息完全对不上。现在端口被占时宁可
启动失败，也不静默换端口。代价：改变了开发者习惯的 5173。

Ruling (tsconfig 给 src 加 "node" 类型): 有几条断言要读 index.html / tokens.css 这些源文件，
把跨文件约束变成会红的测试。代价：应用代码里也能看见 Node 全局变量了，
误用 `process.env` 之类不会被类型系统当场挡住。

## 第二轮的自我更正（代码审查后）

Ruling (更正：estimateNodeHeight 每行多算了 1px)【已修】: 本轮第一版把每条状态行算成
`ROW_HEIGHT + ROW_BORDER = 37`，理由是「每行带一条 1px 上边框」。这是错的：
global.css 里有全局 `* { box-sizing: border-box }`，`.status-node__row` 声明的
`height: 36px` 已经把 border-top 包在内，分隔线不额外占高度。

真实 Chromium 实测（用 offsetHeight，不受 React Flow 视口缩放影响）：
  TASK PROCESSOR(3 行)  198 = 2 + 88 + 3×36
  DECISION GATE (4 行)  234 = 2 + 88 + 4×36
  COMPLETE      (2 行)  162 = 2 + 88 + 2×36
其余常量（CARD_BORDER_Y、标题区各项）实测全对，错的精确就是那一项。

更糟的是当时还写了一条单测「每多一条状态固定长 37px」，把错误值钉成了正确值 ——
将来有人想修这 1px，这条测试反而会拦住他。这正是「断言实现算出来的值而不是
浏览器真实渲染的值」这种测试的典型危害。

代价与影响：高估方向是「比真实卡片更高」，Handle 走的是真实 DOM 位置，不会错位或被遮住；
但 dagre 用这个高度定位（y = 中心点 - height/2），状态行越多偏移越大。量级远小于
ranksep(160)/nodesep(60)，视觉上看不出来 —— 也正因为看不出来，才必须靠测试抓。

配套新增 E2E「卡片的真实高度构成与 layout.ts 的常量一致」：断言
`状态区高度 === 行数 × ROW_HEIGHT` 且 `整卡 === 外框 + 标题区 + 状态区`。
这两条都不涉及文字换行，跨平台确定。已做变异验证：把行高改成 37px 后确实报红
（Expected 108, Received 111）。metrics 的换行行数仍是估算（按字符数除以估算字宽），
真实换行点取决于字体度量，跨平台可能差一行 —— 这是刻意保留的近似，没有纳入断言。

教训：这一类「常量必须与 CSS 一一对应」的约束，手推一遍再写进注释是不够的。
注释里那句「公式与实际渲染因此完全对齐，残差归零」当时就是假的。必须实测，并且
把实测变成会红的测试。

Ruling (标题文字色也跟着 tone 走): 用户指出不一致 —— 候选节点只染了边框，
但选中时标题却会变黄，两套高亮各说各话。现在边框与标题同色：候选 1 绿、候选 2 蓝、
选中黄、非候选保持常规文字色。一张卡属于哪个候选，只应该有一个视觉信号。

实现上把 Highlight 的 `accent` 字段换成了语义明确的 `title`（`accent` 原本只有标题在用，
改名后没有其它消费者）。两个颜色都走 CSS 变量（`--node-highlight` / `--node-title`），
组件里不再有内联 color —— 顺带绕开了 jsdom 会把内联 color 的 hex 规范化成 rgb() 的麻烦。
对比度：三个颜色在 #0d161f 底上对 18px 600 字重（属大号文本，阈值 3:1）都远超标准。

Ruling (路由切换同步 document.title): 变成多页之后，读屏用户点了侧边栏除了 DOM 变化
没有任何「我现在在哪一页」的信号，容易以为点击没生效。标题由 AppShell 按 pathname
从 NAV_ITEMS 取，落在布局路由下却不在 NAV_ITEMS 里的路径只可能是 404。
产品名提取为 APP_NAME，顶栏与标题共用。
未做：路由切换后把焦点移到新页面标题。那是无障碍的另一半，但更容易做得烦人，
用户也没有提出这个需求，故留作已知缺口而不是悄悄实现。

Ruling (e2e 单独一个 tsconfig project): 新增的几何用例要在 page.evaluate 里用
document / HTMLElement，而这些回调是在浏览器里跑的。没有把 "DOM" 加到
tsconfig.node.json 上 —— 那样 vite.config.ts、playwright.config.ts 这些纯 Node 文件
误用浏览器全局时就不会报错了。新建 tsconfig.e2e.json 只给 e2e 放开 DOM。

Ruling (撤销给 src 加 "node" 类型，读源文件的测试挪到 tests/): 用户指出给 src 放开
Node 类型代价太大 —— 应用代码写 process.env / Buffer 不再当场报错，而那在浏览器里是
运行时直接炸的。现在 tsconfig.json 的 types 恢复为纯浏览器，需要 node:fs 的测试
挪到 tests/ 下，走 tsconfig.tests.json（含 "node"，不含 DOM）。
已验证守卫生效：往 src 里塞一句 process.env 会报 TS2591。

tests/ 下只剩 no-remote-assets.test.ts 一个文件，它不 import 任何 src 模块，
因此 tsconfig.tests.json 不需要引用主 project —— 这一点是必要的：composite project
之间互相引用会成环（tsconfig.json 引用 tests、tests 又要引用 tsconfig.json），
实测报 TS6202。

Ruling (色值一致性改由 E2E 比对实际渲染色，不再读源文件): 原来有一条测试读 tokens.css
和 theme.ts，断言 --color-edge 与 EDGE_COLOR 字符串相等。挪出 src 时它成了唯一需要
跨 project import 的文件，顺势重新想了一遍：真正要保证的性质是「箭头和连线看起来同色」，
而字符串相等只能证明两个字面量一样，证明不了画面上是一个颜色。

现在这条断言在 E2E 里：取连线 path 的 computed stroke 与 marker 内图形的 computed fill，
比对两者。已做变异验证 —— 只改 tokens.css 的 --color-edge 不改 theme.ts，
报 Expected "rgb(255, 0, 0)" / Received "rgb(81, 104, 126)"。

中途试过用 Vite 的 `?raw` 把 CSS 当字符串导入来绕开 node:fs，但 vitest 默认
css: false，`?raw` 拿到的是空字符串，行不通。记在这里免得以后有人重走一遍。

Ruling (删掉死 token --color-selected): 这是本轮自己加进 tokens.css 的，但选中色是经
StatusNode 注入 --node-highlight 下去的，CSS 侧没有任何地方引用它。多存一份只会变成
没人消费的死 token，将来改色时还会误导人以为改它就够了。

## 2026-09-19 接口动词、图对象标识、URL 单向、编辑交互

本轮六项改动的裁决。前三条是【后端契约】，写后端时必须读。

### 【后端契约】只有 GET 与 POST

Ruling: 后端只接受 GET 与 POST，因此 `putJson` / `deleteJson` 从 `api/client.ts` 整个删掉，
而不是留着不用——留着就是留一条会被后端直接拒掉的路，而失败点会远离出错的地方。
更新走 `POST /资源/:id`（与新建的 `POST /资源` 按路径区分），删除走 `POST /资源/:id/delete`
（没有能和更新区分开的 body，动作只能写在路径上）。

用户的原话只提到 PUT。DELETE 一并改掉，是因为「只接受 GET 和 POST」这个前提同样挡住 DELETE——
只改 PUT 会留下两个 DELETE 请求在真实后端上必然失败。
代价：若后端其实接受 DELETE，这两条路径多了个 `/delete` 后缀，改回去约 4 行。

### 【后端契约】每个请求都带 object_id / object_version

Ruling: 放查询串，GET 与 POST 一视同仁；由 `api/client.ts` 的 `buildUrl` 统一拼，
各调用点一个都不传。
- 选查询串而不是 body：这两个字段是定址信息不是业务载荷，放查询串就不用管每个接口 body
  的形状（删除类接口根本没有 body），网关 / 日志 / 权限中间件也不必解包 body 就能看到。
- 选集中注入而不是逐个透传：透传等于给每个调用点一次漏掉的机会，而漏掉是静默的——
  后端若宽容地按默认版本返回数据，界面看起来完全正常，用户却在改另一个版本的图。
代价：若将来某个接口**不该**带这两个字段，需要在 client 加一条豁免。

Ruling: mock 对缺失的标识返回 400，而不是宽容放行。
mock 是后端作者的实现说明书，这条约束必须真的挡住；失败要发生在开发期。
代价：开发时打开不带参数的 `/graph` 会在画布上看到「缺少图对象标识」。这是有意的信号，
不是故障；README 给了带参数的深链。

Ruling: 标识从 URL 同步进 api 层的动作放在**渲染期**（`useGraphObjectRefSync`），不放 effect。
React 的 effect 是子先父后，而真正发请求的 effect 住在子组件 SearchBar 里——
放进父组件 GraphPage 的 effect，首次加载那一发请求会赶在同步之前出去，正好漏掉标识。
写法是幂等的（值没变就不写），StrictMode 下重复渲染没有副作用。
有一条单测专门钉住「渲染函数返回时模块里已经有值」，改回 effect 实现会立刻变红。
代价：渲染期写模块状态不是常规写法，读代码的人需要看注释才知道为什么。

### URL 单向：只读不写

Ruling: 页面只从 URL 读查询参数，任何操作都不写回 URL。点「搜索」直接调 `searchGraph`。
连带删掉的东西：`commitQuery`、hop 越界时的写回 effect、以及 `nuqs` 依赖
（它解决的是双向绑定，现在没有这个需求；主 chunk 因此从 329.38 降到 328.71 kB gzip）。

一个意外的好处：旧实现里有个补丁——「查询失败后放开 lastKey 守卫，让用户原样再点一次
搜索能真的发出去」。请求不再经过 URL 之后，这个补丁连同它的两条测试一起没有了存在理由：
直接调用每次都会发。
代价：地址栏不再反映画布当前展示的内容。这正是用户要的（URL 是进入页面时那一份），
但如果将来想要「把当前视图分享给别人」，需要另加一个显式的「复制链接」动作。

### 保存节点前的二次确认

Ruling: 编辑模式下保存一律先确认；删了状态时升级为 danger 态，并**逐条列出**
被删的状态与被连带删除的边（用「实体·状态 → 实体·状态」说，不是 edge_id）。
只说「会影响边」等于没说：那些边连着别的节点，而那些节点在这个抽屉里根本看不见。
新建模式不确认——没有可破坏的东西。
代价：改个 metrics 也要多点一次。若嫌吵，把确认收窄到「有状态被删时」是一行的事。

### 边标签的摆法

Ruling: 做成 `localStorage` 里的三态设置（居左 / 居中 / 居右），默认居右。
不进 URL、不进后端：它是这台机器上这个人的看图习惯，换个人打开同一条深链，
应该看到他自己习惯的摆法。

Ruling: 锚点按**弧长**从 React Flow 生成的路径字符串里解析并计算，不抄一份
`getBezierPath` 的控制点算法。那份算法是 React Flow 的内部细节，抄一份就是埋一个
会随版本漂移、且漂移时毫无信号的副本；路径是它的输出，永远是对的。
按弧长而不是按参数 `t` 取点，是因为两者不是线性关系——直接取 `t=0.8` 在弯度大的边上
会明显偏离「离箭头 22px」这个意图。
代价：React Flow 若改成非三次贝塞尔的路径形状，`parseCubicPath` 会返回 null，
标签退回中点——退化是安全的，但届时需要跟着改。

Ruling: 退化边（两端重合、或短于 1px）退回中点，阈值写成 `total < 1` 而不是 `total === 0`。
两端重合时贝塞尔求值会留下浮点残渣（4.999… / 5.000…1），弧长是个非零的极小值，
写成 `=== 0` 这条退路实际永远走不到。这是写测试时才发现的。

Ruling（范围外但必须修）: 边标签改成真 `<button>`，点它等于点这条边。
它本来就带 `pointer-events: all` 和 `cursor: pointer` 却没有任何点击处理——
压在连线上把本该落到边上的点击全吃掉：指针变成手形、点下去什么都不发生。
这个缺陷在标签居中时就存在，是新加的 E2E 用例撞出来的。顺带也就键盘可达了。

### 边编辑弹窗显示实体名

Ruling: 标题改成「实体 → 实体」加一行「状态描述 → 状态描述」，不再显示 node / status id。
两行都要：同两个节点之间可以有好几条边，只说实体分不出是哪一条。
节点或状态不在图里时退回显示 id 而不是空白——「? → ?」什么也说明不了，
id 至少能让人去库里查这条边挂在哪。
翻译逻辑抽成 `lib/adapters.ts` 的 `describeEdgeEndpoints`，边弹窗与节点保存确认框共用。

## 2026-09-19 下拉行、边标签摆法内置化、发版入口

Ruling: 搜索下拉行只展示 entity 与 metrics，去掉 node_id。
node_id 在画布卡片上从不显示（见 StatusNode 的注释），下拉里摆一个别处见不到的标识，
对正在挑节点的人没有意义，只会把真正要读的两行挤窄。
关键字**仍然**匹配 node_id（mock 的 search handler 不变），只是不上屏——
知道 id 的人还能照常搜到。
顺带调了排版：entity 领起（强色、加粗），metrics 补充（弱色、小一号），拉开层次。

Ruling: 边标签摆法从「界面上的三态开关 + localStorage」收敛成 `lib/edgeLabel.ts` 里的
一个常量 `EDGE_LABEL_PLACEMENT`，默认 `'right'`。
连带删掉的东西：EdgeLabelPlacementControl 组件与它的测试、useUiStore 里的
`edgeLabelPlacement` 状态与 localStorage 读写、graph.css 里切换器的样式、
`isEdgeLabelPlacement` 与 `EDGE_LABEL_PLACEMENTS`（只为校验 localStorage 脏值而存在，
没有持久化就没有脏值）。
`edgeLabelPoint` 仍然支持三种摆法，并有一条用例钉住「三个取值都算得出落在连线上的锚点」——
常量一改就该立刻生效，不能有哪一种是坏的。
代价：换摆法要改代码、重新构建。这正是用户要的（他只需要一个内置开关），
但如果将来想让用户自己选，把这个常量换回 store 即可，几何部分不用动。

Ruling: 工具条加「发版」按钮，接口未定，`onClick` 先给一句「发版功能尚未接入」。
不留空 `onClick`——按得动却毫无反应的按钮和坏掉的按钮长得一模一样。
接上真实接口时替换那一行即可，按钮本身不用动。
样式上与「+ 新建节点」并列成一对次要操作（同一套深底 + 同色描边与文字），
只换色相：新建是增量的绿，发版是「这一步对外生效」的琥珀。两者都不做成 primary——
那个位置留给搜索，一条工具条上只该有一个主操作。

## 2026-09-19 修正：POST 的图对象标识改放 payload

Ruling（推翻前一条）: 前一轮把 object_id / object_version 统一放查询串（GET 与 POST 都是），
理由是「定址信息、不用管 body 形状、中间件不解包就能看到」。后端不接受这个形状，
要求 POST 统一放 payload。这是后端的契约，按后端来。

现在的约定：
- `GET`：查询串，和其它查询条件放一起（没有 body，也只能这样）
- `POST`：payload，URL 上不再出现这两个参数

差异集中在 `api/client.ts` 的 `getJson` / `postJson` 两行里，业务模块一律只传业务载荷。

Ruling: 不做「两头都塞一份」的兼容。同一个事实有两个来源，两边对不上时谁说了算没有定论。
mock 因此把「POST 只在 URL 上带标识」判成没带（400），有一条用例专门钉住这点。
代价：后端若改口说想两边都读，得回来改 client 与 mock 两处。

Ruling: `postJson` 的 body 类型从 `unknown` 收紧到 `object`。
标识要合并进 body，传数组或基本类型会展开成 `{ 0: …, 1: … }` 这种 payload——
不报错，但没人看得懂。类型上挡住比运行时再查便宜。

Ruling: 标识在展开的**最后一位**（`{ ...body, ...objectParams() }`）。
它是这次请求作用在哪张图哪个版本上的权威来源，业务载荷里万一有同名字段不该盖过它。
有用例钉住。

Ruling（【后端契约】）: 服务端收到 POST 后必须把这两个字段从业务载荷里摘掉再落库，
mock 里是 `withoutScope`。不摘的话，节点 / 边 / 文档上会多出两个谁也没声明过的键，
下次读出来又原样发回前端——字段就这样凭空长进了数据模型。
这是改动中最容易漏的一处：`{ ...payload }` 这类写法会把它们一起带进实体里，
而且界面上完全看不出来。两条用例钉住（新建节点不长出这两个键、文档保存后仍是 7 个字段）。

import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './e2e',
  use: { baseURL: 'http://localhost:5173', trace: 'on-first-retry' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  // 注意：reuseExistingServer 只探测这个 url 有没有响应，不校验响应的是不是本应用。
  // 本机另一个项目的 Vite dev server 恰好占着 5173 时，Playwright 会直接复用它，
  // 于是 E2E 在测别人的应用，报错信息完全对不上（表现为大批定位器找不到元素）。
  // 撞上时先确认 5173 上跑的是谁。
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !process.env.CI,
  },
})

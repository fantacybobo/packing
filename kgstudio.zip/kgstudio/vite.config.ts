import { configDefaults, defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'node:path'

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, './src') } },
  test: {
    environment: 'jsdom',
    environmentOptions: { jsdom: { url: 'http://localhost:3000' } },
    setupFiles: ['./src/test/setup.ts'],
    globals: true,
    // e2e/ 下是 Playwright 的用例，文件名同样以 .spec.ts 结尾，
    // 不排除的话会被 vitest 的默认 glob 一并捡起来跑，两套 test() runtime 冲突报错。
    exclude: [...configDefaults.exclude, 'e2e/**'],
    coverage: { provider: 'v8', reporter: ['text', 'html'] },
  },
})

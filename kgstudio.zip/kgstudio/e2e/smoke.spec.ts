import { test, expect } from '@playwright/test'

test('搜索 → 出图 → 打开文档抽屉', async ({ page }) => {
  await page.goto('/')

  // 首屏是空态引导
  await expect(page.getByText('在上方输入关键字选择节点，点「搜索」开始')).toBeVisible()

  // 搜索按钮限定在搜索工具栏容器内。左侧图标栏曾经有一个同名的装饰性「搜索」按钮，
  // 现在那些装饰项已经不是控件、也不在无障碍树里，这个限定不再是唯一挡住
  // strict-mode 冲突的东西 —— 留着只是因为「按容器取控件」本身就更稳。
  const searchBar = page.locator('.search-bar')
  const searchButton = searchBar.getByRole('button', { name: '搜索' })

  // 候选一为空时搜索不可点
  await expect(searchButton).toBeDisabled()

  // 选中候选一
  await page.getByLabel('候选节点 1').click()
  await page.keyboard.type('TASK')
  await page.getByText('TASK PROCESSOR').first().click()

  await searchButton.click()

  // 图渲染出来，且 URL 记录了这次查询
  // 用 heading 角色定位画布上的节点标题：候选框下拉的选项文案里也含
  // 「TASK PROCESSOR」，antd 下拉关闭后其 DOM 节点会带动画延迟卸载，
  // 用 getByText 有时会撞上残留节点造成 strict-mode 冲突；节点标题是唯一的 <h3>。
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()
  await expect(page).toHaveURL(/nodes=N01/)

  // 打开文档抽屉
  await page.getByRole('button', { name: '节点文档' }).first().click()
  await expect(page.getByText('NODE DOCUMENT')).toBeVisible()
  await expect(page.getByText(/任务队列可读/)).toBeVisible()
})

test('拖出连线只打开边弹窗，取消后不会留下边', async ({ page }) => {
  // 这条保证（服务器确认前不建边）在 jsdom 里无法测：React Flow 的连线要真实拖拽。
  // Playwright 能真拖，所以放在 E2E 层。
  await page.goto('/?nodes=N01&hop=2')
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const edgeCountBefore = await page.locator('.react-flow__edge').count()

  // 从 N01 第一行状态的右侧 source handle 拖到 N04 第一行状态的左侧 target handle
  // React Flow 12 把节点 id 放在 data-id 上（实测确认，不是 data-nodeid）
  const source = page.locator('.react-flow__node[data-id="N01"] .react-flow__handle-right').first()
  const target = page.locator('.react-flow__node[data-id="N04"] .react-flow__handle-left').first()

  const sourceBox = await source.boundingBox()
  const targetBox = await target.boundingBox()
  if (!sourceBox || !targetBox) throw new Error('handle bounding box not found')
  const sourcePoint = { x: sourceBox.x + sourceBox.width / 2, y: sourceBox.y + sourceBox.height / 2 }
  const targetPoint = { x: targetBox.x + targetBox.width / 2, y: targetBox.y + targetBox.height / 2 }

  // dragTo 只发 down/move/up 三步；React Flow 的连线需要中间移动帧才会触发，
  // 所以这里手动分步，途中经过一个中点，模拟真实拖拽轨迹。
  await page.mouse.move(sourcePoint.x, sourcePoint.y)
  await page.mouse.down()
  await page.mouse.move(
    (sourcePoint.x + targetPoint.x) / 2,
    (sourcePoint.y + targetPoint.y) / 2,
    { steps: 5 },
  )
  await page.mouse.move(targetPoint.x, targetPoint.y, { steps: 5 })
  await page.mouse.up()

  // 弹窗出现，但边还没建
  await expect(page.getByText('NEW EDGE')).toBeVisible()
  expect(await page.locator('.react-flow__edge').count()).toBe(edgeCountBefore)

  // 关掉弹窗后依然没有新边
  // antd Modal 自带的右上角关闭图标在 zhCN locale 下无障碍名也是「关闭」，
  // 与弹窗底部的显式按钮同名，所以限定在 footer 容器内取按钮，避免 strict-mode 命中两个元素。
  await page.locator('.panel__footer').getByRole('button', { name: '关闭' }).click()
  await expect(page.getByText('NEW EDGE')).not.toBeVisible()
  expect(await page.locator('.react-flow__edge').count()).toBe(edgeCountBefore)
})

test('深链直接进入即可还原图', async ({ page }) => {
  await page.goto('/?nodes=N01&hop=1')
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()
  await expect(page.getByRole('heading', { name: 'DECISION GATE' })).toBeVisible()
  await expect(page.getByLabel('跳数')).toHaveValue('1')
})

test('换一批节点后画布重新取景，不会把更大的图裁在视口外', async ({ page }) => {
  // <ReactFlow fitView /> 只在初始化时生效一次，所以「第二次搜索没有重新取景」
  // 在 jsdom 里测不出来：那里没有真实的尺寸测量，viewport 的 transform 恒为初始值。
  await page.goto('/?nodes=N01&hop=1')
  await expect(page.getByRole('heading', { name: 'TASK PROCESSOR' })).toBeVisible()

  const viewport = page.locator('.react-flow__viewport')
  await expect(viewport).toHaveAttribute('style', /scale/)
  const before = await viewport.getAttribute('style')

  // hop 调到 6：子图从 2 个节点变成 4 个，必须重新 fit
  const hop = page.getByLabel('跳数')
  await hop.fill('6')
  await page.locator('.search-bar').getByRole('button', { name: '搜索' }).click()

  await expect(page.getByRole('heading', { name: 'COMPLETE' })).toBeVisible()
  await expect.poll(() => viewport.getAttribute('style')).not.toBe(before)
})


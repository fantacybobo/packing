import { http, HttpResponse } from 'msw'
import { db, expandGraph, nextEdgeId, nextNodeId, nextStatusId } from './db'
import type { EdgePayload, GraphEdge, GraphNode, NodePayload, NodeDocument } from '@/types/graph'

const ok = <T>(data: T) => HttpResponse.json({ success: true, data, error: null })
const fail = (error: string, status: number) =>
  HttpResponse.json({ success: false, data: null, error }, { status })

// —— 写接口的校验 ——
// 读接口（POST /api/graph/query）按 spec 挡住了边界，写接口原本什么都不查：
// POST /api/edges 会愉快地收下引用不存在节点/状态的边，正是 Item 1 那种孤儿边的
// 服务端来源。mock 是后端作者的实现说明书，这些约束必须写在这里。
// 前端 canvasPolicy 同样拦自环与重复边 —— 那是有意的纵深防御，不是可以合并掉的重复。

const isFilled = (value: unknown) => typeof value === 'string' && value.trim().length > 0

const nodeError = (payload: NodePayload): string | null => {
  if (!isFilled(payload?.entity)) return 'entity 不能为空'
  if (!isFilled(payload?.metrics)) return 'metrics 不能为空'
  return null
}

const DOCUMENT_FIELDS: (keyof NodeDocument)[] = [
  'document_id', 'prerequisite', 'check_question',
  'evaluation_method', 'description', 'flow_reason', 'remark',
]

const documentError = (payload: NodeDocument): string | null => {
  // spec §5：文档更新是全量 PUT，7 个字段一个都不能少（允许为空串，用户可以清空备注）
  const missing = DOCUMENT_FIELDS.filter(field => typeof payload?.[field] !== 'string')
  return missing.length > 0 ? `文档更新必须全量回传 7 个字段，缺少：${missing.join('、')}` : null
}

const sameEndpoints = (edge: GraphEdge, payload: EdgePayload) =>
  edge.from_node_id === payload.from_node_id &&
  edge.to_node_id === payload.to_node_id &&
  edge.from_status_id === payload.from_status_id &&
  edge.to_status_id === payload.to_status_id

/** 返回 [错误文案, HTTP 状态]，合法时返回 null。ignoreEdgeId 用于「编辑时不跟自己比重复」 */
function edgeError(payload: EdgePayload, ignoreEdgeId?: string): [string, number] | null {
  const from = db.nodes.find(n => n.node_id === payload?.from_node_id)
  const to = db.nodes.find(n => n.node_id === payload?.to_node_id)
  if (!from || !to) return ['边引用的节点不存在', 400]
  if (!from.status_list.some(s => s.status_id === payload.from_status_id)) {
    return ['from_status_id 不属于 from_node_id', 400]
  }
  if (!to.status_list.some(s => s.status_id === payload.to_status_id)) {
    return ['to_status_id 不属于 to_node_id', 400]
  }
  // status_id 全局唯一（带 node 前缀），相等即同一个状态
  if (payload.from_status_id === payload.to_status_id) return ['不能把一个状态连到它自己', 400]
  if (db.edges.some(e => e.edge_id !== ignoreEdgeId && sameEndpoints(e, payload))) {
    return ['这两个状态之间已经有一条边了', 409]
  }
  return null
}

export const handlers = [
  http.get('*/api/nodes/search', ({ request }) => {
    const q = (new URL(request.url).searchParams.get('q') ?? '').trim().toLowerCase()
    const matched = q
      ? db.nodes.filter(n => `${n.entity} ${n.metrics} ${n.node_id}`.toLowerCase().includes(q))
      : db.nodes
    return ok(matched)
  }),

  http.post('*/api/graph/query', async ({ request }) => {
    const body = (await request.json()) as { node_ids?: string[]; hop?: number }
    const nodeIds = body.node_ids ?? []
    const hop = body.hop ?? 2
    // mock 同时是给后端看的契约文档，spec 写明的边界必须真的挡住：
    // 否则前端的 clamp 逻辑一旦回退，开发期不会有任何信号。
    if (nodeIds.length < 1 || nodeIds.length > 2) return fail('node_ids 长度必须为 1 或 2', 400)
    if (!Number.isInteger(hop) || hop < 1 || hop > 6) return fail('hop 必须是 1 到 6 的整数', 400)
    return ok(expandGraph(nodeIds, hop))
  }),

  http.post('*/api/nodes', async ({ request }) => {
    const payload = (await request.json()) as NodePayload
    const invalid = nodeError(payload)
    if (invalid) return fail(invalid, 400)
    const nodeId = nextNodeId()
    const node: GraphNode = {
      node_id: nodeId,
      entity: payload.entity,
      metrics: payload.metrics,
      tone: 'default',
      document_id: [],
      status_list: payload.status_list.map(s => ({
        status_id: nextStatusId(nodeId),
        node_id: nodeId,
        status_description: s.status_description,
      })),
    }
    db.nodes = [...db.nodes, node]
    return ok(node)
  }),

  http.put('*/api/nodes/:nodeId', async ({ params, request }) => {
    const nodeId = params.nodeId as string
    const existing = db.nodes.find(n => n.node_id === nodeId)
    if (!existing) return fail('节点不存在', 404)
    const payload = (await request.json()) as NodePayload
    const invalid = nodeError(payload)
    if (invalid) return fail(invalid, 400)
    const updated: GraphNode = {
      ...existing,
      entity: payload.entity,
      metrics: payload.metrics,
      status_list: payload.status_list.map(s => ({
        // 新增的状态没有 status_id，由后端生成；格式与种子数据保持一致
        status_id: s.status_id ?? nextStatusId(nodeId),
        node_id: nodeId,
        status_description: s.status_description,
      })),
    }
    db.nodes = db.nodes.map(n => (n.node_id === nodeId ? updated : n))
    // 状态行被删掉时，挂在它上面的边必须跟着级联删除 —— 与 DELETE /api/nodes 同一条规则。
    // 否则库里留下引用已不存在 status_id 的孤儿边：前端的 sourceHandle/targetHandle
    // 挂不到任何 handle 上，边从画布上消失，却仍然躺在库里，谁也看不到、删不掉。
    const liveStatusIds = new Set(updated.status_list.map(s => s.status_id))
    const orphaned = (e: GraphEdge) =>
      (e.from_node_id === nodeId && !liveStatusIds.has(e.from_status_id)) ||
      (e.to_node_id === nodeId && !liveStatusIds.has(e.to_status_id))
    db.edges = db.edges.filter(e => !orphaned(e))
    return ok(updated)
  }),

  http.delete('*/api/nodes/:nodeId', ({ params }) => {
    const nodeId = params.nodeId as string
    if (!db.nodes.some(n => n.node_id === nodeId)) return fail('节点不存在', 404)
    const removed = db.edges.filter(e => e.from_node_id === nodeId || e.to_node_id === nodeId)
    db.nodes = db.nodes.filter(n => n.node_id !== nodeId)
    db.edges = db.edges.filter(e => !removed.includes(e))
    return ok({ deleted_edge_ids: removed.map(e => e.edge_id) })
  }),

  http.post('*/api/edges', async ({ request }) => {
    const payload = (await request.json()) as EdgePayload
    const invalid = edgeError(payload)
    if (invalid) return fail(...invalid)
    const edge: GraphEdge = { ...payload, tone: 'default', edge_id: nextEdgeId() }
    db.edges = [...db.edges, edge]
    return ok(edge)
  }),

  http.put('*/api/edges/:edgeId', async ({ params, request }) => {
    const edgeId = params.edgeId as string
    const existing = db.edges.find(e => e.edge_id === edgeId)
    if (!existing) return fail('边不存在', 404)
    const payload = (await request.json()) as EdgePayload
    const invalid = edgeError(payload, edgeId)
    if (invalid) return fail(...invalid)
    const updated: GraphEdge = { ...existing, ...payload, tone: 'default' }
    db.edges = db.edges.map(e => (e.edge_id === edgeId ? updated : e))
    return ok(updated)
  }),

  http.delete('*/api/edges/:edgeId', ({ params }) => {
    const edgeId = params.edgeId as string
    if (!db.edges.some(e => e.edge_id === edgeId)) return fail('边不存在', 404)
    db.edges = db.edges.filter(e => e.edge_id !== edgeId)
    return ok({ edge_id: edgeId })
  }),

  http.get('*/api/documents/:documentId', ({ params }) => {
    const doc = db.documents.find(d => d.document_id === params.documentId)
    return doc ? ok(doc) : fail('文档不存在', 404)
  }),

  http.put('*/api/documents/:documentId', async ({ params, request }) => {
    const documentId = params.documentId as string
    if (!db.documents.some(d => d.document_id === documentId)) return fail('文档不存在', 404)
    const payload = (await request.json()) as NodeDocument
    const invalid = documentError(payload)
    if (invalid) return fail(invalid, 400)
    const updated: NodeDocument = { ...payload, document_id: documentId }
    db.documents = db.documents.map(d => (d.document_id === documentId ? updated : d))
    return ok(updated)
  }),
]

export type Tone = 'default'

export interface NodeStatus {
  status_id: string
  node_id: string
  status_description: string
}

export interface GraphNode {
  node_id: string
  entity: string
  metrics: string
  tone: Tone
  document_id: string[]
  status_list: NodeStatus[]
}

export interface GraphEdge {
  edge_id: string
  from_node_id: string
  to_node_id: string
  from_status_id: string
  to_status_id: string
  priority: number
  tone: Tone
}

export interface NodeDocument {
  document_id: string
  prerequisite: string
  check_question: string
  evaluation_method: string
  description: string
  flow_reason: string
  remark: string
}

/** 新建状态时没有 status_id，由后端生成 */
export interface NodeStatusDraft {
  status_id?: string
  status_description: string
}

export interface NodePayload {
  entity: string
  metrics: string
  tone: Tone
  status_list: NodeStatusDraft[]
}

export interface EdgePayload {
  from_node_id: string
  to_node_id: string
  from_status_id: string
  to_status_id: string
  priority: number
  tone: Tone
}

export interface GraphQueryRequest {
  node_ids: string[]
  hop: number
}

export interface GraphQueryResponse {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

export interface ApiEnvelope<T> {
  success: boolean
  data: T | null
  error: string | null
}

import { describe, it, expect } from 'vitest'
import { antdTheme, TONE_COLORS } from './theme'

describe('antdTheme', () => {
  it('使用设计稿的画布底色作为全局背景', () => {
    expect(antdTheme.token?.colorBgBase).toBe('#070c12')
  })

  it('容器背景与边框取自设计稿', () => {
    expect(antdTheme.token?.colorBgContainer).toBe('#0d151d')
    expect(antdTheme.token?.colorBorder).toBe('#23323f')
  })

  it('正文与等宽字体各一套，共两套', () => {
    expect(antdTheme.token?.fontFamily).toContain('IBM Plex Sans')
    expect(antdTheme.token?.fontFamilyCode).toContain('JetBrains Mono')
  })
})

describe('TONE_COLORS', () => {
  it('default tone 有可用的边框与强调色', () => {
    expect(TONE_COLORS.default.border).toBe('#233442')
    expect(TONE_COLORS.default.accent).toBe('#4ade80')
  })
})

import { describe, it, expect, beforeEach } from 'vitest'
import { delay, http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { expandGraph } from '@/mocks/db'
import { useGraphStore } from './useGraphStore'

const store = () => useGraphStore.getState()

beforeEach(() => store().reset())

describe('searchGraph', () => {
  it('成功后填充 nodes、edges 与坐标，并进入 ready 态', async () => {
    await store().searchGraph(['N01'], 1)
    expect(store().status).toBe('ready')
    expect(store().nodes.map(n => n.node_id).sort()).toEqual(['N01', 'N02'])
    expect(store().positions.N01).toBeDefined()
  })

  it('hop 更大时拿到更多节点', async () => {
    await store().searchGraph(['N01'], 1)
    const few = store().nodes.length
    await store().searchGraph(['N01'], 3)
    expect(store().nodes.length).toBeGreaterThan(few)
  })

  it('失败时进入 error 态并保留可读错误文案', async () => {
    server.use(http.post('*/api/graph/query', () =>
      HttpResponse.json({ success: false, data: null, error: '后端炸了' }, { status: 500 })))
    await store().searchGraph(['N01'], 2)
    expect(store().status).toBe('error')
    expect(store().error).toBe('后端炸了')
  })

  it('查询失败时清空上一次的结果，而不是留着旧图', async () => {
    // 必须先查成功一次再查失败：若从空 store 起跑，
    // 「nodes 为空」这条断言在「失败时不清空」的错误实现下同样成立，等于没测。
    await store().searchGraph(['N01'], 3)
    expect(store().nodes.length).toBeGreaterThan(0)

    server.use(http.post('*/api/graph/query', () =>
      HttpResponse.json({ success: false, data: null, error: '后端炸了' }, { status: 500 })))
    await store().searchGraph(['N02'], 1)

    expect(store().status).toBe('error')
    expect(store().nodes).toEqual([])
    expect(store().edges).toEqual([])
    expect(store().positions).toEqual({})
  })

  // 两次查询乱序返回时，晚到的旧响应必须整条丢掉。现实触发点是浏览器前进后退连点
  // （搜索按钮在 loading 期间被锁住，但 URL 驱动的历史导航没有这层锁）。
  // MSW 下必须手工造延迟，否则永远按发出顺序返回，接上真实后端前这问题不会显形。
  const respondWith = (
    decide: (nodeIds: string[]) => { slow: boolean; fail?: boolean },
  ) =>
    server.use(http.post('*/api/graph/query', async ({ request }) => {
      const body = (await request.json()) as { node_ids: string[]; hop: number }
      const { slow, fail } = decide(body.node_ids)
      if (slow) await delay(60)
      if (fail) {
        return HttpResponse.json({ success: false, data: null, error: '后端炸了' }, { status: 500 })
      }
      return HttpResponse.json({
        success: true, error: null, data: expandGraph(body.node_ids, body.hop),
      })
    }))

  it('先发的查询晚到时，不会覆盖后发查询的结果', async () => {
    respondWith(nodeIds => ({ slow: nodeIds.includes('N01') }))

    const first = store().searchGraph(['N01'], 1)
    const second = store().searchGraph(['N04'], 1)
    await Promise.all([first, second])

    // N04 一跳可达 N02/N03/N04，完全不含 N01：旧响应若赢了，这里立刻能看出来
    expect(store().nodes.map(n => n.node_id).sort()).toEqual(['N02', 'N03', 'N04'])
    expect(store().status).toBe('ready')
  })

  it('先发的查询失败且晚到时，不会把后发查询的成功结果清空', async () => {
    // 这条比上一条更凶：失败分支写的是 { ...initial }，晚到的失败会把画布整个清空，
    // 还配上一条与当前 URL 毫无关系的错误提示。
    respondWith(nodeIds => ({ slow: nodeIds.includes('N01'), fail: nodeIds.includes('N01') }))

    const first = store().searchGraph(['N01'], 1)
    const second = store().searchGraph(['N04'], 1)
    await Promise.all([first, second])

    expect(store().status).toBe('ready')
    expect(store().error).toBeNull()
    expect(store().nodes.map(n => n.node_id).sort()).toEqual(['N02', 'N03', 'N04'])
  })

  it('再次查询整体重算坐标，上一次的节点不会残留在 positions 里', async () => {
    await store().searchGraph(['N01'], 1)
    expect(Object.keys(store().positions)).toContain('N01')

    // N04 一跳可达 N02/N03/N04，不含 N01：若实现把 positions 合并而非替换，N01 会残留
    await store().searchGraph(['N04'], 1)
    expect(store().nodes.some(n => n.node_id === 'N01')).toBe(false)
    expect(store().positions.N01).toBeUndefined()
  })
})

describe('节点写操作', () => {
  beforeEach(async () => { await store().searchGraph(['N01'], 3) })

  it('新建成功后节点进入 store 并获得坐标', async () => {
    const before = store().nodes.length
    const created = await store().createNode({
      entity: 'NEW', metrics: '新描述', tone: 'default',
      status_list: [{ status_description: 'Pending' }],
    })
    expect(store().nodes).toHaveLength(before + 1)
    expect(store().positions[created.node_id]).toBeDefined()
  })

  it('新建节点不会扰动已有节点的坐标', async () => {
    // spec 要求新节点用 placeNewNode 落位，而不是整图重排 ——
    // 若退化成 layoutGraph([...nodes, created])，每次新建都会让整个画布跳动。
    const before = { ...store().positions }
    const created = await store().createNode({
      entity: 'NEW', metrics: '新描述', tone: 'default',
      status_list: [{ status_description: 'Pending' }],
    })
    // 必须用 toBe（引用相等）而非 toEqual：
    // 正确实现是 { ...s.positions, [新节点]: ... }，已有条目的值对象原样保留；
    // 整图重排则会为每个节点新建 {x,y} 对象。实测在当前 4 节点种子图上，
    // 「追加新节点后重排」算出的已有坐标与原值逐字节相同 —— toEqual 抓不到，toBe 能。
    for (const [nodeId, position] of Object.entries(before)) {
      expect(store().positions[nodeId]).toBe(position)
    }
    expect(store().positions[created.node_id]).toBeDefined()
  })

  it('新建失败时 store 完全不变', async () => {
    server.use(http.post('*/api/nodes', () =>
      HttpResponse.json({ success: false, data: null, error: '校验失败' }, { status: 400 })))
    const snapshot = store().nodes
    await expect(store().createNode({
      entity: 'X', metrics: 'Y', tone: 'default', status_list: [],
    })).rejects.toThrow('校验失败')
    expect(store().nodes).toBe(snapshot)
  })

  it('编辑成功后用响应覆盖本地节点', async () => {
    await store().updateNode('N01', {
      entity: 'RENAMED', metrics: '改过的', tone: 'default',
      status_list: [{ status_id: 'N01-ST01', status_description: 'Pending' }],
    })
    expect(store().nodes.find(n => n.node_id === 'N01')?.entity).toBe('RENAMED')
  })

  it('编辑失败时 store 完全不变', async () => {
    server.use(http.put('*/api/nodes/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '冲突' }, { status: 409 })))
    const snapshot = store().nodes
    await expect(store().updateNode('N01', {
      entity: 'X', metrics: 'Y', tone: 'default', status_list: [],
    })).rejects.toThrow('冲突')
    expect(store().nodes).toBe(snapshot)
  })

  it('编辑时删掉一行状态，挂在这行状态上的边也从 store 一并清掉', async () => {
    // 这是 Item 1 的核心：边的 sourceHandle/targetHandle 指向 status_id。
    // 状态没了而边还在，React Flow 挂不上 handle —— 边从画布上消失，
    // 却还留在 store 里，用户再也点不到、删不掉。
    expect(store().edges.some(e => e.from_status_id === 'N01-ST01')).toBe(true)

    await store().updateNode('N01', {
      entity: 'TASK PROCESSOR', metrics: '从队列拉取待处理任务。', tone: 'default',
      status_list: [
        { status_id: 'N01-ST02', status_description: 'Running' },
        { status_id: 'N01-ST03', status_description: 'Active' },
      ],
    })

    expect(store().edges.some(
      e => e.from_status_id === 'N01-ST01' || e.to_status_id === 'N01-ST01',
    )).toBe(false)
    // 级联不能扩大化：留下来的状态上的边、以及与 N01 无关的边都必须原样保留
    expect(store().edges.map(e => e.edge_id)).toEqual(
      expect.arrayContaining(['E002', 'E003', 'E004']),
    )
  })

  it('被删状态位于边的 to 侧时同样级联', async () => {
    // E001 是 N01-ST01 → N02-ST01（N02-ST01 在 to 侧），
    // E004 是 N02-ST01 → N03-ST01（同一个状态在 from 侧）：一次改动覆盖两个方向。
    await store().updateNode('N02', {
      entity: 'DECISION GATE', metrics: '按重试次数与超时阈值分流。', tone: 'default',
      status_list: [
        { status_id: 'N02-ST02', status_description: 'Active' },
        { status_id: 'N02-ST03', status_description: 'Failed' },
        { status_id: 'N02-ST04', status_description: 'Inactive' },
      ],
    })

    const ids = store().edges.map(e => e.edge_id)
    expect(ids).not.toContain('E001')
    expect(ids).not.toContain('E004')
    expect(ids).toEqual(expect.arrayContaining(['E002', 'E003']))
  })

  it('删除节点时按响应里的 id 一并清掉相连的边与坐标', async () => {
    await store().deleteNode('N01')
    expect(store().nodes.some(n => n.node_id === 'N01')).toBe(false)
    expect(store().edges.some(e => e.from_node_id === 'N01' || e.to_node_id === 'N01')).toBe(false)
    expect(store().positions.N01).toBeUndefined()
  })

  it('后端未报告 deleted_edge_ids 时，仍按本地关系清理相连的边', async () => {
    // 覆盖「后端对 DELETE 返回空体」这种常见写法：不能留下指向已删节点的孤儿边
    server.use(http.delete('*/api/nodes/:id', () =>
      HttpResponse.json({ success: true, data: null, error: null })))
    await store().deleteNode('N01')
    expect(store().nodes.some(n => n.node_id === 'N01')).toBe(false)
    expect(store().edges.some(e => e.from_node_id === 'N01' || e.to_node_id === 'N01')).toBe(false)
  })

  it('删除失败时节点与边都保留', async () => {
    server.use(http.delete('*/api/nodes/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '有引用' }, { status: 409 })))
    const nodes = store().nodes
    const edges = store().edges
    await expect(store().deleteNode('N01')).rejects.toThrow('有引用')
    expect(store().nodes).toBe(nodes)
    expect(store().edges).toBe(edges)
  })
})

describe('边写操作', () => {
  beforeEach(async () => { await store().searchGraph(['N01'], 3) })

  it('新建边成功后进入 store', async () => {
    const before = store().edges.length
    await store().createEdge({
      from_node_id: 'N01', to_node_id: 'N04',
      from_status_id: 'N01-ST01', to_status_id: 'N04-ST01',
      priority: 3, tone: 'default',
    })
    expect(store().edges).toHaveLength(before + 1)
  })

  it('新建边失败时 store 完全不变', async () => {
    server.use(http.post('*/api/edges', () =>
      HttpResponse.json({ success: false, data: null, error: '边非法' }, { status: 400 })))
    const snapshot = store().edges
    await expect(store().createEdge({
      from_node_id: 'N01', to_node_id: 'N04',
      from_status_id: 'N01-ST01', to_status_id: 'N04-ST01',
      priority: 3, tone: 'default',
    })).rejects.toThrow('边非法')
    expect(store().edges).toBe(snapshot)
  })

  it('编辑边成功后 priority 被更新', async () => {
    await store().updateEdge('E001', {
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 99, tone: 'default',
    })
    expect(store().edges.find(e => e.edge_id === 'E001')?.priority).toBe(99)
  })

  it('编辑边失败时 store 完全不变', async () => {
    server.use(http.put('*/api/edges/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '冲突' }, { status: 409 })))
    const snapshot = store().edges
    await expect(store().updateEdge('E001', {
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 99, tone: 'default',
    })).rejects.toThrow('冲突')
    expect(store().edges).toBe(snapshot)
  })

  it('删除边成功后从 store 移除', async () => {
    await store().deleteEdge('E001')
    expect(store().edges.some(e => e.edge_id === 'E001')).toBe(false)
  })

  it('删除边失败时 store 完全不变', async () => {
    server.use(http.delete('*/api/edges/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '有引用' }, { status: 409 })))
    const snapshot = store().edges
    await expect(store().deleteEdge('E001')).rejects.toThrow('有引用')
    expect(store().edges).toBe(snapshot)
  })
})

describe('setNodePosition', () => {
  it('只改目标节点的坐标，不动其他节点', async () => {
    await store().searchGraph(['N01'], 1)
    const others = Object.entries(store().positions).filter(([id]) => id !== 'N01')

    store().setNodePosition('N01', { x: 999, y: 888 })

    expect(store().positions.N01).toEqual({ x: 999, y: 888 })
    for (const [nodeId, position] of others) {
      expect(store().positions[nodeId]).toEqual(position)
    }
  })
})

import { create } from 'zustand'
import type { Connection } from '@xyflow/react'

export interface NodeEditorTarget {
  mode: 'create' | 'edit'
  nodeId?: string
}

export interface EdgeEditorTarget {
  mode: 'create' | 'edit'
  edgeId?: string
  draft?: Connection
}

export interface DocumentTarget {
  nodeId: string
  documentId: string
}

interface UiState {
  nodeEditor: NodeEditorTarget | null
  edgeEditor: EdgeEditorTarget | null
  documentPanel: DocumentTarget | null
  openNodeEditor: (target: NodeEditorTarget) => void
  closeNodeEditor: () => void
  openEdgeEditor: (target: EdgeEditorTarget) => void
  closeEdgeEditor: () => void
  openDocument: (target: DocumentTarget) => void
  closeDocument: () => void
}

export const useUiStore = create<UiState>()(set => ({
  nodeEditor: null,
  edgeEditor: null,
  documentPanel: null,
  openNodeEditor: target => set({ nodeEditor: target }),
  closeNodeEditor: () => set({ nodeEditor: null }),
  openEdgeEditor: target => set({ edgeEditor: target }),
  closeEdgeEditor: () => set({ edgeEditor: null }),
  openDocument: target => set({ documentPanel: target }),
  closeDocument: () => set({ documentPanel: null }),
}))

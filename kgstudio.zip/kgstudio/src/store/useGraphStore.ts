import { create } from 'zustand'
import {
  createEdgeApi, createNodeApi, deleteEdgeApi, deleteNodeApi,
  queryGraph, updateEdgeApi, updateNodeApi,
} from '@/api/graph'
import { errorMessage } from '@/lib/errors'
import { layoutGraph, placeNewNode, type XY } from '@/lib/layout'
import type { EdgePayload, GraphEdge, GraphNode, NodePayload } from '@/types/graph'

export type GraphStatus = 'idle' | 'loading' | 'ready' | 'error'

interface GraphState {
  nodes: GraphNode[]
  edges: GraphEdge[]
  positions: Record<string, XY>
  status: GraphStatus
  error: string | null

  searchGraph: (nodeIds: string[], hop: number) => Promise<void>
  createNode: (payload: NodePayload) => Promise<GraphNode>
  updateNode: (nodeId: string, payload: NodePayload) => Promise<GraphNode>
  deleteNode: (nodeId: string) => Promise<void>
  createEdge: (payload: EdgePayload) => Promise<GraphEdge>
  updateEdge: (edgeId: string, payload: EdgePayload) => Promise<GraphEdge>
  deleteEdge: (edgeId: string) => Promise<void>
  setNodePosition: (nodeId: string, position: XY) => void
  reset: () => void
}

const initial = {
  nodes: [] as GraphNode[],
  edges: [] as GraphEdge[],
  positions: {} as Record<string, XY>,
  status: 'idle' as GraphStatus,
  error: null as string | null,
}

// 查询请求的序号。两次查询可能乱序返回（浏览器前进后退可以连点，
// 搜索按钮的 loading 锁管不到 URL 驱动的历史导航），晚到的旧响应必须整条丢掉：
// 否则画布画着子图 A，URL 却写着 B。MSW 下永远按顺序返回，这问题要等接上
// 真实后端、带上真实网络抖动才会间歇性出现 —— 那时就很难查了。
let searchSeq = 0

export const useGraphStore = create<GraphState>()(set => ({
  ...initial,

  async searchGraph(nodeIds, hop) {
    const seq = ++searchSeq
    const isStale = () => seq !== searchSeq
    set({ status: 'loading', error: null })
    try {
      const { nodes, edges } = await queryGraph({ node_ids: nodeIds, hop })
      if (isStale()) return
      set({ nodes, edges, positions: layoutGraph(nodes, edges), status: 'ready', error: null })
    } catch (e) {
      // 失败分支同样要判：晚到的失败会把 { ...initial } 写回去，
      // 把一次成功查询的结果整个清空，还配上与当前 URL 无关的错误提示。
      if (isStale()) return
      set({ ...initial, status: 'error', error: errorMessage(e, '查询失败，请重试') })
    }
  },

  async createNode(payload) {
    const created = await createNodeApi(payload)
    set(s => ({
      nodes: [...s.nodes, created],
      positions: { ...s.positions, [created.node_id]: placeNewNode(s.positions) },
    }))
    return created
  },

  async updateNode(nodeId, payload) {
    const updated = await updateNodeApi(nodeId, payload)
    // 状态行被删除时，挂在它上面的边必须一起清掉。
    // 否则边的 sourceHandle/targetHandle 指向一个已不存在的 handle：
    // React Flow 挂不上去，边从画布上消失，但它仍在 store 与数据库里 ——
    // 用户再也看不到、点不到、删不掉（打开边编辑的唯一入口就是点那条边）。
    // 与 deleteNode 一样，这里由返回的 node 自行推导，不依赖服务端额外告知。
    const liveStatusIds = new Set(updated.status_list.map(s => s.status_id))
    const referencesDeadStatus = (e: GraphEdge) =>
      (e.from_node_id === nodeId && !liveStatusIds.has(e.from_status_id)) ||
      (e.to_node_id === nodeId && !liveStatusIds.has(e.to_status_id))

    set(s => ({
      nodes: s.nodes.map(n => (n.node_id === nodeId ? updated : n)),
      edges: s.edges.filter(e => !referencesDeadStatus(e)),
    }))
    return updated
  },

  async deleteNode(nodeId) {
    const response = await deleteNodeApi(nodeId)
    // 不能只信响应。Task 2 把 { success: true, data: null } 确立为合法的成功响应，
    // 而 DELETE 返回空体是常见 REST 写法 —— 那样 deleted_edge_ids 就不存在，
    // 相连的边会留在画布上，指向一个已经不存在的节点。
    // 取「响应报告的边」与「本地按 node_id 判定的相连边」的并集，两种后端写法都正确。
    const reported = new Set(response?.deleted_edge_ids ?? [])
    set(s => {
      const positions = { ...s.positions }
      delete positions[nodeId]
      return {
        nodes: s.nodes.filter(n => n.node_id !== nodeId),
        edges: s.edges.filter(
          e =>
            !reported.has(e.edge_id) &&
            e.from_node_id !== nodeId &&
            e.to_node_id !== nodeId,
        ),
        positions,
      }
    })
  },

  async createEdge(payload) {
    const created = await createEdgeApi(payload)
    set(s => ({ edges: [...s.edges, created] }))
    return created
  },

  async updateEdge(edgeId, payload) {
    const updated = await updateEdgeApi(edgeId, payload)
    set(s => ({ edges: s.edges.map(e => (e.edge_id === edgeId ? updated : e)) }))
    return updated
  },

  async deleteEdge(edgeId) {
    await deleteEdgeApi(edgeId)
    set(s => ({ edges: s.edges.filter(e => e.edge_id !== edgeId) }))
  },

  setNodePosition(nodeId, position) {
    set(s => ({ positions: { ...s.positions, [nodeId]: position } }))
  },

  reset() {
    set({ ...initial })
  },
}))

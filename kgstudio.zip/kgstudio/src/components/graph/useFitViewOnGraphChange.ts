import { useEffect } from 'react'
import { useReactFlow } from '@xyflow/react'

/**
 * 图的内容换了一批节点时重新取景。
 *
 * `<ReactFlow fitView />` 只在初始化时生效一次。于是第二次搜索——尤其是把 hop 从 1 调到 6——
 * 出来的更大的图会沿用上一次的缩放，被裁在视口外，用户得自己缩放才能看全。
 *
 * 不需要自己等节点量完尺寸：`fitView()` 只是把请求排进 React Flow 的节点队列
 * （`fitViewQueued`），测量完成后由内部流程执行——`<ReactFlow fitView />` 初始化时
 * 走的也正是这条队列。
 *
 * 顺带记一笔踩过的坑：别用 `useNodesInitialized()` 当闸门。受控模式下测量完成走的是
 * `updateNodeInternals`，它不会回写 store 里的 `nodesInitialized` 字段，
 * 那个值要等下一次 `setNodes` 才重算 —— 于是闸门会一直是 false，effect 永远不放行。
 * （实测：E2E 里 hop 1→6 之后 viewport 的 transform 一动不动。）
 *
 * @param graphKey 图的身份标识，节点集合变了它就要变
 */
export function useFitViewOnGraphChange(graphKey: string): void {
  const { fitView } = useReactFlow()

  useEffect(() => {
    if (!graphKey) return
    void fitView({ padding: 0.2 })
  }, [graphKey, fitView])
}

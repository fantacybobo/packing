import { describe, it, expect, vi, beforeEach } from 'vitest'
import { renderHook } from '@testing-library/react'
import { useFitViewOnGraphChange } from './useFitViewOnGraphChange'

const fitView = vi.fn(async () => true)

// 只关心「什么时候请求重新取景」，不需要真的跑起一张画布。
// 取景本身是否正确由 E2E 里的 transform 断言把关（jsdom 没有尺寸测量，测不了）。
vi.mock('@xyflow/react', () => ({ useReactFlow: () => ({ fitView }) }))

beforeEach(() => fitView.mockClear())

describe('useFitViewOnGraphChange', () => {
  it('图换了一批节点时重新取景', () => {
    const { rerender } = renderHook(({ key }) => useFitViewOnGraphChange(key), {
      initialProps: { key: 'N01,N02' },
    })
    expect(fitView).toHaveBeenCalledTimes(1)

    // 第二次搜索（例如 hop 从 1 调到 6）带回更大的图：必须重新取景，
    // 否则新图沿用旧缩放被裁在视口外。<ReactFlow fitView /> 这个 prop 管不到这里。
    rerender({ key: 'N01,N02,N03,N04' })
    expect(fitView).toHaveBeenCalledTimes(2)
  })

  it('图没变时不重复取景，免得把用户手动调好的视角冲掉', () => {
    const { rerender } = renderHook(({ key }) => useFitViewOnGraphChange(key), {
      initialProps: { key: 'N01,N02' },
    })
    rerender({ key: 'N01,N02' })
    rerender({ key: 'N01,N02' })
    expect(fitView).toHaveBeenCalledTimes(1)
  })

  it('空图不取景', () => {
    renderHook(() => useFitViewOnGraphChange(''))
    expect(fitView).not.toHaveBeenCalled()
  })
})

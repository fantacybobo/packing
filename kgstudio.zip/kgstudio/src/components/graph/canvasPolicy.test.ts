import { describe, it, expect } from 'vitest'
import type { Connection, NodeChange } from '@xyflow/react'
import type { GraphEdge } from '@/types/graph'
import { nextSelectedId, decideConnect } from './canvasPolicy'

const selectChange = (id: string, selected: boolean): NodeChange => ({ type: 'select', id, selected })
const positionChange = (id: string): NodeChange => ({ type: 'position', id, position: { x: 1, y: 2 } })

describe('nextSelectedId', () => {
  it('select: true 选中该节点', () => {
    expect(nextSelectedId(null, selectChange('N01', true))).toBe('N01')
  })

  it('select: false 命中当前选中项时清空', () => {
    expect(nextSelectedId('N01', selectChange('N01', false))).toBeNull()
  })

  it('select: false 但不是当前选中项时保持不变', () => {
    expect(nextSelectedId('N01', selectChange('N02', false))).toBe('N01')
  })

  it('非 select 变更（如拖拽产生的 position）不影响选中态', () => {
    expect(nextSelectedId('N01', positionChange('N02'))).toBe('N01')
  })
})

const edge: GraphEdge = {
  edge_id: 'E001', from_node_id: 'N01', to_node_id: 'N02',
  from_status_id: 'N01-ST01', to_status_id: 'N02-ST01', priority: 7, tone: 'default',
}

const connection = (over: Partial<Connection> = {}): Connection => ({
  source: 'N01', target: 'N02', sourceHandle: 'N01-ST01', targetHandle: 'N02-ST01', ...over,
})

describe('decideConnect', () => {
  it('自连判定为 self-loop', () => {
    expect(decideConnect([], connection({ target: 'N01', targetHandle: 'N01-ST01' }))).toEqual({ kind: 'self-loop' })
  })

  it('两个 status 之间已有边时判定为 duplicate', () => {
    expect(decideConnect([edge], connection())).toEqual({ kind: 'duplicate' })
  })

  it('合法的新连线判定为 open-editor，交给上层打开编辑器（永远不在这里直接建边）', () => {
    expect(decideConnect([edge], connection({ targetHandle: 'N02-ST02' }))).toEqual({ kind: 'open-editor' })
  })
})

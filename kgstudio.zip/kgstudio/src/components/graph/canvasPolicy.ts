import type { Connection, NodeChange } from '@xyflow/react'
import { findDuplicateEdge, isSelfLoop } from '@/lib/adapters'
import type { GraphEdge } from '@/types/graph'

/**
 * 把一条 NodeChange 折叠进当前选中态，供 `changes.reduce(nextSelectedId, current)` 使用。
 * - select:true  → 选中该节点
 * - select:false → 只有命中当前选中项时才清空；选中 A 时收到别的节点的 deselect 不应把 A 冲掉
 * - 其它类型（拖拽产生的 position、尺寸变化等）→ 选中态不变
 */
export function nextSelectedId(current: string | null, change: NodeChange): string | null {
  if (change.type !== 'select') return current
  if (change.selected) return change.id
  return current === change.id ? null : current
}

export type ConnectDecision =
  | { kind: 'self-loop' }
  | { kind: 'duplicate' }
  | { kind: 'open-editor' }

/**
 * `onConnect` 与 `isValidConnection` 共用的判定，建立在 Task 6 已测试过的
 * `isSelfLoop` / `findDuplicateEdge` 之上。两个调用方共享同一份判定与顺序，
 * 不会出现「拖拽预览允许、松手后又被拒绝」这类不一致。
 * 落到 `open-editor` 时，调用方只负责打开编辑器草稿 —— 拖拽连线本身永远不直接建边。
 */
export function decideConnect(edges: GraphEdge[], connection: Connection): ConnectDecision {
  if (isSelfLoop(connection)) return { kind: 'self-loop' }
  if (findDuplicateEdge(edges, connection)) return { kind: 'duplicate' }
  return { kind: 'open-editor' }
}

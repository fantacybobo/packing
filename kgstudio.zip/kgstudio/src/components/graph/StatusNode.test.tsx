import { describe, it, expect, beforeEach } from 'vitest'
import type { ComponentProps } from 'react'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ReactFlowProvider } from '@xyflow/react'
import { StatusNode } from './StatusNode'
import { useUiStore } from '@/store/useUiStore'
import { renderWithProviders } from '@/test/renderWithProviders'
import type { GraphNode } from '@/types/graph'

const node: GraphNode = {
  node_id: 'N01', entity: 'TASK PROCESSOR', metrics: '从队列拉取待处理任务。',
  tone: 'default', document_id: ['DOC-2026-0001'],
  status_list: [
    { status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' },
    { status_id: 'N01-ST02', node_id: 'N01', status_description: 'Running' },
  ],
}

// xyflow v12 的 NodeProps 字段较多，测试里只关心其中几个，
// 用组件自身的 props 类型收敛，避免逐个补齐无关字段
type StatusNodeProps = ComponentProps<typeof StatusNode>

const renderNode = (data: GraphNode = node) => {
  const props = {
    id: data.node_id,
    type: 'statusNode',
    data: { node: data },
    selected: false,
    dragging: false,
    zIndex: 0,
    isConnectable: true,
    positionAbsoluteX: 0,
    positionAbsoluteY: 0,
  } as unknown as StatusNodeProps

  // renderWithProviders 提供与生产一致的 ConfigProvider/AntApp；
  // ReactFlowProvider 是 StatusNode 使用 <Handle> 所必需的额外上下文。
  return renderWithProviders(
    <ReactFlowProvider>
      <StatusNode {...props} />
    </ReactFlowProvider>,
  )
}

beforeEach(() => {
  useUiStore.setState({ nodeEditor: null, edgeEditor: null, documentPanel: null })
})

describe('StatusNode', () => {
  it('展示 node_id、entity 与 metrics', () => {
    renderNode()
    expect(screen.getByText('N01')).toBeInTheDocument()
    expect(screen.getByText('TASK PROCESSOR')).toBeInTheDocument()
    expect(screen.getByText('从队列拉取待处理任务。')).toBeInTheDocument()
  })

  it('每条 status 渲染一行', () => {
    renderNode()
    expect(screen.getByText('Pending')).toBeInTheDocument()
    expect(screen.getByText('Running')).toBeInTheDocument()
  })

  it('每条 status 左右各一个 handle，id 就是 status_id，左侧为 target、右侧为 source', () => {
    const { container } = renderNode()
    // 覆盖两条 status，而不只是第一条；同时断言 handle 类型，
    // 防止左右 target/source 被悄悄调换（连线方向会因此整体反转）。
    for (const statusId of ['N01-ST01', 'N01-ST02']) {
      const left = container.querySelector(`[data-handleid="${statusId}"][data-handlepos="left"]`)
      const right = container.querySelector(`[data-handleid="${statusId}"][data-handlepos="right"]`)
      expect(left).toBeTruthy()
      expect(right).toBeTruthy()
      expect(left).toHaveClass('target')
      expect(right).toHaveClass('source')
    }
  })

  it('点编辑按钮打开节点编辑抽屉', async () => {
    const user = userEvent.setup()
    renderNode()
    await user.click(screen.getByRole('button', { name: '编辑节点' }))
    expect(useUiStore.getState().nodeEditor).toEqual({ mode: 'edit', nodeId: 'N01' })
  })

  it('点文档按钮用第一个 document_id 打开文档面板', async () => {
    const user = userEvent.setup()
    renderNode()
    await user.click(screen.getByRole('button', { name: '节点文档' }))
    expect(useUiStore.getState().documentPanel).toEqual({ nodeId: 'N01', documentId: 'DOC-2026-0001' })
  })

  it('document_id 为空时文档按钮禁用', () => {
    renderNode({ ...node, document_id: [] })
    expect(screen.getByRole('button', { name: '该节点暂无文档' })).toBeDisabled()
  })
})

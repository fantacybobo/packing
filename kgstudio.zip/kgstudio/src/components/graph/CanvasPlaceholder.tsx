import { Empty, Button, Spin } from 'antd'
import type { GraphStatus } from '@/store/useGraphStore'

interface CanvasPlaceholderProps {
  status: GraphStatus
  error: string | null
  onRetry: () => void
}

export function CanvasPlaceholder({ status, error, onRetry }: CanvasPlaceholderProps) {
  if (status === 'error') {
    return (
      <div className="canvas-placeholder">
        <Empty description={error ?? '查询失败'} image={Empty.PRESENTED_IMAGE_SIMPLE} />
        <Button onClick={onRetry}>重试</Button>
      </div>
    )
  }
  // 查询已经在飞：不能落到「点搜索开始」这条文案，那是在告诉用户去做一件已经在做的事。
  if (status === 'loading') {
    return (
      <div className="canvas-placeholder">
        <Spin size="large" />
        <p className="canvas-placeholder__hint">正在查询图谱…</p>
      </div>
    )
  }
  if (status === 'ready') {
    return (
      <div className="canvas-placeholder">
        <Empty description="未找到对应节点，换个关键字或调大跳数试试" image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    )
  }
  return (
    <div className="canvas-placeholder">
      <Empty description="在上方输入关键字选择节点，点「搜索」开始" image={Empty.PRESENTED_IMAGE_SIMPLE} />
    </div>
  )
}

import { useCallback, useMemo, useState } from 'react'
import { App as AntApp } from 'antd'
import {
  Background, Controls, ReactFlow, ReactFlowProvider,
  type Connection, type Edge, type NodeChange,
} from '@xyflow/react'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import { toFlowEdges, toFlowNodes } from '@/lib/adapters'
import { useGraphQueryParams } from '@/hooks/useGraphQuery'
import { decideConnect, nextSelectedId } from './canvasPolicy'
import { useFitViewOnGraphChange } from './useFitViewOnGraphChange'
import { StatusNode } from './StatusNode'
import { PriorityEdge } from './PriorityEdge'
import { CanvasPlaceholder } from './CanvasPlaceholder'
import './graph.css'

const nodeTypes = { statusNode: StatusNode }
const edgeTypes = { priorityEdge: PriorityEdge }

function GraphCanvasInner() {
  const { message } = AntApp.useApp()
  // 只读参数供重试按钮使用；查询 effect 由 SearchBar 独占，这里不能用 useGraphQuerySync
  const { nodeIds, hop } = useGraphQueryParams()
  const nodes = useGraphStore(s => s.nodes)
  const edges = useGraphStore(s => s.edges)
  const positions = useGraphStore(s => s.positions)
  const status = useGraphStore(s => s.status)
  const error = useGraphStore(s => s.error)
  const setNodePosition = useGraphStore(s => s.setNodePosition)
  const searchGraph = useGraphStore(s => s.searchGraph)
  const openEdgeEditor = useUiStore(s => s.openEdgeEditor)

  // 节点数据由 store 驱动，但选中态是纯视图状态，留在组件内
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const flowNodes = useMemo(
    () => toFlowNodes(nodes, positions).map(n => ({ ...n, selected: n.id === selectedId })),
    [nodes, positions, selectedId],
  )
  const flowEdges = useMemo(() => toFlowEdges(edges), [edges])

  // <ReactFlow fitView /> 只在初始化时生效一次，第二次搜索不会重新取景。
  // 图的身份用节点 id 列表表示：换了一批节点就重新 fit，纯粹挪动某个节点不会触发。
  useFitViewOnGraphChange(useMemo(() => nodes.map(n => n.node_id).join(','), [nodes]))

  const onNodesChange = useCallback((changes: NodeChange[]) => {
    for (const change of changes) {
      if (change.type === 'position' && change.position) {
        setNodePosition(change.id, change.position)
      }
    }
    // 选中态的折叠规则见 canvasPolicy.nextSelectedId，这里只负责喂数据
    setSelectedId(current => changes.reduce(nextSelectedId, current))
  }, [setNodePosition])

  const isValidConnection = useCallback(
    (c: Connection | Edge) => decideConnect(edges, c as Connection).kind === 'open-editor',
    [edges],
  )

  // 与 isValidConnection 共用 canvasPolicy.decideConnect，保证判定与顺序完全一致。
  // 落到 open-editor 时只打开编辑器草稿——拖拽连线本身永远不在这里直接建边。
  const onConnect = useCallback((connection: Connection) => {
    const decision = decideConnect(edges, connection)
    if (decision.kind === 'self-loop') {
      message.warning('不能把一个状态连到它自己')
      return
    }
    if (decision.kind === 'duplicate') {
      message.warning('这两个状态之间已经有一条边了')
      return
    }
    openEdgeEditor({ mode: 'create', draft: connection })
  }, [edges, message, openEdgeEditor])

  const onEdgeOpen = useCallback((event: React.MouseEvent, edge: Edge) => {
    event.preventDefault()
    openEdgeEditor({ mode: 'edit', edgeId: edge.id })
  }, [openEdgeEditor])

  if (nodes.length === 0) {
    return (
      <CanvasPlaceholder
        status={status}
        error={error}
        onRetry={() => nodeIds.length > 0 && void searchGraph(nodeIds, hop)}
      />
    )
  }

  return (
    <ReactFlow
      nodes={flowNodes}
      edges={flowEdges}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      onNodesChange={onNodesChange}
      onConnect={onConnect}
      isValidConnection={isValidConnection}
      onEdgeClick={onEdgeOpen}
      onEdgeContextMenu={onEdgeOpen}
      minZoom={0.3}
      maxZoom={1.8}
      fitView
      fitViewOptions={{ padding: 0.2 }}
      proOptions={{ hideAttribution: false }}
    >
      <Background gap={44} color="rgba(58,86,112,.28)" />
      <Controls showInteractive={false} />
    </ReactFlow>
  )
}

export function GraphCanvas() {
  return (
    <ReactFlowProvider>
      <GraphCanvasInner />
    </ReactFlowProvider>
  )
}

import { memo } from 'react'
import { Handle, Position, type NodeProps } from '@xyflow/react'
import { TONE_COLORS } from '@/theme'
import { useUiStore } from '@/store/useUiStore'
import { NODE_WIDTH } from '@/lib/layout'
import type { StatusFlowNode } from '@/lib/adapters'
import './graph.css'

function StatusNodeImpl({ data, selected }: NodeProps<StatusFlowNode>) {
  const { node } = data
  const tone = TONE_COLORS[node.tone] ?? TONE_COLORS.default
  const openNodeEditor = useUiStore(s => s.openNodeEditor)
  const openDocument = useUiStore(s => s.openDocument)
  const documentId = node.document_id[0]

  return (
    <article
      className={`status-node${selected ? ' status-node--selected' : ''}`}
      style={{ width: NODE_WIDTH, borderColor: selected ? tone.accent : tone.border }}
    >
      <header className="status-node__bar">
        <div className="status-node__bar-left">
          <span className="status-node__id">{node.node_id}</span>
          <button
            type="button"
            className="status-node__icon nodrag"
            disabled={!documentId}
            aria-label={documentId ? '节点文档' : '该节点暂无文档'}
            title={documentId ? '节点文档' : '该节点暂无文档'}
            onClick={() => documentId && openDocument({ nodeId: node.node_id, documentId })}
          >
            <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
              <rect x="2" y="1" width="8" height="10" rx="1.5" fill="none" stroke="currentColor" strokeWidth="1.2" />
              <line x1="4" y1="4" x2="8" y2="4" stroke="currentColor" strokeWidth="1.2" />
              <line x1="4" y1="6.5" x2="8" y2="6.5" stroke="currentColor" strokeWidth="1.2" />
            </svg>
          </button>
        </div>
        <button
          type="button"
          className="status-node__icon nodrag"
          aria-label="编辑节点"
          title="编辑节点"
          onClick={() => openNodeEditor({ mode: 'edit', nodeId: node.node_id })}
        >
          <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true">
            <circle cx="3.6" cy="10.4" r="2.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <rect x="5.6" y="2.2" width="3" height="7.2" rx="1.2" transform="rotate(45 7.1 5.8)"
              fill="none" stroke="currentColor" strokeWidth="1.3" />
          </svg>
        </button>
      </header>

      <div className="status-node__head">
        <h3 className="status-node__title" style={{ color: selected ? tone.accent : 'var(--color-text-strong)' }}>
          {node.entity}
        </h3>
        <p className="status-node__metrics">{node.metrics}</p>
      </div>

      <ul className="status-node__rows">
        {node.status_list.map(status => (
          <li key={status.status_id} className="status-node__row">
            <Handle type="target" position={Position.Left} id={status.status_id} className="status-node__port" />
            <span className="status-node__row-label">Status:</span>
            <span className="status-node__row-value">{status.status_description}</span>
            <Handle type="source" position={Position.Right} id={status.status_id} className="status-node__port" />
          </li>
        ))}
      </ul>
    </article>
  )
}

export const StatusNode = memo(StatusNodeImpl)

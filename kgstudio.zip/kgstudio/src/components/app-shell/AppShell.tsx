import type { ReactNode } from 'react'
import { IconRail } from './IconRail'
import { TopBar } from './TopBar'
import './app-shell.css'

interface AppShellProps {
  toolbar: ReactNode
  children: ReactNode
}

export function AppShell({ toolbar, children }: AppShellProps) {
  return (
    <div className="app-shell">
      <IconRail />
      <div className="app-shell__body">
        <TopBar />
        <div className="app-shell__toolbar">{toolbar}</div>
        <main className="app-shell__main">{children}</main>
      </div>
    </div>
  )
}

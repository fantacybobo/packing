import { describe, it, expect } from 'vitest'
import { render, screen, within } from '@testing-library/react'
import { AppShell } from './AppShell'

describe('AppShell', () => {
  it('渲染产品名', () => {
    render(<AppShell toolbar={null}><div /></AppShell>)
    expect(screen.getByText('KG Studio')).toBeInTheDocument()
  })

  it('使用语义化结构：导航、页头、主内容', () => {
    render(<AppShell toolbar={null}><div data-testid="content" /></AppShell>)
    expect(screen.getByRole('navigation', { name: '主导航' })).toBeInTheDocument()
    expect(screen.getByRole('banner')).toBeInTheDocument()
    expect(screen.getByRole('main')).toBeInTheDocument()
  })

  it('工具条与主内容都被渲染到位', () => {
    render(<AppShell toolbar={<div data-testid="toolbar" />}><div data-testid="content" /></AppShell>)
    expect(screen.getByTestId('toolbar')).toBeInTheDocument()
    expect(screen.getByTestId('content')).toBeInTheDocument()
  })

  it('图标栏里没有可聚焦控件：不占 Tab 顺序，也不会和工具条里的按钮重名', () => {
    // 这五项本期没有任何目的地。渲染成 <button> 时，键盘用户会 Tab 进五个
    // 按了没反应的东西，其中「搜索」还和搜索栏里真正的搜索按钮同名 ——
    // E2E 里那句「限定 .search-bar 以避开 strict-mode 冲突」就是被它逼出来的。
    render(
      <AppShell toolbar={<button type="button">搜索</button>}><div /></AppShell>,
    )
    const nav = screen.getByRole('navigation', { name: '主导航' })
    expect(within(nav).queryAllByRole('button')).toHaveLength(0)
    expect(nav.querySelectorAll('button, a, [tabindex]')).toHaveLength(0)

    // 全页面只剩工具条里那一个真正的「搜索」
    expect(screen.getAllByRole('button', { name: '搜索' })).toHaveLength(1)
  })

  it('头像的无障碍名真的生效（裸 span 上的 aria-label 会被读屏忽略）', () => {
    render(<AppShell toolbar={null}><div /></AppShell>)
    expect(screen.getByRole('img', { name: '当前用户' })).toBeInTheDocument()
  })
})

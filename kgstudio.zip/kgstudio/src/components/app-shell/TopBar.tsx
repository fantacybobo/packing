export function TopBar() {
  return (
    <header className="top-bar">
      <span className="top-bar__title">KG Studio</span>
      {/* 裸 <span> 上的 aria-label 会被读屏忽略（没有 role 就不允许命名），
          给它 role="img"，这个名字才真的存在 */}
      <span className="top-bar__avatar" role="img" aria-label="当前用户">N</span>
    </header>
  )
}

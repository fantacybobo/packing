import type { ReactNode } from 'react'
import './app-shell.css'

const ITEMS = [
  { key: 'overview', label: '总览' },
  { key: 'search', label: '搜索' },
  { key: 'graph', label: '图谱', active: true },
  { key: 'docs', label: '文档' },
  { key: 'settings', label: '设置' },
]

// 五个导航项各自的图标，均以 currentColor 绘制，随 .icon-rail__item 的
// 默认/hover/active 颜色规则自动变化，无需额外 CSS。
const ICONS: Record<string, ReactNode> = {
  overview: (
    <svg width="16" height="16" viewBox="0 0 16 16">
      <rect x="1" y="1" width="6" height="6" rx="1.5" fill="currentColor" />
      <rect x="9" y="1" width="6" height="6" rx="1.5" fill="currentColor" />
      <rect x="1" y="9" width="6" height="6" rx="1.5" fill="currentColor" />
      <rect x="9" y="9" width="6" height="6" rx="1.5" fill="currentColor" />
    </svg>
  ),
  search: (
    <svg width="16" height="16" viewBox="0 0 16 16">
      <circle cx="7" cy="7" r="5" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <line x1="11" y1="11" x2="15" y2="15" stroke="currentColor" strokeWidth="1.6" />
    </svg>
  ),
  graph: (
    <svg width="16" height="16" viewBox="0 0 16 16">
      <circle cx="3.5" cy="8" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12.5" cy="4" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12.5" cy="12" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <line x1="5.4" y1="7.1" x2="10.6" y2="4.7" stroke="currentColor" strokeWidth="1.3" />
      <line x1="5.4" y1="8.9" x2="10.6" y2="11.3" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  ),
  docs: (
    <svg width="16" height="16" viewBox="0 0 16 16">
      <rect x="1.5" y="3" width="13" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <line x1="1.5" y1="7" x2="14.5" y2="7" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  ),
  settings: (
    <svg width="16" height="16" viewBox="0 0 16 16">
      <circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="8" cy="8" r="1.8" fill="currentColor" />
    </svg>
  ),
}

export function IconRail() {
  return (
    <nav className="icon-rail" aria-label="主导航">
      <div className="icon-rail__brand" aria-hidden="true">
        <svg width="18" height="18" viewBox="0 0 18 18">
          <circle cx="4" cy="9" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
          <circle cx="14" cy="4" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
          <circle cx="14" cy="14" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
          <line x1="6" y1="8" x2="12" y2="5" stroke="var(--accent-start)" strokeWidth="1.2" />
          <line x1="6" y1="10" x2="12" y2="13" stroke="var(--accent-start)" strokeWidth="1.2" />
        </svg>
      </div>
      {/*
        本期没有路由，这五项没有任何目的地，所以它们不是控件：
        用 <button> 会让键盘用户 Tab 进五个按了没反应的东西，其中「搜索」
        还会和搜索栏里真正的搜索按钮重名（E2E 里那段限定 .search-bar 的注释
        就是被这个逼出来的）；aria-current="page" 更是在一个没有页面概念的应用里
        凭空宣称「当前页」。现在渲染成不可聚焦、对读屏隐藏的装饰元素，
        title 留给鼠标用户认图标。等真有路由了再换回 <a>/<button>。
      */}
      {ITEMS.map(item => (
        <span
          key={item.key}
          aria-hidden="true"
          title={item.label}
          className={`icon-rail__item${item.active ? ' icon-rail__item--active' : ''}`}
        >
          {ICONS[item.key]}
        </span>
      ))}
    </nav>
  )
}

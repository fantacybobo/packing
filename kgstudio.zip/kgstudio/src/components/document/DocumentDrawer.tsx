import { useEffect, useState } from 'react'
import { Alert, App as AntApp, Button, Drawer, Input, Skeleton, Space } from 'antd'
import { getDocument, updateDocument } from '@/api/graph'
import { useUiStore } from '@/store/useUiStore'
import { errorMessage } from '@/lib/errors'
import type { NodeDocument } from '@/types/graph'
import './document.css'

type EditableField = 'evaluation_method' | 'description' | 'flow_reason' | 'remark'

const EDITABLE: { key: EditableField; label: string; rows: number }[] = [
  { key: 'evaluation_method', label: 'EVALUATION METHOD', rows: 3 },
  { key: 'description', label: 'DESCRIPTION', rows: 4 },
  { key: 'flow_reason', label: 'FLOW REASON', rows: 3 },
  { key: 'remark', label: 'REMARK', rows: 5 },
]

export function DocumentDrawer() {
  const { message } = AntApp.useApp()
  const target = useUiStore(s => s.documentPanel)
  const close = useUiStore(s => s.closeDocument)

  const [doc, setDoc] = useState<NodeDocument | null>(null)
  const [loading, setLoading] = useState(false)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  // 依赖 target?.documentId：抽屉关闭或切换到另一个文档时都会重新跑这个 effect，
  // cleanup 里的 cancelled 保证旧请求的迟到响应不会覆盖新状态。
  useEffect(() => {
    if (!target) {
      setDoc(null)
      setLoadError(null)
      return
    }
    let cancelled = false
    setLoading(true)
    setLoadError(null)
    getDocument(target.documentId)
      .then(result => { if (!cancelled) setDoc(result) })
      .catch(e => { if (!cancelled) setLoadError(errorMessage(e, '文档加载失败')) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [target?.documentId])

  const patch = (key: EditableField, value: string) =>
    setDoc(current => (current ? { ...current, [key]: value } : current))

  const save = async () => {
    if (!doc) return
    setSaving(true)
    try {
      // 全量回传 7 个字段，不做部分更新：prerequisite / check_question 未变
      // 也要跟着可编辑的 4 个字段一起发出去。
      setDoc(await updateDocument(doc))
      message.success('文档已保存')
      close()
    } catch (e) {
      // 失败时不 setDoc、不 close：抽屉留在原地，doc 里用户刚编辑的内容原样保留。
      message.error(errorMessage(e, '保存失败'))
    } finally {
      setSaving(false)
    }
  }

  return (
    <Drawer
      open={!!target}
      onClose={close}
      size="33.33vw"
      styles={{ wrapper: { minWidth: 380 } }}
      closeIcon={false}
      title={
        <div>
          <div className="panel__kicker">NODE DOCUMENT</div>
          <div className="panel__id">{doc?.document_id ?? target?.documentId ?? ''}</div>
        </div>
      }
      extra={
        <button type="button" className="panel__close" aria-label="关闭" onClick={close}>
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true">
            <line x1="1" y1="1" x2="13" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="13" y1="1" x2="1" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </button>
      }
      footer={
        <div className="document__footer">
          <Space>
            <Button onClick={close}>关闭</Button>
            <Button type="primary" loading={saving} disabled={!doc} onClick={save}>保存</Button>
          </Space>
        </div>
      }
    >
      {loading && <Skeleton active paragraph={{ rows: 8 }} />}
      {loadError && <Alert type="error" showIcon message={loadError} />}

      {doc && !loading && (
        <>
          <div className="document__readonly">
            <span className="panel__kicker">PREREQUISITE</span>
            <p className="document__readonly-body">{doc.prerequisite}</p>
          </div>
          <div className="document__readonly">
            <span className="panel__kicker">CHECK QUESTION</span>
            <p className="document__readonly-body">{doc.check_question}</p>
          </div>

          {EDITABLE.map(field => (
            <div key={field.key} className="panel__field">
              <span className="panel__kicker">{field.label}</span>
              <Input.TextArea
                aria-label={field.label}
                rows={field.rows}
                value={doc[field.key]}
                onChange={e => patch(field.key, e.target.value)}
              />
            </div>
          ))}
        </>
      )}
    </Drawer>
  )
}

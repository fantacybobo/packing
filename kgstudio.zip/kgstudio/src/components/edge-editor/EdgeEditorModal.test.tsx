import { describe, it, expect, beforeEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithProviders } from '@/test/renderWithProviders'
import { EdgeEditorModal } from './EdgeEditorModal'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import type { EdgePayload } from '@/types/graph'

const draft = {
  source: 'N01', target: 'N04',
  sourceHandle: 'N01-ST01', targetHandle: 'N04-ST01',
}

// renderWithProviders 而非裸 render(<AntApp>...)：它额外带上 ConfigProvider 的
// autoInsertSpace: false，否则「保存」会被渲染成「保 存」，按名查询按钮全部失配。
const renderModal = () => renderWithProviders(<EdgeEditorModal />)

beforeEach(async () => {
  useGraphStore.getState().reset()
  useUiStore.setState({ nodeEditor: null, edgeEditor: null, documentPanel: null })
  await useGraphStore.getState().searchGraph(['N01'], 3)
})

describe('EdgeEditorModal', () => {
  it('未打开时不渲染', () => {
    renderModal()
    expect(screen.queryByLabelText('PRIORITY')).not.toBeInTheDocument()
  })

  it('建边模式展示起止状态，优先级默认 1', async () => {
    useUiStore.getState().openEdgeEditor({ mode: 'create', draft })
    renderModal()
    expect(await screen.findByLabelText('PRIORITY')).toHaveValue('1')
    expect(screen.getByText(/N01-ST01/)).toBeInTheDocument()
    expect(screen.getByText(/N04-ST01/)).toBeInTheDocument()
  })

  it('保存成功后边才进入 store，弹窗关闭', async () => {
    const user = userEvent.setup()
    const before = useGraphStore.getState().edges.length
    useUiStore.getState().openEdgeEditor({ mode: 'create', draft })
    renderModal()
    await user.clear(await screen.findByLabelText('PRIORITY'))
    await user.type(screen.getByLabelText('PRIORITY'), '5')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await waitFor(() => expect(useGraphStore.getState().edges).toHaveLength(before + 1))
    expect(useUiStore.getState().edgeEditor).toBeNull()
  })

  it('保存失败时不建边，弹窗保持打开且不丢用户输入', async () => {
    const user = userEvent.setup()
    server.use(http.post('*/api/edges', () =>
      HttpResponse.json({ success: false, data: null, error: '不允许的连线' }, { status: 400 })))
    const before = useGraphStore.getState().edges.length
    useUiStore.getState().openEdgeEditor({ mode: 'create', draft })
    renderModal()

    // 先改成一个有辨识度的值，失败后必须还在 ——
    // 只断言「弹窗还开着」的话，一个失败时重置表单的实现同样能过。
    const priorityInput = await screen.findByLabelText('PRIORITY')
    await user.clear(priorityInput)
    await user.type(priorityInput, '9')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await screen.findByText('不允许的连线')

    expect(useGraphStore.getState().edges).toHaveLength(before)
    expect(useUiStore.getState().edgeEditor).not.toBeNull()
    expect(screen.getByLabelText('PRIORITY')).toHaveValue('9')
  })

  it('编辑模式回填现有 priority 并能改掉', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openEdgeEditor({ mode: 'edit', edgeId: 'E001' })
    renderModal()
    expect(await screen.findByLabelText('PRIORITY')).toHaveValue('1')
    await user.clear(screen.getByLabelText('PRIORITY'))
    await user.type(screen.getByLabelText('PRIORITY'), '42')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await waitFor(() =>
      expect(useGraphStore.getState().edges.find(e => e.edge_id === 'E001')?.priority).toBe(42))
  })

  it('编辑目标的边已不在 store 中时，保存报错且不静默关闭', async () => {
    const user = userEvent.setup()
    const before = useGraphStore.getState().edges.length
    // E999 不在种子数据里：existing 解析不到，且没有 draft 可用 ——
    // 两个分支都不成立，必须显式报错而不是悄悄 close()。
    useUiStore.getState().openEdgeEditor({ mode: 'edit', edgeId: 'E999' })
    renderModal()
    await user.click(await screen.findByRole('button', { name: '保存' }))
    await screen.findByText('这条边已不存在，请关闭后重新操作')
    expect(useGraphStore.getState().edges).toHaveLength(before)
    expect(useUiStore.getState().edgeEditor).not.toBeNull()
  })

  it('删除边需要二次确认', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openEdgeEditor({ mode: 'edit', edgeId: 'E001' })
    renderModal()
    await user.click(await screen.findByRole('button', { name: '删除边' }))
    await user.click(await screen.findByRole('button', { name: '确认删除' }))
    await waitFor(() =>
      expect(useGraphStore.getState().edges.some(e => e.edge_id === 'E001')).toBe(false))
  })

  it('建边模式不显示删除按钮', async () => {
    useUiStore.getState().openEdgeEditor({ mode: 'create', draft })
    renderModal()
    await screen.findByLabelText('PRIORITY')
    expect(screen.queryByRole('button', { name: '删除边' })).not.toBeInTheDocument()
  })

  it('建边提交时四个 id 与优先级如实发到服务端', async () => {
    const user = userEvent.setup()
    let body: EdgePayload | undefined
    server.use(http.post('*/api/edges', async ({ request }) => {
      body = (await request.json()) as EdgePayload
      return HttpResponse.json({
        success: true, error: null,
        data: { ...body, tone: 'default', edge_id: 'E999' },
      })
    }))
    useUiStore.getState().openEdgeEditor({ mode: 'create', draft })
    renderModal()
    await user.clear(await screen.findByLabelText('PRIORITY'))
    await user.type(screen.getByLabelText('PRIORITY'), '7')
    await user.click(screen.getByRole('button', { name: '保存' }))

    await waitFor(() => expect(body).toBeDefined())
    // store 断言只能看到 edges 变长，看不出发的是哪四个 id —— 这里直接钉住请求体，
    // 确认 connectionToPayload 真的把 source/target/sourceHandle/targetHandle
    // 映射到了 from_node_id/to_node_id/from_status_id/to_status_id。
    expect(body).toEqual({
      from_node_id: 'N01', to_node_id: 'N04',
      from_status_id: 'N01-ST01', to_status_id: 'N04-ST01',
      priority: 7, tone: 'default',
    })
  })

  it('草稿缺少 handle 时不发请求，弹窗保持打开并提示', async () => {
    const user = userEvent.setup()
    let calls = 0
    server.use(http.post('*/api/edges', () => {
      calls += 1
      return HttpResponse.json({ success: false, data: null, error: '不应被调用' }, { status: 400 })
    }))
    const before = useGraphStore.getState().edges.length
    useUiStore.getState().openEdgeEditor({
      mode: 'create',
      draft: { source: 'N01', target: 'N04', sourceHandle: null, targetHandle: 'N04-ST01' },
    })
    renderModal()
    await user.click(await screen.findByRole('button', { name: '保存' }))
    await screen.findByText('连线信息不完整，请重新拖动连接')
    expect(calls).toBe(0)
    expect(useGraphStore.getState().edges).toHaveLength(before)
    expect(useUiStore.getState().edgeEditor).not.toBeNull()
  })
})

import { describe, it, expect, beforeEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithProviders } from '@/test/renderWithProviders'
import { SearchBar } from './SearchBar'
import { useGraphStore } from '@/store/useGraphStore'

const renderBar = (search = '') => renderWithProviders(<SearchBar />, { searchParams: search })

beforeEach(() => useGraphStore.getState().reset())

describe('SearchBar', () => {
  it('候选一为空时搜索按钮禁用', () => {
    renderBar()
    expect(screen.getByRole('button', { name: '搜索' })).toBeDisabled()
  })

  it('选中候选一后搜索按钮可点击', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')
    await user.click(await screen.findByText(/TASK PROCESSOR/))
    expect(screen.getByRole('button', { name: '搜索' })).toBeEnabled()
  })

  it('hop 默认是 2', () => {
    renderBar()
    expect(screen.getByLabelText('跳数')).toHaveValue('2')
  })

  it('URL 中带 hop 时用 URL 的值', () => {
    renderBar('?nodes=N01&hop=4')
    expect(screen.getByLabelText('跳数')).toHaveValue('4')
  })

  it('URL 中 hop 越界时收敛到上界', () => {
    renderBar('?nodes=N01&hop=99')
    expect(screen.getByLabelText('跳数')).toHaveValue('6')
  })

  it('深链进入时按响应回填候选框的显示文案', async () => {
    renderBar('?nodes=N01&hop=1')
    // antd 内部 title 与 label 是两条独立的计算路径：
    // title 只是 hover 提示，屏幕上真正显示的是 label。
    // 只断言 title 的话，label 计算整个坏掉测试依然会绿 —— 两条都要钉住。
    // 二者渲染在同一个 .ant-select-selection-item 元素上，可以一次断完。
    const selected = await screen.findByTitle('TASK PROCESSOR')
    expect(selected).toHaveTextContent('从队列拉取待处理任务')
  })

  it('深链进入时自动发起查询并把图灌进 store', async () => {
    renderBar('?nodes=N01&hop=1')
    await waitFor(() => expect(useGraphStore.getState().nodes).toHaveLength(2))
  })

  it('节点搜索失败时明说失败，而不是谎报「无匹配节点」', async () => {
    // 500、断网、真的没匹配 —— 三件事被压成同一句文案时，用户会以为节点不存在。
    // spec §11：不静默吞掉任何错误。
    const user = userEvent.setup()
    server.use(http.get('*/api/nodes/search', () =>
      HttpResponse.json({ success: false, data: null, error: '节点服务暂时不可用' }, { status: 500 })))

    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')

    expect(await screen.findByText('节点服务暂时不可用')).toBeInTheDocument()
    expect(screen.queryByText('无匹配节点')).not.toBeInTheDocument()
  })

  it('搜索恢复正常后错误提示消失', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')
    expect(await screen.findByText(/TASK PROCESSOR/)).toBeInTheDocument()
    expect(screen.queryByText(/暂时不可用/)).not.toBeInTheDocument()
  })
})

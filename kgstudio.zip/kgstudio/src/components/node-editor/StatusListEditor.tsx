import { Button, Input } from 'antd'
import './node-editor.css'

export interface StatusRow {
  key: string
  status_id?: string
  status_description: string
}

let tempSeq = 0
export const makeTempRow = (): StatusRow => ({ key: `tmp-${++tempSeq}`, status_description: '' })

interface StatusListEditorProps {
  rows: StatusRow[]
  onChange: (rows: StatusRow[]) => void
}

export function StatusListEditor({ rows, onChange }: StatusListEditorProps) {
  const patch = (key: string, description: string) =>
    onChange(rows.map(r => (r.key === key ? { ...r, status_description: description } : r)))

  return (
    <section className="status-editor">
      <div className="status-editor__head">
        <span className="panel__kicker">STATUS LIST · {rows.length}</span>
        <Button size="small" onClick={() => onChange([...rows, makeTempRow()])}>+ 添加状态</Button>
      </div>

      {rows.map((row, index) => (
        <div key={row.key} className="status-editor__row">
          <div className="status-editor__id">
            <span className="panel__kicker">STATUS ID</span>
            <span className="status-editor__id-value">{row.status_id ?? '待生成'}</span>
          </div>
          <div className="status-editor__desc">
            <span className="panel__kicker">DESCRIPTION</span>
            <Input.TextArea
              aria-label={`状态描述 ${index + 1}`}
              rows={2}
              value={row.status_description}
              onChange={e => patch(row.key, e.target.value)}
            />
          </div>
          <Button
            danger
            type="text"
            aria-label="删除该状态"
            onClick={() => onChange(rows.filter(r => r.key !== row.key))}
          >
            ✕
          </Button>
        </div>
      ))}
    </section>
  )
}

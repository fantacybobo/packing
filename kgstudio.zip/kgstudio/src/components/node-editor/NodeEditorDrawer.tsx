import { useEffect, useState } from 'react'
import { App as AntApp, Button, Drawer, Input, Popconfirm, Space } from 'antd'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import { errorMessage } from '@/lib/errors'
import { StatusListEditor, makeTempRow, type StatusRow } from './StatusListEditor'
import './node-editor.css'

export function NodeEditorDrawer() {
  const { message } = AntApp.useApp()
  const target = useUiStore(s => s.nodeEditor)
  const close = useUiStore(s => s.closeNodeEditor)
  const nodes = useGraphStore(s => s.nodes)
  const createNode = useGraphStore(s => s.createNode)
  const updateNode = useGraphStore(s => s.updateNode)
  const deleteNode = useGraphStore(s => s.deleteNode)

  const isEdit = target?.mode === 'edit'
  const existing = isEdit ? nodes.find(n => n.node_id === target.nodeId) : undefined

  const [entity, setEntity] = useState('')
  const [metrics, setMetrics] = useState('')
  const [rows, setRows] = useState<StatusRow[]>([])
  const [saving, setSaving] = useState(false)

  // 每次打开抽屉时重置表单；失败时不会走到这里，输入得以保留
  useEffect(() => {
    if (!target) return
    setEntity(existing?.entity ?? '')
    setMetrics(existing?.metrics ?? '')
    setRows(
      existing
        ? existing.status_list.map(s => ({
            key: s.status_id, status_id: s.status_id, status_description: s.status_description,
          }))
        : [makeTempRow()],
    )
  }, [target?.mode, target?.nodeId])

  const save = async () => {
    if (!target) return

    // 描述为空的行不能被悄悄滤掉。那等于把「清空这行文字」偷偷变成「删除这条状态」，
    // 而删除状态会级联清掉挂在它上面的边（见 store.updateNode）——
    // 用户从头到尾没碰过任何删除控件，边却没了。显式拦下，并把行留在原地给他改。
    const statusList = rows.map(r => ({
      status_id: r.status_id,
      status_description: r.status_description.trim(),
    }))
    if (statusList.some(s => !s.status_description)) {
      message.error('有状态描述为空，请填写或删除该行')
      return
    }

    setSaving(true)
    try {
      const payload = {
        entity: entity.trim(),
        metrics: metrics.trim(),
        tone: 'default' as const,
        status_list: statusList,
      }
      if (isEdit && target.nodeId) {
        await updateNode(target.nodeId, payload)
        message.success('节点已更新')
      } else {
        await createNode(payload)
        message.success('节点已创建')
      }
      close()
    } catch (e) {
      message.error(errorMessage(e, '保存失败'))
    } finally {
      setSaving(false)
    }
  }

  const remove = async () => {
    if (!target?.nodeId) return
    try {
      await deleteNode(target.nodeId)
      message.success('节点已删除')
      close()
    } catch (e) {
      message.error(errorMessage(e, '删除失败'))
    }
  }

  return (
    <Drawer
      open={!!target}
      onClose={close}
      size="33.33vw"
      styles={{ wrapper: { minWidth: 380 } }}
      closeIcon={false}
      title={
        <div>
          <div className="panel__kicker">{isEdit ? 'EDIT NODE' : 'NEW NODE'}</div>
          <div className="panel__id">{existing?.node_id ?? '待保存'}</div>
        </div>
      }
      extra={
        <button type="button" className="panel__close" aria-label="关闭" onClick={close}>
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true">
            <line x1="1" y1="1" x2="13" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="13" y1="1" x2="1" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </button>
      }
      footer={
        <div className="panel__footer">
          {isEdit ? (
            <Popconfirm
              title="确认删除该节点及其相连的边？"
              description="此操作不可撤销。"
              okText="确认删除"
              cancelText="取消"
              okButtonProps={{ danger: true }}
              onConfirm={remove}
            >
              <Button danger>删除节点</Button>
            </Popconfirm>
          ) : <span />}
          <Space>
            <Button onClick={close}>关闭</Button>
            <Button type="primary" loading={saving} onClick={save}>保存</Button>
          </Space>
        </div>
      }
    >
      <div className="panel__field">
        <span className="panel__kicker">ENTITY</span>
        <Input.TextArea aria-label="ENTITY" rows={1} value={entity} onChange={e => setEntity(e.target.value)} />
      </div>
      <div className="panel__field">
        <span className="panel__kicker">METRICS</span>
        <Input.TextArea aria-label="METRICS" rows={3} value={metrics} onChange={e => setMetrics(e.target.value)} />
      </div>
      <StatusListEditor rows={rows} onChange={setRows} />
    </Drawer>
  )
}

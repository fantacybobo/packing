import { describe, it, expect, vi, afterEach } from 'vitest'
import { ApiError } from '@/api/client'
import { errorMessage } from './errors'

afterEach(() => vi.restoreAllMocks())

describe('errorMessage', () => {
  it('ApiError 直接用后端给的文案，不记日志', () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {})
    expect(errorMessage(new ApiError('节点不存在', 404), '保存失败')).toBe('节点不存在')
    expect(spy).not.toHaveBeenCalled()
  })

  it('非 ApiError 的 Error 仍然展示 message，并把原始错误打进 console.error', () => {
    // 这是这个 helper 存在的理由：store 里的 TypeError（例如 layoutGraph 崩了）
    // 原本会被换成一句无关的固定文案，栈丢得一干二净。
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {})
    const bug = new TypeError('nodes.map is not a function')
    expect(errorMessage(bug, '查询失败')).toBe('nodes.map is not a function')
    expect(spy).toHaveBeenCalledWith(expect.any(String), bug)
  })

  it('抛出来的不是 Error 时回落到 fallback，同样留日志', () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {})
    expect(errorMessage('字符串异常', '保存失败')).toBe('保存失败')
    expect(spy).toHaveBeenCalledWith(expect.any(String), '字符串异常')
  })

  it('不传 fallback 时有默认文案', () => {
    vi.spyOn(console, 'error').mockImplementation(() => {})
    expect(errorMessage(undefined)).toBe('发生未知错误，请重试')
  })
})

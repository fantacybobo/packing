import { ApiError } from '@/api/client'

/**
 * 全应用唯一的「异常 → 用户可读文案」转换。
 *
 * 以前有两套：store 把任何非 ApiError 都换成一句固定文案（message、栈全丢，也不记日志），
 * 组件用 `e instanceof Error ? e.message : …`（会把 message 亮出来）。
 * 同一个故障，被哪一层接住决定了用户看到什么，而 layoutGraph 里的一个 TypeError
 * 走 store 那条路会彻底无声消失 —— 没有提示、没有日志、没有线索。
 *
 * 现在统一：ApiError 是后端给的、可直接展示的文案；其余都属于预期外的程序错误，
 * 照样展示 message（比固定文案有信息量），同时把原始对象打进 console.error 保住栈。
 */
export function errorMessage(e: unknown, fallback = '发生未知错误，请重试'): string {
  if (e instanceof ApiError) return e.message
  console.error('[kg-studio] 预期外的错误：', e)
  if (e instanceof Error && e.message) return e.message
  return fallback
}

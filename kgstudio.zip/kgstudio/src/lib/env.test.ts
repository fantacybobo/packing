import { describe, it, expect, vi, afterEach } from 'vitest'
import { shouldUseMock } from './env'

afterEach(() => vi.restoreAllMocks())

describe('shouldUseMock', () => {
  it('未设置时按 spec 的默认值启用 mock', () => {
    expect(shouldUseMock(undefined)).toBe(true)
    expect(shouldUseMock('')).toBe(true)
  })

  it("'true' / 'false' 按字面意思解释，允许大小写与空格", () => {
    expect(shouldUseMock('true')).toBe(true)
    expect(shouldUseMock(' TRUE ')).toBe(true)
    expect(shouldUseMock('false')).toBe(false)
    expect(shouldUseMock('False')).toBe(false)
  })

  it('认不出来的值一律不启用 mock，并且发出警告', () => {
    // 旧写法是 `!== 'false'`：VITE_USE_MOCK=0 会静默启用 mock，
    // 于是一个自以为连着真实后端的环境，满屏都是编造的数据。
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    for (const raw of ['0', 'off', 'no', 'FALSE!', '1']) {
      expect(shouldUseMock(raw)).toBe(false)
    }
    expect(warn).toHaveBeenCalledTimes(5)
  })
})

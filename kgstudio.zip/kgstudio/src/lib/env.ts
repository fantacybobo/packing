/** 只认 'true' / 'false' 两个值；缺省（未设置）时按 spec 的默认值走 mock。 */
const DEFAULT_USE_MOCK = true

/**
 * 判断是否启动 MSW worker。
 *
 * 原来的写法是 `import.meta.env.VITE_USE_MOCK !== 'false'`，失败方向是「开」：
 * VITE_USE_MOCK=0 / off / FALSE 都会静默启用 mock，于是一个以为自己连着真实后端的
 * 环境，界面上摆的全是编造出来的数据，而且看起来一模一样。
 * 认不出来的值一律按「不启用 mock」处理，并且吼一声。
 */
export function shouldUseMock(raw: unknown): boolean {
  if (raw === undefined || raw === null || raw === '') return DEFAULT_USE_MOCK
  const value = String(raw).trim().toLowerCase()
  if (value === 'true') return true
  if (value === 'false') return false
  console.warn(
    `[kg-studio] VITE_USE_MOCK=${JSON.stringify(raw)} 无法识别，只接受 'true' / 'false'；` +
    '本次按 false 处理（不启用 mock，直接走真实后端）。',
  )
  return false
}

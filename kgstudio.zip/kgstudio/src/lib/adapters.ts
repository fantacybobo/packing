import type { Connection, Edge, Node } from '@xyflow/react'
import type { EdgePayload, GraphEdge, GraphNode } from '@/types/graph'
import type { XY } from './layout'

export interface StatusNodeData extends Record<string, unknown> {
  node: GraphNode
}

export type StatusFlowNode = Node<StatusNodeData, 'statusNode'>

export function toFlowNodes(nodes: GraphNode[], positions: Record<string, XY>): StatusFlowNode[] {
  return nodes.map(node => ({
    id: node.node_id,
    type: 'statusNode' as const,
    position: positions[node.node_id] ?? { x: 0, y: 0 },
    // 只有标题栏能拖动整个节点。状态行两侧是连线用的 handle，
    // 若整张卡片都可拖拽，用户想拉连线时稍微偏一点就会把节点拖走。
    // 这也让标题栏的 cursor: grab 名副其实。
    dragHandle: '.status-node__bar',
    data: { node },
  }))
}

export function toFlowEdges(edges: GraphEdge[]): Edge[] {
  return edges.map(edge => ({
    id: edge.edge_id,
    type: 'priorityEdge',
    source: edge.from_node_id,
    target: edge.to_node_id,
    sourceHandle: edge.from_status_id,
    targetHandle: edge.to_status_id,
    data: { priority: edge.priority, tone: edge.tone },
  }))
}

export function connectionToPayload(c: Connection, priority: number): EdgePayload | null {
  if (!c.source || !c.target || !c.sourceHandle || !c.targetHandle) return null
  return {
    from_node_id: c.source,
    to_node_id: c.target,
    from_status_id: c.sourceHandle,
    to_status_id: c.targetHandle,
    priority,
    tone: 'default',
  }
}

export function isSelfLoop(c: Connection): boolean {
  return c.source === c.target && c.sourceHandle === c.targetHandle
}

export function findDuplicateEdge(edges: GraphEdge[], c: Connection): GraphEdge | undefined {
  return edges.find(
    e =>
      e.from_node_id === c.source &&
      e.to_node_id === c.target &&
      e.from_status_id === c.sourceHandle &&
      e.to_status_id === c.targetHandle,
  )
}

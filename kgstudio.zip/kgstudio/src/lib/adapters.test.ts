import { describe, it, expect } from 'vitest'
import type { Connection } from '@xyflow/react'
import { toFlowNodes, toFlowEdges, connectionToPayload, findDuplicateEdge, isSelfLoop } from './adapters'
import type { GraphEdge, GraphNode } from '@/types/graph'

const node: GraphNode = {
  node_id: 'N01', entity: 'TASK', metrics: '描述', tone: 'default', document_id: ['DOC-1'],
  status_list: [{ status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' }],
}

const edge: GraphEdge = {
  edge_id: 'E001', from_node_id: 'N01', to_node_id: 'N02',
  from_status_id: 'N01-ST01', to_status_id: 'N02-ST01', priority: 7, tone: 'default',
}

const connection = (over: Partial<Connection> = {}): Connection => ({
  source: 'N01', target: 'N02', sourceHandle: 'N01-ST01', targetHandle: 'N02-ST01', ...over,
})

describe('toFlowNodes', () => {
  it('node_id 作为 React Flow 的 id，原始节点挂在 data 上', () => {
    const [flow] = toFlowNodes([node], { N01: { x: 10, y: 20 } })
    expect(flow.id).toBe('N01')
    expect(flow.type).toBe('statusNode')
    expect(flow.data.node).toBe(node)
    expect(flow.position).toEqual({ x: 10, y: 20 })
  })

  it('dragHandle 限定为标题栏，避免拖拽状态行上的 handle 时带走整个节点', () => {
    const [flow] = toFlowNodes([node], {})
    expect(flow.dragHandle).toBe('.status-node__bar')
  })

  it('缺少坐标的节点回落到原点而不是 undefined', () => {
    const [flow] = toFlowNodes([node], {})
    expect(flow.position).toEqual({ x: 0, y: 0 })
  })
})

describe('toFlowEdges', () => {
  it('status_id 直接作为 sourceHandle / targetHandle', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.id).toBe('E001')
    expect(flow.source).toBe('N01')
    expect(flow.target).toBe('N02')
    expect(flow.sourceHandle).toBe('N01-ST01')
    expect(flow.targetHandle).toBe('N02-ST01')
  })

  it('priority 传进 data 供自定义边渲染标签', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.data?.priority).toBe(7)
    expect(flow.type).toBe('priorityEdge')
  })
})

describe('connectionToPayload', () => {
  it('把 React Flow 的 Connection 映射成建边入参', () => {
    expect(connectionToPayload(connection(), 5)).toEqual({
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 5, tone: 'default',
    })
  })

  it('缺少 handle 时返回 null，不产生残缺的边', () => {
    expect(connectionToPayload(connection({ sourceHandle: null }), 1)).toBeNull()
    expect(connectionToPayload(connection({ targetHandle: null }), 1)).toBeNull()
  })
})

describe('isSelfLoop', () => {
  it('同一个 status 自连视为非法', () => {
    expect(isSelfLoop(connection({ target: 'N01', targetHandle: 'N01-ST01' }))).toBe(true)
  })

  it('同节点不同 status 之间允许连线', () => {
    expect(isSelfLoop(connection({ target: 'N01', targetHandle: 'N01-ST02' }))).toBe(false)
  })

  it('不同节点之间不是自连', () => {
    expect(isSelfLoop(connection())).toBe(false)
  })
})

describe('findDuplicateEdge', () => {
  it('同一对 status 之间已有边时能找出来', () => {
    expect(findDuplicateEdge([edge], connection())).toBe(edge)
  })

  it('目标 status 不同则不算重复', () => {
    expect(findDuplicateEdge([edge], connection({ targetHandle: 'N02-ST02' }))).toBeUndefined()
  })

  it('方向相反不算重复', () => {
    const reversed = connection({
      source: 'N02', target: 'N01', sourceHandle: 'N02-ST01', targetHandle: 'N01-ST01',
    })
    expect(findDuplicateEdge([edge], reversed)).toBeUndefined()
  })
})

import { describe, it, expect } from 'vitest'
import { NODE_WIDTH, estimateNodeHeight, layoutGraph, placeNewNode } from './layout'
import type { GraphEdge, GraphNode } from '@/types/graph'

const makeNode = (id: string, statusCount: number, metrics = '短描述'): GraphNode => ({
  node_id: id, entity: id, metrics, tone: 'default', document_id: [],
  status_list: Array.from({ length: statusCount }, (_, i) => ({
    status_id: `${id}-ST${i}`, node_id: id, status_description: 'Active',
  })),
})

const makeEdge = (from: string, to: string): GraphEdge => ({
  edge_id: `${from}->${to}`, from_node_id: from, to_node_id: to,
  from_status_id: `${from}-ST0`, to_status_id: `${to}-ST0`,
  priority: 1, tone: 'default',
})

describe('estimateNodeHeight', () => {
  it('单行描述、单状态时套用设计稿公式', () => {
    // charsPerLine = max(8, floor((330-28)/13)) = 23；lines = 1
    // headHeight = 10+22+4+1*19+10 = 65
    // height = 32+65+24+1*34+0 = 155
    expect(estimateNodeHeight(makeNode('A', 1))).toBe(155)
  })

  it('状态越多节点越高', () => {
    expect(estimateNodeHeight(makeNode('A', 4))).toBeGreaterThan(estimateNodeHeight(makeNode('A', 1)))
  })

  it('长描述换行后节点更高', () => {
    const long = 'x'.repeat(100)
    expect(estimateNodeHeight(makeNode('A', 1, long))).toBeGreaterThan(estimateNodeHeight(makeNode('A', 1)))
  })

  it('空描述也至少占一行，不会得到比单行更矮的高度', () => {
    expect(estimateNodeHeight(makeNode('A', 1, ''))).toBe(155)
  })
})

describe('layoutGraph', () => {
  it('为每个节点都产出坐标', () => {
    const nodes = [makeNode('A', 2), makeNode('B', 2)]
    const positions = layoutGraph(nodes, [makeEdge('A', 'B')])
    expect(Object.keys(positions).sort()).toEqual(['A', 'B'])
  })

  it('按 LR 方向分层：下游节点在上游右侧', () => {
    const nodes = [makeNode('A', 2), makeNode('B', 2)]
    const positions = layoutGraph(nodes, [makeEdge('A', 'B')])
    expect(positions.B.x).toBeGreaterThan(positions.A.x + NODE_WIDTH)
  })

  it('孤立节点也有坐标而不是 undefined', () => {
    const positions = layoutGraph([makeNode('A', 1), makeNode('LONE', 1)], [])
    expect(positions.LONE).toBeDefined()
    expect(Number.isFinite(positions.LONE.x)).toBe(true)
  })

  it('端点不在节点集合内的边被过滤掉，dagre 不会因缺少尺寸而抛错', () => {
    // 真实信号是「不抛错」：输出恒由 nodes.map 构造，所以即使不过滤也不会多出 GHOST 键；
    // 但不过滤时 setEdge 会凭空建出无尺寸的 GHOST 节点，dagre.layout 读 width 时会抛。
    const run = () => layoutGraph([makeNode('A', 1)], [makeEdge('A', 'GHOST')])
    expect(run).not.toThrow()
    expect(Object.keys(run())).toEqual(['A'])
  })

  it('返回左上角坐标：高度不同的两个节点应中心对齐，而非顶部对齐', () => {
    // 这是唯一能区分「中心点」与「左上角」的断言形状。
    // dagre 让相邻 rank 的节点中心对齐：若直接返回中心点，两者 y 相等（顶部对齐的假象）；
    // 正确换算成左上角后 y 不相等，但各自 y + 自身高度/2 相等。
    // 只断言 x/y >= 0 是抓不到这个回退的 —— dagre 的中心点同样非负。
    const short = makeNode('SHORT', 1)
    const tall = makeNode('TALL', 4)
    const positions = layoutGraph([short, tall], [makeEdge('SHORT', 'TALL')])

    expect(positions.SHORT.y).not.toBe(positions.TALL.y)
    expect(positions.SHORT.y + estimateNodeHeight(short) / 2).toBeCloseTo(
      positions.TALL.y + estimateNodeHeight(tall) / 2,
      5,
    )
  })

  it('空输入返回空对象', () => {
    expect(layoutGraph([], [])).toEqual({})
  })
})

describe('placeNewNode', () => {
  it('放在现有节点最右侧之外，避免重叠', () => {
    const spot = placeNewNode({ A: { x: 0, y: 0 }, B: { x: 500, y: 200 } })
    expect(spot.x).toBeGreaterThan(500 + NODE_WIDTH)
  })

  it('画布为空时给一个确定的起始位置', () => {
    expect(placeNewNode({})).toEqual({ x: 0, y: 0 })
  })
})

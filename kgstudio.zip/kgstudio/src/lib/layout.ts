import dagre from '@dagrejs/dagre'
import type { GraphEdge, GraphNode } from '@/types/graph'

export const NODE_WIDTH = 330

const BAR_HEIGHT = 32
const BODY_PADDING = 24
const ROW_HEIGHT = 34
const ROW_GAP = 8
const NEW_NODE_GAP = 160

// 标题区的构成。这几个值必须与 Task 11 的 StatusNode 实际渲染一一对应：
// 两边一旦漂移，dagre 预留的垂直空间就是错的，连线会挂在视觉上偏移的位置。
const HEAD_PADDING_TOP = 10      // .status-node__head 的上内边距
const TITLE_LINE_HEIGHT = 22     // entity 标题 18px × 1.2 行高
const TITLE_METRICS_GAP = 4      // .status-node__metrics 的 margin-top
const METRICS_LINE_HEIGHT = 19   // metrics 13px × 1.45 行高
const HEAD_PADDING_BOTTOM = 10   // 标题区与状态区之间的留白
const HEAD_SIDE_PADDING = 28     // 左右各 14px
const METRICS_CHAR_WIDTH = 13    // 单个中文字符的估算宽度
const MIN_CHARS_PER_LINE = 8     // 极窄卡片下的兜底，避免除出 0

// 已知且刻意保留的残差：单状态卡片下，本公式给出 155px，实际渲染约 156.45px。
// 差值 ~1.45px 主要是 .status-node 卡片自身的 1px 上下外框（共 2px），
// 十个命名常量里没有一个代表它；行高估算的四舍五入（21.6→22、18.85→19）
// 又把差值往回抵了一点，两者相抵后剩下约 1.45px。
// 量级远小于 dagre 的行/列间距（ranksep/nodesep），不影响布局，故不为这 2px 外框单独加常量，
// 也不要为了让这条注释"对上"而去反推、微调上面的常量——那样反而会破坏已经对齐的部分。

export interface XY { x: number; y: number }

/** 与设计稿一致的高度估算，详见 spec 第 7 节 */
export function estimateNodeHeight(node: GraphNode): number {
  const charsPerLine = Math.max(
    MIN_CHARS_PER_LINE,
    Math.floor((NODE_WIDTH - HEAD_SIDE_PADDING) / METRICS_CHAR_WIDTH),
  )
  const lines = Math.max(1, Math.ceil(node.metrics.length / charsPerLine))
  const headHeight =
    HEAD_PADDING_TOP + TITLE_LINE_HEIGHT + TITLE_METRICS_GAP +
    lines * METRICS_LINE_HEIGHT + HEAD_PADDING_BOTTOM
  const count = node.status_list.length
  return BAR_HEIGHT + headHeight + BODY_PADDING + count * ROW_HEIGHT + Math.max(0, count - 1) * ROW_GAP
}

export function layoutGraph(nodes: GraphNode[], edges: GraphEdge[]): Record<string, XY> {
  if (nodes.length === 0) return {}

  const graph = new dagre.graphlib.Graph()
  graph.setGraph({ rankdir: 'LR', nodesep: 60, ranksep: 160, marginx: 40, marginy: 40 })
  graph.setDefaultEdgeLabel(() => ({}))

  const heights = new Map<string, number>()
  for (const node of nodes) {
    const height = estimateNodeHeight(node)
    heights.set(node.node_id, height)
    graph.setNode(node.node_id, { width: NODE_WIDTH, height })
  }

  const known = new Set(nodes.map(n => n.node_id))
  for (const edge of edges) {
    if (known.has(edge.from_node_id) && known.has(edge.to_node_id)) {
      graph.setEdge(edge.from_node_id, edge.to_node_id)
    }
  }

  dagre.layout(graph)

  // dagre 返回的是中心点，React Flow 用的是左上角
  return Object.fromEntries(
    nodes.map(node => {
      const laid = graph.node(node.node_id)
      const height = heights.get(node.node_id)!
      return [node.node_id, { x: laid.x - NODE_WIDTH / 2, y: laid.y - height / 2 }]
    }),
  )
}

/** 新建节点放到现有布局的右侧空白处，避免重排已有节点 */
export function placeNewNode(positions: Record<string, XY>): XY {
  const all = Object.values(positions)
  if (all.length === 0) return { x: 0, y: 0 }
  const maxX = Math.max(...all.map(p => p.x))
  const minY = Math.min(...all.map(p => p.y))
  return { x: maxX + NODE_WIDTH + NEW_NODE_GAP, y: minY }
}

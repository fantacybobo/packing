import { AppShell } from './components/app-shell/AppShell'
import { SearchBar } from './components/search-bar/SearchBar'
import { GraphCanvas } from './components/graph/GraphCanvas'
import { NodeEditorDrawer } from './components/node-editor/NodeEditorDrawer'
import { EdgeEditorModal } from './components/edge-editor/EdgeEditorModal'
import { DocumentDrawer } from './components/document/DocumentDrawer'

export default function App() {
  return (
    <AppShell toolbar={<SearchBar />}>
      <GraphCanvas />
      <NodeEditorDrawer />
      <EdgeEditorModal />
      <DocumentDrawer />
    </AppShell>
  )
}

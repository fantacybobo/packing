import { useCallback, useEffect, useRef, useState } from 'react'
import { parseAsInteger, parseAsString, useQueryStates } from 'nuqs'
import { useGraphStore } from '@/store/useGraphStore'
import { HOP_DEFAULT, clampHop, parseNodeIds, sanitizeNodeIds, serializeNodeIds } from './queryParams'

/**
 * URL 是查询状态的唯一来源。
 * 提交查询 = 写 URL；真正发请求的是监听 URL 的 effect。
 * 这样「点搜索」「粘贴链接」「浏览器前进后退」共用同一条代码路径。
 *
 * 只读参数，无任何副作用，可以被多个组件同时调用。
 */
export function useGraphQueryParams() {
  const [params, setParams] = useQueryStates(
    {
      nodes: parseAsString.withDefault(''),
      hop: parseAsInteger.withDefault(HOP_DEFAULT),
    },
    { clearOnDefault: true },
  )

  const rawHop = params.hop
  const nodeIds = parseNodeIds(params.nodes)
  const hop = clampHop(rawHop)

  // 用 useCallback 稳定引用：这是本文件唯一对外、供多个组件消费的回调，
  // 不稳定的引用会让消费方的 memo / 依赖数组失效。
  const commitQuery = useCallback(
    (ids: string[], nextHop: number) => {
      // 写入端与 hop 一样做边界净化。
      // 读取端的 parseNodeIds 只防「脏 URL」，防不住调用方传进来的重复或超量 id；
      // 而 nodes 没有像 hop 那样的写回清洗 effect，脏值会一直留在 URL 里，
      // 破坏「URL 恒等于画布当前展示的查询」这条不变量。
      void setParams(
        { nodes: serializeNodeIds(sanitizeNodeIds(ids)), hop: clampHop(nextHop) },
        { history: 'push' },
      )
    },
    [setParams],
  )

  return { nodeIds, hop, rawHop, setParams, commitQuery }
}

/**
 * 独占「URL 变化 → 发起查询」这个副作用。
 * 全应用只能调用一次，否则每次 URL 变化会重复发请求。当前唯一调用方是 SearchBar。
 */
export function useGraphQuerySync() {
  const { nodeIds, hop, rawHop, setParams, commitQuery: writeQuery } = useGraphQueryParams()
  const searchGraph = useGraphStore(s => s.searchGraph)
  const reset = useGraphStore(s => s.reset)

  // URL 里的 hop 越界时，清洗后原地写回，不产生新的历史记录
  useEffect(() => {
    if (rawHop !== hop) void setParams({ hop }, { history: 'replace' })
  }, [rawHop, hop, setParams])

  // nodeIds 每次渲染都是新数组，所以依赖用序列化后的字符串，避免 effect 反复触发
  const queryKey = `${serializeNodeIds(nodeIds)}|${hop}`
  const lastKey = useRef<string | null>(null)

  // 提交计数器。查询参数没改时 queryKey 不变，effect 的依赖数组也不变，
  // effect 根本不会重新执行 —— 所以「失败后原样再点一次搜索」需要一个独立于 URL 的信号
  // 把 effect 推起来。发不发请求仍然由下面的 lastKey 守卫决定，普通重渲染不会碰这个计数器。
  const [submitSeq, setSubmitSeq] = useState(0)

  const commitQuery = useCallback(
    (ids: string[], nextHop: number) => {
      writeQuery(ids, nextHop)
      setSubmitSeq(seq => seq + 1)
    },
    [writeQuery],
  )

  useEffect(() => {
    if (lastKey.current === queryKey) return
    lastKey.current = queryKey
    const [ids, nextHop] = [parseNodeIds(queryKey.split('|')[0]), Number(queryKey.split('|')[1])]
    if (ids.length === 0) {
      reset()
      return
    }
    void searchGraph(ids, nextHop).then(() => {
      // 失败后放开守卫，让同一组参数能再提交一次。
      // 否则用户点「搜索」会完全没有反应：URL 没变 → queryKey 没变 → 守卫 return，
      // 不发请求、没有 loading、没有报错。成功时守卫照旧挡住重复提交。
      if (useGraphStore.getState().status === 'error') lastKey.current = null
    })
  }, [queryKey, submitSeq, searchGraph, reset])

  return { nodeIds, hop, commitQuery }
}

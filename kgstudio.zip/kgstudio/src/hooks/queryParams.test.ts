import { describe, it, expect } from 'vitest'
import {
  HOP_DEFAULT, HOP_MAX, HOP_MIN,
  clampHop, parseNodeIds, sanitizeNodeIds, serializeNodeIds,
} from './queryParams'

describe('clampHop', () => {
  it('合法整数原样返回', () => {
    expect(clampHop(3)).toBe(3)
  })

  it('小于下界时收敛到下界', () => {
    expect(clampHop(0)).toBe(HOP_MIN)
    expect(clampHop(-5)).toBe(HOP_MIN)
  })

  it('大于上界时收敛到上界', () => {
    expect(clampHop(99)).toBe(HOP_MAX)
  })

  it('小数向下取整', () => {
    expect(clampHop(2.9)).toBe(2)
  })

  it('非数字回落到默认值', () => {
    expect(clampHop(null)).toBe(HOP_DEFAULT)
    expect(clampHop(undefined)).toBe(HOP_DEFAULT)
    expect(clampHop('abc')).toBe(HOP_DEFAULT)
    expect(clampHop(NaN)).toBe(HOP_DEFAULT)
  })

  it('数字字符串可以接受', () => {
    expect(clampHop('4')).toBe(4)
  })
})

describe('parseNodeIds', () => {
  it('逗号分隔解析成数组', () => {
    expect(parseNodeIds('N01,N04')).toEqual(['N01', 'N04'])
  })

  it('去掉空白与空项', () => {
    expect(parseNodeIds(' N01 , , N04 ')).toEqual(['N01', 'N04'])
  })

  it('超过两个时只取前两个', () => {
    expect(parseNodeIds('N01,N02,N03,N04')).toEqual(['N01', 'N02'])
  })

  it('去重，避免把同一个节点传两次', () => {
    expect(parseNodeIds('N01,N01')).toEqual(['N01'])
  })

  it('空值返回空数组', () => {
    expect(parseNodeIds(null)).toEqual([])
    expect(parseNodeIds('')).toEqual([])
    expect(parseNodeIds(' , ')).toEqual([])
  })
})

describe('sanitizeNodeIds', () => {
  it('去重后再截断，两条规则叠加时结果正确', () => {
    expect(sanitizeNodeIds(['N01', 'N01', 'N02', 'N03'])).toEqual(['N01', 'N02'])
  })

  it('与 parseNodeIds 使用同一套规则，读写两端不会漂移', () => {
    expect(sanitizeNodeIds([' N01 ', '', 'N04'])).toEqual(parseNodeIds(' N01 , , N04 '))
  })
})

describe('serializeNodeIds', () => {
  it('用逗号拼接', () => {
    expect(serializeNodeIds(['N01', 'N04'])).toBe('N01,N04')
  })

  it('空数组序列化成空串，便于 nuqs 从 URL 清除该参数', () => {
    expect(serializeNodeIds([])).toBe('')
  })
})

import { describe, it, expect, afterEach, beforeEach, vi } from 'vitest'
import type { ReactNode } from 'react'
import { act, renderHook, waitFor } from '@testing-library/react'
import { NuqsTestingAdapter, type UrlUpdateEvent } from 'nuqs/adapters/testing'
import { useGraphStore } from '@/store/useGraphStore'
import { useGraphQuerySync } from './useGraphQuery'

function wrapper({ children }: { children: ReactNode }) {
  return (
    <NuqsTestingAdapter searchParams="?nodes=N01&hop=1" hasMemory>
      {children}
    </NuqsTestingAdapter>
  )
}

// reset() 只还原 state 字段，不还原被换掉的 action ——
// 少了这个 afterEach，下一个用例会继承上一个用例装进 store 的 searchGraph mock。
const realSearchGraph = useGraphStore.getState().searchGraph

describe('useGraphQuerySync', () => {
  beforeEach(() => {
    useGraphStore.getState().reset()
  })

  afterEach(() => {
    useGraphStore.setState({ searchGraph: realSearchGraph })
  })

  it('URL 未变化时不重复发起查询；提交新查询后才再次触发', () => {
    const searchGraph = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => {},
    )
    useGraphStore.setState({ searchGraph })

    const { result, rerender } = renderHook(() => useGraphQuerySync(), { wrapper })

    // 挂载即按 URL 里的初始查询发起一次请求
    expect(searchGraph).toHaveBeenCalledTimes(1)
    expect(searchGraph).toHaveBeenCalledWith(['N01'], 1)

    // 再渲染两次，URL 没变——nodeIds 每次都是新数组，但不应该重复发请求
    rerender()
    rerender()
    expect(searchGraph).toHaveBeenCalledTimes(1)

    // 提交一次真正的新查询：这时才应该再发一次请求
    act(() => {
      result.current.commitQuery(['N04'], 2)
    })

    expect(searchGraph).toHaveBeenCalledTimes(2)
    expect(searchGraph).toHaveBeenLastCalledWith(['N04'], 2)
  })

  // queryKey 没变，但 searchGraph 的引用变了（例如 store 被替换/热更新）时，
  // lastKey ref 是唯一挡住重复请求的东西——effect 的依赖数组本身会因为
  // searchGraph 引用变化而判定为「变了」，从而重新执行 effect 函数体。
  it('查询没变时，即使 store 里的 searchGraph 引用发生变化，也不会用新引用重复发起同一次查询', () => {
    const searchGraph1 = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => {},
    )
    useGraphStore.setState({ searchGraph: searchGraph1 })

    renderHook(() => useGraphQuerySync(), { wrapper })
    expect(searchGraph1).toHaveBeenCalledTimes(1)
    expect(searchGraph1).toHaveBeenCalledWith(['N01'], 1)

    // 换一个新的 searchGraph 引用，触发依赖 searchGraph 的 effect 重新求值，
    // 但 URL/查询本身（queryKey）完全没变
    const searchGraph2 = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => {},
    )
    act(() => {
      useGraphStore.setState({ searchGraph: searchGraph2 })
    })

    expect(searchGraph2).not.toHaveBeenCalled()
    expect(searchGraph1).toHaveBeenCalledTimes(1)
  })

  // 读回来的 nodeIds 会经过 parseNodeIds，脏值在读取端也会被净化，
  // 所以不能靠 nodeIds 或 searchGraph 的调用参数分辨 commitQuery 写入前
  // 有没有净化——必须直接看写进 URL 的原始字符串。
  it('commitQuery 写入 URL 前会净化 node ids：去重、截断到两个；hop 等于默认值时被清除', async () => {
    const searchGraph = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => {},
    )
    useGraphStore.setState({ searchGraph })

    const onUrlUpdate = vi.fn<(event: UrlUpdateEvent) => void>()
    const { result } = renderHook(() => useGraphQuerySync(), {
      wrapper: ({ children }) => (
        <NuqsTestingAdapter searchParams="?nodes=N01&hop=1" hasMemory onUrlUpdate={onUrlUpdate}>
          {children}
        </NuqsTestingAdapter>
      ),
    })

    // 传入重复 id 且超过两个上限
    act(() => {
      result.current.commitQuery(['N01', 'N01', 'N02', 'N03'], 2)
    })

    // URL 写入走的是节流队列，onUrlUpdate 不会和 commitQuery 同步触发
    await waitFor(() => expect(onUrlUpdate).toHaveBeenCalledTimes(1))

    const [event] = onUrlUpdate.mock.calls[0]
    expect(event.searchParams.get('nodes')).toBe('N01,N02')
    // hop 传入 2，等于 HOP_DEFAULT，clearOnDefault 应该让它从 URL 里消失
    expect(event.searchParams.has('hop')).toBe(false)
  })

  // 查询失败 → 用户什么都不改，再点一次「搜索」。这是最自然的反应，
  // 旧实现下 commitQuery 写回同样的 URL，queryKey 没变，守卫直接 return：
  // 不发请求、没有 loading、没有报错，按钮像坏了一样。
  it('查询失败后，原样重提同一组参数会真的再发一次请求', async () => {
    const searchGraph = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => { useGraphStore.setState({ status: 'error', error: '后端炸了' }) },
    )
    useGraphStore.setState({ searchGraph })

    const { result } = renderHook(() => useGraphQuerySync(), { wrapper })
    await waitFor(() => expect(useGraphStore.getState().status).toBe('error'))
    expect(searchGraph).toHaveBeenCalledTimes(1)

    await act(async () => { result.current.commitQuery(['N01'], 1) })

    await waitFor(() => expect(searchGraph).toHaveBeenCalledTimes(2))
    expect(searchGraph).toHaveBeenLastCalledWith(['N01'], 1)
  })

  // 上一条的反面：放行只限于「上一次失败了」，成功后的重复提交仍然要被守卫挡住，
  // 否则就把守卫当初要防的重复请求又放回来了。
  it('查询成功后原样重提同一组参数，不会重复发请求', async () => {
    const searchGraph = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(
      async () => { useGraphStore.setState({ status: 'ready' }) },
    )
    useGraphStore.setState({ searchGraph })

    const { result, rerender } = renderHook(() => useGraphQuerySync(), { wrapper })
    await waitFor(() => expect(useGraphStore.getState().status).toBe('ready'))
    expect(searchGraph).toHaveBeenCalledTimes(1)

    await act(async () => { result.current.commitQuery(['N01'], 1) })
    rerender()
    await act(async () => {})

    expect(searchGraph).toHaveBeenCalledTimes(1)
  })
})

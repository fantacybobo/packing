export const HOP_MIN = 1
export const HOP_MAX = 6
export const HOP_DEFAULT = 2

const MAX_SEEDS = 2

export function clampHop(raw: unknown): number {
  const value = typeof raw === 'string' ? Number(raw) : raw
  if (typeof value !== 'number' || !Number.isFinite(value)) return HOP_DEFAULT
  return Math.min(HOP_MAX, Math.max(HOP_MIN, Math.floor(value)))
}

export function parseNodeIds(raw: string | null): string[] {
  if (!raw) return []
  const cleaned = raw.split(',').map(s => s.trim()).filter(Boolean)
  return [...new Set(cleaned)].slice(0, MAX_SEEDS)
}

export function serializeNodeIds(ids: string[]): string {
  return ids.join(',')
}

/**
 * 写入端净化：去空、去重、截断到 2 个。
 * 复用 parseNodeIds 的规则，保证读写两端不会各自漂移。
 */
export function sanitizeNodeIds(ids: string[]): string[] {
  return parseNodeIds(ids.join(','))
}

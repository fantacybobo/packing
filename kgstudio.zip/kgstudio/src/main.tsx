import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { ConfigProvider, App as AntApp } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import { NuqsAdapter } from 'nuqs/adapters/react'
import '@xyflow/react/dist/style.css'
import './styles/global.css'
import { antdTheme } from './theme'
import { shouldUseMock } from './lib/env'
import App from './App'

async function bootstrap() {
  if (shouldUseMock(import.meta.env.VITE_USE_MOCK)) {
    const { worker } = await import('./mocks/browser')
    await worker.start({ onUnhandledRequest: 'bypass' })
  }
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <NuqsAdapter>
        <ConfigProvider theme={antdTheme} locale={zhCN} button={{ autoInsertSpace: false }}>
          <AntApp>
            <App />
          </AntApp>
        </ConfigProvider>
      </NuqsAdapter>
    </StrictMode>,
  )
}

void bootstrap()

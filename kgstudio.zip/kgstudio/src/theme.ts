import { theme, type ThemeConfig } from 'antd'
import type { Tone } from '@/types/graph'

export const TONE_COLORS: Record<Tone, { border: string; accent: string }> = {
  default: { border: '#233442', accent: '#4ade80' },
}

export const antdTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorBgBase: '#070c12',
    colorBgContainer: '#0d151d',
    colorBgElevated: '#0b131b',
    colorBorder: '#23323f',
    colorBorderSecondary: '#1d2b38',
    colorText: '#c9d6e3',
    colorTextHeading: '#e9f1f8',
    colorPrimary: '#3d7fa8',
    colorError: '#dc2626',
    borderRadius: 6,
    fontSize: 13,
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Helvetica, sans-serif",
    fontFamilyCode: "'JetBrains Mono', ui-monospace, monospace",
  },
}

import { deleteJson, getJson, postJson, putJson } from './client'
import type {
  EdgePayload, GraphEdge, GraphNode, GraphQueryRequest,
  GraphQueryResponse, NodeDocument, NodePayload,
} from '@/types/graph'

export const searchNodes = (q: string) =>
  getJson<GraphNode[]>(`/nodes/search?q=${encodeURIComponent(q)}`)

export const queryGraph = (req: GraphQueryRequest) =>
  postJson<GraphQueryResponse>('/graph/query', req)

export const createNodeApi = (payload: NodePayload) =>
  postJson<GraphNode>('/nodes', payload)

export const updateNodeApi = (nodeId: string, payload: NodePayload) =>
  putJson<GraphNode>(`/nodes/${encodeURIComponent(nodeId)}`, payload)

export const deleteNodeApi = (nodeId: string) =>
  deleteJson<{ deleted_edge_ids: string[] }>(`/nodes/${encodeURIComponent(nodeId)}`)

export const createEdgeApi = (payload: EdgePayload) =>
  postJson<GraphEdge>('/edges', payload)

export const updateEdgeApi = (edgeId: string, payload: EdgePayload) =>
  putJson<GraphEdge>(`/edges/${encodeURIComponent(edgeId)}`, payload)

export const deleteEdgeApi = (edgeId: string) =>
  deleteJson<{ edge_id: string }>(`/edges/${encodeURIComponent(edgeId)}`)

export const getDocument = (documentId: string) =>
  getJson<NodeDocument>(`/documents/${encodeURIComponent(documentId)}`)

export const updateDocument = (doc: NodeDocument) =>
  putJson<NodeDocument>(`/documents/${encodeURIComponent(doc.document_id)}`, doc)

import { describe, it, expect } from 'vitest'
import {
  searchNodes, queryGraph, createNodeApi, updateNodeApi, deleteNodeApi,
  createEdgeApi, updateEdgeApi, deleteEdgeApi, getDocument, updateDocument,
} from './graph'
import { ApiError } from './client'

describe('searchNodes', () => {
  it('按关键字模糊匹配 entity 与 metrics', async () => {
    const result = await searchNodes('DECISION')
    expect(result.map(n => n.node_id)).toEqual(['N02'])
  })

  it('关键字为空时返回全部节点', async () => {
    expect(await searchNodes('')).toHaveLength(4)
  })
})

describe('queryGraph', () => {
  it('把 node_ids 与 hop 一起发给后端', async () => {
    const result = await queryGraph({ node_ids: ['N01'], hop: 1 })
    expect(result.nodes.map(n => n.node_id).sort()).toEqual(['N01', 'N02'])
  })

  it('node_ids 为空时抛出 ApiError', async () => {
    await expect(queryGraph({ node_ids: [], hop: 2 })).rejects.toThrow(ApiError)
  })
})

describe('节点写操作', () => {
  it('新建节点由后端生成 node_id 与 status_id', async () => {
    const created = await createNodeApi({
      entity: 'NEW ENTITY', metrics: '新节点描述', tone: 'default',
      status_list: [{ status_description: 'Pending' }],
    })
    expect(created.node_id).toBeTruthy()
    expect(created.status_list[0].status_id).toBeTruthy()
    expect(created.status_list[0].node_id).toBe(created.node_id)
  })

  it('编辑节点返回更新后的完整节点', async () => {
    const updated = await updateNodeApi('N01', {
      entity: 'RENAMED', metrics: '改过的描述', tone: 'default',
      status_list: [{ status_id: 'N01-ST01', status_description: 'Pending' }],
    })
    expect(updated.entity).toBe('RENAMED')
    expect(updated.status_list).toHaveLength(1)
  })

  it('删除节点返回被级联删除的边 id', async () => {
    const { deleted_edge_ids } = await deleteNodeApi('N01')
    expect(deleted_edge_ids).toEqual(['E001', 'E002', 'E003'])
  })

  it('删除不存在的节点抛出 404', async () => {
    await expect(deleteNodeApi('NOPE')).rejects.toMatchObject({ status: 404 })
  })
})

describe('边写操作', () => {
  it('新建边由后端生成 edge_id', async () => {
    const created = await createEdgeApi({
      from_node_id: 'N01', to_node_id: 'N04',
      from_status_id: 'N01-ST01', to_status_id: 'N04-ST01',
      priority: 3, tone: 'default',
    })
    expect(created.edge_id).toBeTruthy()
    expect(created.priority).toBe(3)
  })

  it('编辑边更新 priority', async () => {
    const updated = await updateEdgeApi('E001', {
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 42, tone: 'default',
    })
    expect(updated.priority).toBe(42)
  })

  it('删除边返回被删除的 edge_id', async () => {
    expect(await deleteEdgeApi('E001')).toEqual({ edge_id: 'E001' })
  })
})

describe('文档', () => {
  it('按 document_id 读取文档', async () => {
    const doc = await getDocument('DOC-2026-0001')
    expect(doc.prerequisite).toContain('任务队列可读')
  })

  it('全量更新文档并回传 7 个字段', async () => {
    const original = await getDocument('DOC-2026-0001')
    const updated = await updateDocument({ ...original, remark: '改过的备注' })
    expect(updated.remark).toBe('改过的备注')
    expect(updated.prerequisite).toBe(original.prerequisite)
    expect(Object.keys(updated).sort()).toEqual([
      'check_question', 'description', 'document_id', 'evaluation_method',
      'flow_reason', 'prerequisite', 'remark',
    ])
  })

  it('文档不存在时抛出 404', async () => {
    await expect(getDocument('DOC-NOPE')).rejects.toMatchObject({ status: 404 })
  })
})

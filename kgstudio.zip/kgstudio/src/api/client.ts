import type { ApiEnvelope } from '@/types/graph'

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api'

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...init?.headers },
    })
  } catch {
    throw new ApiError('网络请求失败，请检查网络连接后重试', 0)
  }

  let envelope: ApiEnvelope<T>
  try {
    envelope = (await response.json()) as ApiEnvelope<T>
  } catch {
    throw new ApiError(`服务返回了非法响应（HTTP ${response.status}）`, response.status)
  }

  // 失败与否只看 HTTP 状态与信封的 success。
  // 不能把 data === null 当成失败：后端对 DELETE 这类无内容响应返回
  // { success: true, data: null } 是常见做法，那是成功而不是错误。
  if (!response.ok || !envelope.success) {
    throw new ApiError(envelope.error ?? `请求失败（HTTP ${response.status}）`, response.status)
  }
  return envelope.data as T
}

export const getJson = <T>(path: string) => request<T>(path)
export const postJson = <T>(path: string, body: unknown) =>
  request<T>(path, { method: 'POST', body: JSON.stringify(body) })
export const putJson = <T>(path: string, body: unknown) =>
  request<T>(path, { method: 'PUT', body: JSON.stringify(body) })
export const deleteJson = <T>(path: string) => request<T>(path, { method: 'DELETE' })

import { describe, it, expect, vi, afterEach } from 'vitest'
import { ApiError, getJson, postJson } from './client'

function mockFetchOnce(body: unknown, init: { status?: number; ok?: boolean } = {}) {
  const status = init.status ?? 200
  vi.stubGlobal('fetch', vi.fn(async () => ({
    ok: init.ok ?? status < 400,
    status,
    json: async () => body,
  })))
}

afterEach(() => vi.unstubAllGlobals())

describe('getJson', () => {
  it('成功时解开信封只返回 data', async () => {
    mockFetchOnce({ success: true, data: { node_id: 'N01' }, error: null })
    await expect(getJson('/nodes/N01')).resolves.toEqual({ node_id: 'N01' })
  })

  it('success 为 true 但 data 为 null 时视为成功，不抛错', async () => {
    mockFetchOnce({ success: true, data: null, error: null })
    await expect(getJson('/edges/E001')).resolves.toBeNull()
  })

  it('信封 success 为 false 时抛出 ApiError 并带上后端错误文案', async () => {
    mockFetchOnce({ success: false, data: null, error: '节点不存在' }, { status: 404 })
    await expect(getJson('/nodes/NONE')).rejects.toThrow(ApiError)
    await expect(getJson('/nodes/NONE')).rejects.toThrow('节点不存在')
  })

  it('HTTP 200 但 success 为 false 时同样视为失败', async () => {
    mockFetchOnce({ success: false, data: null, error: '参数非法' }, { status: 200 })
    await expect(getJson('/nodes/x')).rejects.toThrow('参数非法')
  })

  it('响应不是合法 JSON 时抛出可读错误', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({
      ok: false,
      status: 500,
      json: async () => { throw new SyntaxError('Unexpected token') },
    })))
    await expect(getJson('/nodes')).rejects.toThrow('HTTP 500')
  })

  it('网络中断时抛出 status 为 0 的 ApiError', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch') }))
    await expect(getJson('/nodes')).rejects.toMatchObject({ status: 0 })
  })
})

describe('postJson', () => {
  it('以 JSON 方式发送请求体', async () => {
    const fetchMock = vi.fn(async () => ({ ok: true, status: 200, json: async () => ({ success: true, data: { ok: 1 }, error: null }) }))
    vi.stubGlobal('fetch', fetchMock)
    await postJson('/edges', { priority: 3 })
    const [, init] = (fetchMock.mock.calls[0] as unknown[]) as [string, RequestInit]
    expect(init.method).toBe('POST')
    expect(init.body).toBe(JSON.stringify({ priority: 3 }))
  })
})

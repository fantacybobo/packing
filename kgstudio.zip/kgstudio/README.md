# KG Studio

一个知识图谱编辑器：以状态节点（status node）与带优先级的边（priority edge）为核心，
支持按候选节点 + 跳数（hop）搜索出图、拖拽连线新建边、节点与边的增删改、以及节点文档的
查看与编辑。图的自动布局由 dagre 完成，画布渲染基于 React Flow，查询状态以 URL 为唯一
真源（深链可还原任意一次查询）。

后端默认由浏览器内的 MSW mock 提供，开箱即用，无需额外起一个 API 进程。

## 快速开始

```bash
npm install
npm run dev
```

默认在 `http://localhost:5173` 提供开发服务器，`VITE_USE_MOCK` 默认为真，图数据完全跑在
浏览器内的 mock 后端上。

## 常用命令

| 命令 | 作用 |
|---|---|
| `npm install` | 安装依赖 |
| `npm run dev` | 启动开发服务器（默认 5173 端口） |
| `npm test` | 运行 vitest 单元测试（jsdom 环境） |
| `npm run e2e` | 运行 Playwright 端到端冒烟用例（真实 Chromium） |
| `npm run build` | 类型检查 + 生产构建 |

`npm run e2e` 会通过 `playwright.config.ts` 里的 `webServer` 配置自动拉起
`npm run dev`；如果本机已经有一个开发服务器在跑，Playwright 会直接复用它
（`reuseExistingServer: !process.env.CI`），不会抢占端口起第二个。

**首次运行 `npm run e2e` 前**，需要额外安装一次 Playwright 的浏览器二进制文件
（`npm install` 不会自动带上它）：

```bash
npx playwright install chromium
```

冷启动一个新 clone 时如果跳过这一步，`npm run e2e` 会因为缺少浏览器二进制而直接失败。

## 环境变量

复制 `.env.example` 为 `.env.local` 后按需修改：

```bash
VITE_API_BASE_URL=/api
VITE_USE_MOCK=true
```

- `VITE_API_BASE_URL`：真实后端的 API 前缀。HTTP 客户端所有请求都会拼上这个前缀。
- `VITE_USE_MOCK`：是否启用浏览器内的 MSW mock 后端。默认为 `true`，此时
  `VITE_API_BASE_URL` 不会被真正请求——所有图数据、节点、边、文档的读写都落在内存里的
  mock 数据库上，刷新页面即重置为种子数据。

**联调真实后端时**，把 `VITE_USE_MOCK` 设为 `false` 并把 `VITE_API_BASE_URL` 配置成真实
后端地址，应用会改为直接向该地址发起请求，不再经过 mock。

`VITE_USE_MOCK` 只认 `true` / `false` 两个值（大小写与首尾空格不计）。写成 `0`、`off`
这类值时不会被当成 `false` 之外的「疑似开启」——应用会在控制台警告并按 `false` 处理，
即不启用 mock。这条规则是有意的：失败方向必须是「不 mock」，否则一个自以为连着真实
后端的环境会摆满编造的数据，而且看起来和真的一模一样。

## 测试

- 单元测试（`npm test`）：148 个用例，覆盖 API 客户端、mock 处理器、布局算法、适配器、
  各 store 与主要组件，运行在 jsdom 下。
- 端到端测试（`npm run e2e`）：3 个冒烟用例，运行在真实 Chromium 里，覆盖：
  1. 搜索 → 出图 → 打开节点文档抽屉的主链路；
  2. 拖拽连线只会打开边编辑弹窗、在服务器确认前不会建边这条关键保证（这条无法在 jsdom
     下验证，因为它依赖 React Flow 真实的指针拖拽）；
  3. 深链（URL 直接带 `nodes` / `hop` 参数）进入即可还原图。

两套测试互不干扰：`e2e/` 目录已从 vitest 的默认收集范围中排除，`playwright test` 只认
`e2e/` 下的用例。

## 生产构建体积

`npm run build` 的主 chunk 实测 **314.97 kB gzip**，超出了最初设定的 < 300kB 预算。这个
超出是**有意接受的结果**，不是待办事项：

- 主要贡献者是 antd（v6，深色主题走 `theme.darkAlgorithm`），不是 React Flow 或应用自身
  代码。
- 做过一次实测：把 `@dagrejs/dagre` 改成动态 `import()` 懒加载后，主 chunk 降到
  298 kB gzip，勉强压线。但 dagre 是自动布局算法，第一次搜索返回结果时就要立刻用上——
  懒加载并不会推迟任何真实的用户可感知的等待，只是把同一次网络请求的时机往后挪了几十毫秒，
  换来的是一个只剩 1.8 kB 的脆弱余量、外加一次额外的动态 import 往返。这个权衡不划算，
  已放弃，代码保持同步 `import`。
- 另有一个约 160 kB gzip 的独立 `browser-*.js` chunk（MSW mock worker），但它只在
  `VITE_USE_MOCK=true` 时才会被请求和执行；真实部署（`VITE_USE_MOCK=false`，直连真实
  后端）不会加载这个 chunk，不计入这份预算的讨论范围。

结论：314.97 kB gzip 是当前的真实数字，预算已相应确认为"接受但不追求进一步压缩"，后续
如无必要不应为了凑 300kB 而引入代码分割或懒加载。

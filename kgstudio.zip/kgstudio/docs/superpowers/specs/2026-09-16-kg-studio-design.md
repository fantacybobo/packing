# KG Studio — 节点状态图管理器 设计文档

- 日期：2026-09-16
- 状态：已确认，待实现
- 设计来源：Claude Design 项目「蜂窝管理系统设计」/ `Hive Graph Manager.dc.html`

## 1. 目标

一个知识图谱编辑工具。用户通过关键字搜索定位 1～2 个候选节点，指定向外扩展的跳数，
后端返回子图，前端用 React Flow 绘制成「节点 — 状态行」的流程图，并支持对节点、边、
节点文档的增删改查。

非目标（本期不做）：多文档管理、节点坐标持久化、tone 的多套配色、权限与多用户协作。

## 2. 技术栈

| 项 | 选型 | 备注 |
|---|---|---|
| 构建 | Vite + React 19 + TypeScript | 实装 Vite 8.3 / TS 7.0；本机 Node v24.6.0，包管理用 npm |
| UI | antd 6 | ConfigProvider + theme.darkAlgorithm + 定制 token（实装 6.6.4） |
| 图 | `@xyflow/react`（React Flow 12） | 不是旧的 `reactflow` v11 包 |
| 状态 | zustand 5 | 两个 store：graph / ui |
| URL 状态 | nuqs 2（`nuqs/adapters/react`） | 查询参数的唯一来源 |
| 布局 | `@dagrejs/dagre` | LR 分层自动布局 |
| Mock | msw 2 | browser worker（开发）+ node server（单测复用） |
| 测试 | vitest + @testing-library/react + playwright | 核心单测 + 1 条 E2E 冒烟 |

## 3. 目录结构

按功能域组织，单文件控制在 400 行以内。

```
src/
├── types/graph.ts
├── api/
│   ├── client.ts            # fetch 封装、信封解包、ApiError
│   └── graph.ts             # 10 个接口
├── mocks/
│   ├── browser.ts
│   ├── handlers.ts
│   └── db.ts                # 种子数据（取自设计稿的 4 节点 / 10 边）
├── store/
│   ├── useGraphStore.ts
│   └── useUiStore.ts
├── hooks/
│   └── useGraphQuery.ts     # nuqs 参数 + 触发查询的 effect
├── lib/
│   ├── layout.ts            # dagre → positions
│   └── adapters.ts          # 领域对象 ↔ React Flow 对象
├── components/
│   ├── app-shell/           # IconRail · TopBar · AppShell
│   ├── search-bar/          # SearchBar · NodeCombobox · HopInput
│   ├── graph/               # GraphCanvas · StatusNode · StatusRow · PriorityEdge · EmptyState
│   ├── node-editor/         # NodeEditorDrawer · StatusListEditor
│   ├── edge-editor/         # EdgeEditorModal
│   └── document/            # DocumentDrawer
└── styles/
    ├── tokens.css
    └── global.css
```

## 4. 数据模型

对用户原始定义做了两处修正：
- `evalutaion_method` 为拼写笔误，统一用 `evaluation_method`。
- `tone` 本期只有 `'default'` 一个值，但渲染层通过查表取色，将来扩展只改一张表。

```ts
export type Tone = 'default'

export interface NodeStatus {
  status_id: string
  node_id: string
  status_description: string
}

export interface GraphNode {
  node_id: string
  entity: string
  metrics: string
  tone: Tone
  document_id: string[]
  status_list: NodeStatus[]
}

export interface GraphEdge {
  edge_id: string
  from_node_id: string
  to_node_id: string
  from_status_id: string
  to_status_id: string
  priority: number
  tone: Tone
}

export interface NodeDocument {
  document_id: string
  prerequisite: string
  check_question: string
  evaluation_method: string
  description: string
  flow_reason: string
  remark: string
}
```

## 5. 接口

统一响应信封 `{ success: boolean, data: T | null, error: string | null }`，
`api/client.ts` 负责解包，失败抛 `ApiError`。

| 方法 | 路径 | 入参 | 返回 |
|---|---|---|---|
| GET | `/api/nodes/search` | `?q=关键字` | `GraphNode[]` |
| POST | `/api/graph/query` | `{ node_ids: string[], hop: number }` | `{ nodes: GraphNode[], edges: GraphEdge[] }` |
| POST | `/api/nodes` | 节点表单（不含 `node_id`、`status_id`） | `GraphNode` |
| PUT | `/api/nodes/:node_id` | 全量节点字段 | `GraphNode` |
| DELETE | `/api/nodes/:node_id` | — | `{ deleted_edge_ids: string[] }` |
| POST | `/api/edges` | `{ from_node_id, to_node_id, from_status_id, to_status_id, priority, tone }` | `GraphEdge` |
| PUT | `/api/edges/:edge_id` | 全量边字段 | `GraphEdge` |
| DELETE | `/api/edges/:edge_id` | — | `{ edge_id }` |
| GET | `/api/documents/:document_id` | — | `NodeDocument` |
| PUT | `/api/documents/:document_id` | 全量 7 个字段 | `NodeDocument` |

约定：
- `node_ids` 长度为 1 或 2；`hop` 为 1～6 的整数，前端始终显式传值，不依赖后端默认。
- 删除节点由后端级联删除相连的边，并返回被删除的 `edge_id` 列表，前端据此清理本地状态。
- 编辑节点时若某个状态行被删除，后端同样级联删除引用该 `status_id` 的边
  （`from_status_id` / `to_status_id` 两个方向都算），与「删除节点级联删边」是同一条规则。
  边的 `sourceHandle` / `targetHandle` 就是 `status_id`：状态没了而边还在，
  React Flow 挂不上 handle，边会从画布上消失却仍留在库里——用户再也看不到、点不到、删不掉。
  前端 `updateNode` 按响应里返回的 `status_list` 自行推导并清理本地的边，
  与 `deleteNode` 一样不依赖服务端额外告知（PUT 的响应体形状不变，仍是 `GraphNode`）。
- 新增节点/新增状态时前端不传 `status_id`，由后端生成并在响应中回传完整 `GraphNode`。
- 文档更新为全量 PUT（7 个字段全部回传），不做部分更新。

### 环境变量

| 变量 | 默认 | 用途 |
|---|---|---|
| `VITE_API_BASE_URL` | `/api` | 接口前缀，联调真实后端时改这里 |
| `VITE_USE_MOCK` | `true` | 只认 `true` / `false`：`true` 启动 MSW worker，`false` 走真实后端。其余值一律警告并按 `false` 处理（失败方向必须是「不 mock」） |

随仓库提交 `.env.example`，不提交 `.env.local`。

### Mock 的 hop 语义

MSW handler 真实实现 hop：以 `node_ids` 为种子，在边集上做广度优先扩展 N 跳
（忽略方向，入边出边都算），返回命中的节点及它们之间的全部边。
这样在 mock 模式下调整 hop 能看到子图真实地变大变小。

## 6. 状态管理

### useGraphStore —— 只存服务端图数据

```
state:  nodes, edges, positions, status: 'idle'|'loading'|'ready'|'error', error
action: searchGraph(nodeIds, hop)
        createNode / updateNode / deleteNode
        createEdge / updateEdge / deleteEdge
        setNodePosition
```

核心约束：**每个写操作都是 `await api` 成功后才 `set(...)`**，失败则 rethrow 且 store 不变。
这实现了「服务器返回 OK 之后界面上才出现」这一需求。所有更新走不可变模式。

### useUiStore —— 只存开关

```
nodeEditor:    { mode: 'create' | 'edit', nodeId?: string } | null
edgeEditor:    { mode: 'create' | 'edit', edgeId?: string, draft?: Connection } | null
documentPanel: { nodeId: string, documentId: string } | null
```

文档详情不进全局 store，在 `DocumentDrawer` 内部 fetch + 局部 state —— 只有一个消费者。

## 7. React Flow 映射

- 一个 `GraphNode` → 一个自定义节点 `statusNode`。
- 节点内每条 status 渲染一行，左右各挂一个 Handle，**handle id 直接用 `status_id`**：

```tsx
<Handle type="target" position={Position.Left}  id={s.status_id} />
<Handle type="source" position={Position.Right} id={s.status_id} />
```

- 用户拖线后，`onConnect` 回调给出的 `{ source, target, sourceHandle, targetHandle }`
  即 `from_node_id / to_node_id / from_status_id / to_status_id`，无需额外转换。
- `onConnect` **不直接建边**，而是打开 Edge 弹窗（`mode: 'create'`，携带 draft），
  用户填写 priority 并保存 → `POST /api/edges` → 成功后才 `addEdge`。
- `isValidConnection` 拦截：自连、同一对 status 的重复连线。
- 边的编辑：左键点击与右键菜单都打开编辑弹窗（左键更易发现，右键保留设计稿习惯）。
- 边标签 `pri: N` 由自定义 edge 组件绘制在路径中点。设计稿中的「标签防重叠推挤」算法
  本期不实现（YAGNI），若实际数据下标签重叠再补。

### 布局

`lib/layout.ts` 使用 dagre，`rankdir: 'LR'`，`nodesep: 60`，`ranksep: 160`。
节点尺寸：宽度固定 `W = 330`。高度按设计稿原始公式估算，不留未定义量：

```
charsPerLine = max(8, floor((W - 28) / 13))
lines        = max(1, ceil(metrics.length / charsPerLine))
headHeight   = 10 + 22 + 4 + lines * 19 + 10        // 标题区（entity + metrics）
nodeHeight   = 32 + headHeight + 24 + n * 34 + (n - 1) * 8   // n = status_list.length
```

其中 32 为标题栏高度，24 为状态区上下内边距，34 为单行状态高度，8 为行间距。

每次 `searchGraph` 成功后重算全部坐标；`onNodeDragStop` 仅更新 store 中的坐标，
不持久化，刷新后回到自动布局。

## 8. 主题与视觉

AntD `darkAlgorithm` + 从设计稿提取的 token。同一套色值同时写入 `tokens.css`
的 CSS 自定义属性，供画布与节点卡片等非 AntD 部分使用。

```
--color-bg-app     #070c12
--color-bg-panel   #0a1017
--color-bg-surface #0d151d
--color-border     #23323f
--color-text       #c9d6e3
--color-text-strong #e9f1f8
--accent-start     #4ade80
--accent-end       #60a5fa
--color-danger     #dc2626
```

字体两套：IBM Plex Sans（正文）+ JetBrains Mono（id / 标签 / 数值），
`font-display: swap`，仅预加载正文 500 字重。
画布 44px 网格背景、节点选中发光、按钮 hover 态按设计稿还原。
动画不得使用会触发布局重排的属性（width / height / top / left / margin / padding / border / font-size）；位移与显隐一律用 `transform` / `opacity`。悬停 / 焦点态的 `background-color`、`color`、`border-color` 过渡属于允许范围 —— 它们只触发重绘不触发重排，且是交互反馈的标准做法；为避开它而叠一层伪元素做 opacity 淡入是不必要的复杂度。所有动画均需遵循 `prefers-reduced-motion`。

## 9. URL 作为查询状态的唯一来源

### URL 形态

```
/?nodes=N01,N04&hop=3     两个候选 + 非默认 hop
/?nodes=N01               单候选；hop 为默认值 2 时不写入 URL（clearOnDefault）
```

### 数据流

```
点「搜索」 ──写入 URL(push)──▶ URL 变化 ──effect──▶ searchGraph(nodes, hop) ──▶ 渲染
                                    ▲
                        浏览器前进/后退、直接粘贴链接进入
```

搜索按钮不直接调接口，只把草稿提交进 URL；真正触发查询的是监听 URL 的 effect。
「点搜索」「粘贴链接」「浏览器后退」三条入口因此共用同一段代码，
不会产生双重请求或状态不一致。

### 草稿态 vs 提交态

- 两个 Select 的选择、hop 步进器的调整只修改组件内部草稿 state，**不碰 URL**，
  避免每次交互都往历史栈塞记录。
- 只有点击「搜索」才将草稿提交进 URL。URL 中始终是「当前画布这张图对应的查询」。

### 深链回填

URL 中只有 node id，而模糊搜索接口按关键字查询，无法按 id 反查。
解决办法：`POST /api/graph/query` 的响应中种子节点必然存在，
拿到响应后按 id 从 `nodes` 数组中找出这两个节点，用其 `metrics` / `entity`
回填 Select 的显示值。无需额外接口。

### 边界处理

- `hop` 非整数或越界 → clamp 到 1～6，并将清洗后的值以 `replace` 写回 URL。
- `nodes` 为空或全为空串 → 不发请求，回到空画布引导态。
- `nodes` 超过 2 个 → 只取前 2 个。
- id 在后端不存在 → 接口返回空结果，展示「未找到对应节点」空态，不崩溃。
- 节点/边的增删改不修改 URL，只更新 store。

## 10. 交互流程

首屏为空画布 + 引导文案。

```
空态引导  →  候选一必填（Select 远程搜索，防抖 300ms）
          →  候选二选填
          →  hop 步进器（1–6，默认 2）
          →  搜索按钮：仅候选一有值时可点
          →  写入 URL → POST /graph/query → dagre 布局 → 渲染

节点标题栏 📄 → document_id[0] 存在则 GET 文档 → 右侧抽屉
                 prerequisite / check_question 只读展示
                 evaluation_method / description / flow_reason / remark 可编辑
                 Save → 全量 PUT
              → document_id 为空 → 按钮禁用，提示「该节点暂无文档」

节点标题栏 ✏️ → 右侧抽屉编辑 entity / metrics / status 列表 → PUT → 成功才更新
右上「新建节点」 → 同一抽屉 create 模式 → POST → 成功才上图
拖线 → Edge 弹窗 → POST → 成功才连上
点边 → Edge 弹窗 edit 模式 → PUT / DELETE
```

搜索条为一整条连体控件：

```
┌────────────────┬────────────────┬──────────────┬────────┐
│ ● 候选节点 1 ▾ │ ● 候选节点 2 ▾ │ HOP   2 ⌃⌄  │  搜索  │
└────────────────┴────────────────┴──────────────┴────────┘
```

新增 status 行使用客户端临时 key（`tmp-*`）占位，提交时不传 `status_id`，
后端返回的完整 Node 覆盖本地状态。

## 11. 错误处理

- `api/client.ts` 统一抛出 `ApiError`（含 status、message）。
- store 捕获后 rethrow，调用方用 antd `message.error` 提示用户。
- **保存失败时抽屉/弹窗保持打开**，不清空用户已填内容。
- 查询失败时画布进入 error 态并提供重试入口。
- 不静默吞掉任何错误。

## 12. 测试

### 单元测试（vitest + MSW node server）

- `lib/layout.ts`：坐标计算、节点高度估算。
- `lib/adapters.ts`：领域对象 ↔ React Flow 对象的双向转换。
- `hooks/useGraphQuery.ts`：hop clamp、nodes 解析/截断/去空、默认值不写入 URL。
- `store/useGraphStore.ts`：搜索、节点 CRUD、边 CRUD，
  **含关键断言「接口失败时 state 不变」**。
- `api/graph.ts`：接口契约与信封解包。

### E2E（playwright）

1 条冒烟用例：搜索 → 出图 → 打开文档抽屉。

## 13. 可访问性与性能

- 语义化结构：`<header>` / `<nav aria-label>` / `<main>`。
- 所有图标按钮带 `aria-label`；抽屉与弹窗走 antd 的焦点管理。
- 遵循 `prefers-reduced-motion`。
- 应用页 JS 预算原定 < 300kb gzip。构建后核对实际体积：主 chunk 实测
  **314.97 kB gzip**，超出预算，且已确认有意接受，不再追加代码分割或懒加载去凑
  300kb。最大贡献者是 antd（非最初设想的 React Flow）；详细权衡记录见
  `README.md` 的「生产构建体积」一节（含一次把 `@dagrejs/dagre` 懒加载的实测，能压到
  298kB 但被否决——dagre 首次搜索出图就要用，懒加载不省任何用户可感知的等待，只留 1.8kB
  的脆弱余量）。

import { describe, it, expect } from 'vitest'
import type { Connection } from '@xyflow/react'
import { MarkerType } from '@xyflow/react'
import { EDGE_COLOR } from '@/theme'
import {
  toFlowNodes, toFlowEdges, connectionToPayload, describeEdgeEndpoints,
  findDuplicateEdge, isSelfLoop,
} from './adapters'
import type { GraphEdge, GraphNode } from '@/types/graph'

const node: GraphNode = {
  node_id: 'N01', entity: 'TASK', metrics: '描述', tone: 'default', document_id: ['DOC-1'],
  status_list: [{ status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' }],
}

const edge: GraphEdge = {
  edge_id: 'E001', from_node_id: 'N01', to_node_id: 'N02',
  from_status_id: 'N01-ST01', to_status_id: 'N02-ST01', priority: 7, tone: 'default',
}

const connection = (over: Partial<Connection> = {}): Connection => ({
  source: 'N01', target: 'N02', sourceHandle: 'N01-ST01', targetHandle: 'N02-ST01', ...over,
})

describe('toFlowNodes', () => {
  it('node_id 作为 React Flow 的 id，原始节点挂在 data 上', () => {
    const [flow] = toFlowNodes([node], { N01: { x: 10, y: 20 } })
    expect(flow.id).toBe('N01')
    expect(flow.type).toBe('statusNode')
    expect(flow.data.node).toBe(node)
    expect(flow.position).toEqual({ x: 10, y: 20 })
  })

  it('dragHandle 限定为标题区，避免拖拽状态行上的 handle 时带走整个节点', () => {
    const [flow] = toFlowNodes([node], {})
    expect(flow.dragHandle).toBe('.status-node__head')
  })

  it('缺少坐标的节点回落到原点而不是 undefined', () => {
    const [flow] = toFlowNodes([node], {})
    expect(flow.position).toEqual({ x: 0, y: 0 })
  })
})

describe('toFlowEdges', () => {
  // 边是有向的（from → to），但 React Flow 不会自己画箭头：
  // 没有 markerEnd 就只有一根两头一样的曲线，看不出方向。
  it('终点带箭头 marker，方向才看得出来', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.markerEnd).toEqual({
      type: MarkerType.ArrowClosed,
      width: 18,
      height: 18,
      color: EDGE_COLOR,
    })
  })

  it('起点不带 marker，免得两头都像终点', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.markerStart).toBeUndefined()
  })

  it('status_id 直接作为 sourceHandle / targetHandle', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.id).toBe('E001')
    expect(flow.source).toBe('N01')
    expect(flow.target).toBe('N02')
    expect(flow.sourceHandle).toBe('N01-ST01')
    expect(flow.targetHandle).toBe('N02-ST01')
  })

  it('priority 传进 data 供自定义边渲染标签', () => {
    const [flow] = toFlowEdges([edge])
    expect(flow.data?.priority).toBe(7)
    expect(flow.type).toBe('priorityEdge')
  })
})

describe('connectionToPayload', () => {
  it('把 React Flow 的 Connection 映射成建边入参', () => {
    expect(connectionToPayload(connection(), 5)).toEqual({
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 5, tone: 'default',
    })
  })

  it('缺少 handle 时返回 null，不产生残缺的边', () => {
    expect(connectionToPayload(connection({ sourceHandle: null }), 1)).toBeNull()
    expect(connectionToPayload(connection({ targetHandle: null }), 1)).toBeNull()
  })
})

describe('isSelfLoop', () => {
  it('同一个 status 自连视为非法', () => {
    expect(isSelfLoop(connection({ target: 'N01', targetHandle: 'N01-ST01' }))).toBe(true)
  })

  it('同节点不同 status 之间允许连线', () => {
    expect(isSelfLoop(connection({ target: 'N01', targetHandle: 'N01-ST02' }))).toBe(false)
  })

  it('不同节点之间不是自连', () => {
    expect(isSelfLoop(connection())).toBe(false)
  })
})

describe('findDuplicateEdge', () => {
  it('同一对 status 之间已有边时能找出来', () => {
    expect(findDuplicateEdge([edge], connection())).toBe(edge)
  })

  it('目标 status 不同则不算重复', () => {
    expect(findDuplicateEdge([edge], connection({ targetHandle: 'N02-ST02' }))).toBeUndefined()
  })

  it('方向相反不算重复', () => {
    const reversed = connection({
      source: 'N02', target: 'N01', sourceHandle: 'N02-ST01', targetHandle: 'N01-ST01',
    })
    expect(findDuplicateEdge([edge], reversed)).toBeUndefined()
  })
})

describe('describeEdgeEndpoints', () => {
  const nodes: GraphNode[] = [
    {
      node_id: 'N01', entity: 'TASK PROCESSOR', metrics: 'm', tone: 'default', document_id: [],
      status_list: [{ status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' }],
    },
    {
      node_id: 'N02', entity: 'DECISION GATE', metrics: 'm', tone: 'default', document_id: [],
      status_list: [{ status_id: 'N02-ST01', node_id: 'N02', status_description: 'Active' }],
    },
  ]
  const ref = {
    fromNodeId: 'N01', toNodeId: 'N02',
    fromStatusId: 'N01-ST01', toStatusId: 'N02-ST01',
  }

  it('把四个 id 翻译成实体与状态描述', () => {
    expect(describeEdgeEndpoints(nodes, ref)).toEqual({
      fromEntity: 'TASK PROCESSOR', fromStatus: 'Pending',
      toEntity: 'DECISION GATE', toStatus: 'Active',
    })
  })

  // 退回 id 而不是空串：图里少了一个节点时，「? → ?」什么也说明不了，
  // 而 id 至少能让人去库里查这条边到底挂在哪。
  it('节点不在图里时退回 id', () => {
    const text = describeEdgeEndpoints(nodes, { ...ref, toNodeId: 'N99', toStatusId: 'N99-ST01' })
    expect(text.toEntity).toBe('N99')
    expect(text.toStatus).toBe('N99-ST01')
  })

  it('节点在、状态不在时只退回状态那一半', () => {
    const text = describeEdgeEndpoints(nodes, { ...ref, fromStatusId: 'N01-ST99' })
    expect(text.fromEntity).toBe('TASK PROCESSOR')
    expect(text.fromStatus).toBe('N01-ST99')
  })

  it('连 id 都没有时给一句话，而不是渲染 undefined', () => {
    const text = describeEdgeEndpoints(nodes, {
      fromNodeId: null, toNodeId: undefined, fromStatusId: null, toStatusId: undefined,
    })
    expect(text.fromEntity).toBe('未知节点')
    expect(text.toStatus).toBe('未知状态')
  })
})

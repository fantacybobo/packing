import { MarkerType, type Connection, type Edge, type EdgeMarker, type Node } from '@xyflow/react'
import { EDGE_COLOR } from '@/theme'
import type { EdgePayload, GraphEdge, GraphNode } from '@/types/graph'
import type { XY } from './layout'

// 边是有向的，但 React Flow 不会自动画箭头：不给 markerEnd，画出来就是一根
// 两头长得一样的曲线，from / to 完全看不出来。marker 由 React Flow 生成进 <defs>，
// 拿不到 .priority-edge 上的 stroke，所以颜色只能从 JS 传进去。
const ARROW_END: EdgeMarker = {
  type: MarkerType.ArrowClosed,
  width: 18,
  height: 18,
  color: EDGE_COLOR,
}

export interface StatusNodeData extends Record<string, unknown> {
  node: GraphNode
}

export type StatusFlowNode = Node<StatusNodeData, 'statusNode'>

export function toFlowNodes(nodes: GraphNode[], positions: Record<string, XY>): StatusFlowNode[] {
  return nodes.map(node => ({
    id: node.node_id,
    type: 'statusNode' as const,
    position: positions[node.node_id] ?? { x: 0, y: 0 },
    // 只有标题区能拖动整个节点。状态行两侧是连线用的 handle，
    // 若整张卡片都可拖拽，用户想拉连线时稍微偏一点就会把节点拖走。
    // 这也让标题区的 cursor: grab 名副其实。
    dragHandle: '.status-node__head',
    data: { node },
  }))
}

export function toFlowEdges(edges: GraphEdge[]): Edge[] {
  return edges.map(edge => ({
    id: edge.edge_id,
    type: 'priorityEdge',
    source: edge.from_node_id,
    target: edge.to_node_id,
    sourceHandle: edge.from_status_id,
    targetHandle: edge.to_status_id,
    markerEnd: ARROW_END,
    data: { priority: edge.priority, tone: edge.tone },
  }))
}

export function connectionToPayload(c: Connection, priority: number): EdgePayload | null {
  if (!c.source || !c.target || !c.sourceHandle || !c.targetHandle) return null
  return {
    from_node_id: c.source,
    to_node_id: c.target,
    from_status_id: c.sourceHandle,
    to_status_id: c.targetHandle,
    priority,
    tone: 'default',
  }
}

export function isSelfLoop(c: Connection): boolean {
  return c.source === c.target && c.sourceHandle === c.targetHandle
}

export function findDuplicateEdge(edges: GraphEdge[], c: Connection): GraphEdge | undefined {
  return edges.find(
    e =>
      e.from_node_id === c.source &&
      e.to_node_id === c.target &&
      e.from_status_id === c.sourceHandle &&
      e.to_status_id === c.targetHandle,
  )
}

/** 一条边的两端用人话怎么说。找不到对应节点 / 状态时退回 id，而不是显示空白。 */
export interface EdgeEndpointText {
  fromEntity: string
  fromStatus: string
  toEntity: string
  toStatus: string
}

export interface EdgeEndpointRef {
  fromNodeId: string | null | undefined
  toNodeId: string | null | undefined
  fromStatusId: string | null | undefined
  toStatusId: string | null | undefined
}

function describeEndpoint(
  nodes: GraphNode[],
  nodeId: string | null | undefined,
  statusId: string | null | undefined,
): { entity: string; status: string } {
  const node = nodes.find(n => n.node_id === nodeId)
  const status = node?.status_list.find(s => s.status_id === statusId)
  return {
    // 退回 id 而不是空串：图里少了一个节点时，「? → ?」什么也说明不了，
    // 而 id 至少能让人去库里查这条边到底挂在哪。
    entity: node?.entity || nodeId || '未知节点',
    status: status?.status_description || statusId || '未知状态',
  }
}

/**
 * 把边的四个 id 翻译成「实体 · 状态」。
 *
 * 面板标题原来直接显示 from_status_id → to_status_id，对着图看的人根本不知道
 * N01-ST01 是谁 —— 卡片上从来不显示 id（见 StatusNode 的注释），两边对不上。
 */
export function describeEdgeEndpoints(nodes: GraphNode[], ref: EdgeEndpointRef): EdgeEndpointText {
  const from = describeEndpoint(nodes, ref.fromNodeId, ref.fromStatusId)
  const to = describeEndpoint(nodes, ref.toNodeId, ref.toStatusId)
  return {
    fromEntity: from.entity, fromStatus: from.status,
    toEntity: to.entity, toStatus: to.status,
  }
}

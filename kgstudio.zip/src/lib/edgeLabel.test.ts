import { describe, it, expect } from 'vitest'
import {
  EDGE_LABEL_ANCHOR, EDGE_LABEL_PLACEMENT,
  cubicPointAt, edgeLabelPoint, parseCubicPath,
} from './edgeLabel'
import type { XY } from './layout'

// React Flow 的贝塞尔边就是这个形状：起点 (0,0)、终点 (200,120)，两个横向控制点。
const PATH = 'M0,0 C100,0 100,120 200,120'
const POINTS = [0, 0, 100, 0, 100, 120, 200, 120]

/** 点到曲线的最短距离。用来验证「返回的点确实落在连线上」，而不是飘在旁边。 */
function distanceToCurve(points: number[], p: XY): number {
  let best = Infinity
  for (let i = 0; i <= 2000; i++) {
    const q = cubicPointAt(points, i / 2000)
    best = Math.min(best, Math.hypot(q.x - p.x, q.y - p.y))
  }
  return best
}

/** 沿曲线从起点走到 t 的弧长 */
function arcLengthTo(points: number[], t: number): number {
  let total = 0
  let previous = cubicPointAt(points, 0)
  const steps = 2000
  for (let i = 1; i <= steps; i++) {
    const current = cubicPointAt(points, (i / steps) * t)
    total += Math.hypot(current.x - previous.x, current.y - previous.y)
    previous = current
  }
  return total
}

/** 点在曲线上的弧长位置 */
function arcLengthOf(points: number[], p: XY): number {
  let bestT = 0
  let best = Infinity
  for (let i = 0; i <= 2000; i++) {
    const t = i / 2000
    const q = cubicPointAt(points, t)
    const d = Math.hypot(q.x - p.x, q.y - p.y)
    if (d < best) { best = d; bestT = t }
  }
  return arcLengthTo(points, bestT)
}

describe('parseCubicPath', () => {
  it('从路径里取出四个控制点', () => {
    expect(parseCubicPath(PATH)).toEqual(POINTS)
  })

  it('负坐标与小数都能解析', () => {
    expect(parseCubicPath('M-10.5,0 C-5,2.25 30,40 60.75,-12'))
      .toEqual([-10.5, 0, -5, 2.25, 30, 40, 60.75, -12])
  })

  it('不是三次贝塞尔时返回 null，而不是解析出半组坐标', () => {
    // 直线边只有四个数，按 8 个取会读到越界的 undefined
    expect(parseCubicPath('M0,0 L100,100')).toBeNull()
    expect(parseCubicPath('')).toBeNull()
  })
})

describe('cubicPointAt', () => {
  it('t=0 与 t=1 落在两个端点上', () => {
    expect(cubicPointAt(POINTS, 0)).toEqual({ x: 0, y: 0 })
    expect(cubicPointAt(POINTS, 1)).toEqual({ x: 200, y: 120 })
  })

  it('对称曲线的 t=0.5 落在两端点的中点', () => {
    const mid = cubicPointAt(POINTS, 0.5)
    expect(mid.x).toBeCloseTo(100, 6)
    expect(mid.y).toBeCloseTo(60, 6)
  })
})

describe('edgeLabelPoint', () => {
  const fallback = { x: 100, y: 60 }

  it('居中时直接用 React Flow 给的中点，不做任何计算', () => {
    expect(edgeLabelPoint(PATH, 'center', fallback)).toBe(fallback)
  })

  it('靠左的锚点落在曲线上，且离起点约一个 END_GAP', () => {
    const point = edgeLabelPoint(PATH, 'left', fallback)
    expect(distanceToCurve(POINTS, point)).toBeLessThan(0.5)
    expect(arcLengthOf(POINTS, point)).toBeCloseTo(22, 0)
  })

  it('靠右的锚点落在曲线上，且离终点约一个 END_GAP —— 不会压在箭头上', () => {
    const point = edgeLabelPoint(PATH, 'right', fallback)
    const total = arcLengthTo(POINTS, 1)
    expect(distanceToCurve(POINTS, point)).toBeLessThan(0.5)
    expect(total - arcLengthOf(POINTS, point)).toBeCloseTo(22, 0)
  })

  // 按弧长取点而不是按参数 t：贝塞尔的 t 与弧长不是线性的，
  // 直接取 t=0.8 在这条弯度不小的边上会偏出好几像素。
  it('靠右的点明显偏向终点一侧，而不是停在中点', () => {
    const point = edgeLabelPoint(PATH, 'right', fallback)
    expect(Math.hypot(point.x - 200, point.y - 120))
      .toBeLessThan(Math.hypot(point.x - 0, point.y - 0))
  })

  it('短边上收敛到中点，靠左靠右都不会跑到对面去', () => {
    // 总弧长约 14px，不足两个 END_GAP
    const shortPath = 'M0,0 C5,0 5,10 10,10'
    const shortPoints = parseCubicPath(shortPath)!
    const left = edgeLabelPoint(shortPath, 'left', fallback)
    const right = edgeLabelPoint(shortPath, 'right', fallback)
    const half = arcLengthTo(shortPoints, 1) / 2
    expect(arcLengthOf(shortPoints, left)).toBeCloseTo(half, 0)
    expect(arcLengthOf(shortPoints, right)).toBeCloseTo(half, 0)
  })

  it('路径解析不出来时退回中点，而不是把标签扔到 (0,0)', () => {
    expect(edgeLabelPoint('M0,0 L10,10', 'right', fallback)).toBe(fallback)
  })

  // 两端重合时贝塞尔求值会留下浮点残渣，弧长是个非零的极小值 ——
  // 所以阈值必须是「短于 1px」而不是「等于 0」，否则这条退路实际永远走不到。
  it('两端重合的退化边退回中点，不在浮点残渣上算位置', () => {
    expect(edgeLabelPoint('M5,5 C5,5 5,5 5,5', 'right', fallback)).toBe(fallback)
  })

  it('不足 1px 的边也退回中点', () => {
    expect(edgeLabelPoint('M0,0 C0.1,0 0.2,0.1 0.3,0.2', 'left', fallback)).toBe(fallback)
  })
})

describe('摆法本身', () => {
  // 界面上不给开关，改这个常量就换全图的摆法。
  it('内置的摆法是靠近箭头一侧', () => {
    expect(EDGE_LABEL_PLACEMENT).toBe('right')
  })

  it('靠左靠右时标签整个挪到锚点一侧，不会盖住端点', () => {
    // 锚点离端点只有 22px，标签比这宽 —— 靠自身位移躲开，而不是靠拉远锚点
    expect(EDGE_LABEL_ANCHOR.left).toContain('translate(0')
    expect(EDGE_LABEL_ANCHOR.right).toContain('-100%')
    expect(EDGE_LABEL_ANCHOR.center).toContain('-50%')
  })

  // 三种摆法都得真的算得出位置：常量一改就该立刻生效，不能有哪一种是坏的。
  it('三种取值都能算出落在连线上的锚点', () => {
    const fallback = { x: 100, y: 60 }
    const left = edgeLabelPoint(PATH, 'left', fallback)
    const centre = edgeLabelPoint(PATH, 'center', fallback)
    const right = edgeLabelPoint(PATH, 'right', fallback)
    expect(distanceToCurve(POINTS, left)).toBeLessThan(0.5)
    expect(centre).toBe(fallback)
    expect(distanceToCurve(POINTS, right)).toBeLessThan(0.5)
    expect(arcLengthOf(POINTS, left)).toBeLessThan(arcLengthOf(POINTS, right))
  })
})

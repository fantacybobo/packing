import dagre from '@dagrejs/dagre'
import type { GraphEdge, GraphNode } from '@/types/graph'

export const NODE_WIDTH = 330

const NEW_NODE_GAP = 160

// 卡片各段的高度构成。这些值必须与 graph.css 里 .status-node__* 的实际渲染一一对应：
// 两边一旦漂移，dagre 预留的垂直空间就是错的，连线会挂在视觉上偏移的位置。
//
// 卡片结构（见 StatusNode.tsx）：
//   [1px 上边框]
//   __head        padding 12 / 标题行 22 / 间距 4 / metrics 每行 19 / padding 12
//   __row × n     每行 36（含自身的 1px 上分隔线，见下）
//   [1px 下边框]
const CARD_BORDER_Y = 2          // .status-node 的上下外框各 1px
const CARD_BORDER_X = 2          // 左右外框；box-sizing 为 border-box，内容宽因此比 NODE_WIDTH 少 2
const HEAD_PADDING_TOP = 12      // .status-node__head 的上内边距
const TITLE_LINE_HEIGHT = 22     // .status-node__head-top 的固定高度（= 标题行高，也 = 操作按钮高）
const TITLE_METRICS_GAP = 4      // .status-node__metrics 的 margin-top
const METRICS_LINE_HEIGHT = 19   // .status-node__metrics 的 line-height
const HEAD_PADDING_BOTTOM = 12   // .status-node__head 的下内边距
const HEAD_SIDE_PADDING = 28     // 左右各 14px
// global.css 里有全局的 * { box-sizing: border-box }，所以 .status-node__row 声明的
// height: 36px 已经把它自己的 1px border-top 包在内 —— 分隔线不额外占高度，
// 绝不能再往上加一个 border 常量。（实测：3 行的状态区恰好 108px = 3 × 36。）
const ROW_HEIGHT = 36            // .status-node__row 的高度，含 border-top
const METRICS_CHAR_WIDTH = 13    // 单个中文字符的估算宽度
const MIN_CHARS_PER_LINE = 8     // 极窄卡片下的兜底，避免除出 0

// 旧版公式有约 1.45px 的已知残差（卡片自身的 2px 外框没有对应常量，
// 又被行高估算的四舍五入抵掉一部分）。这一版把外框显式算进 CARD_BORDER_Y，
// 并在 CSS 里给标题和 metrics 写死整数 line-height。
//
// 下面这些常量是在真实 Chromium 里逐项量出来的，不是手推的（第一版就是手推的，
// 把 border-box 语义想错了，每行多算 1px）：
//   TASK PROCESSOR(3 行, metrics 2 行)  实测 198 = 2 + 88 + 3×36
//   DECISION GATE (4 行, metrics 2 行)  实测 234 = 2 + 88 + 4×36
//   COMPLETE      (2 行, metrics 2 行)  实测 162 = 2 + 88 + 2×36
// e2e/smoke.spec.ts 里有一条用例把「状态区高度 = 行数 × ROW_HEIGHT」钉在真实渲染上，
// 因为这条一旦漂移，jsdom 是量不出来的。
//
// 唯一仍然是估算的是 metrics 的换行行数：它按字符数除以估算字宽算，
// 真实换行点取决于字体度量，跨平台可能差一行。这是刻意保留的近似。

export interface XY { x: number; y: number }

/** 与设计稿一致的高度估算，详见 spec 第 7 节 */
export function estimateNodeHeight(node: GraphNode): number {
  const charsPerLine = Math.max(
    MIN_CHARS_PER_LINE,
    Math.floor((NODE_WIDTH - CARD_BORDER_X - HEAD_SIDE_PADDING) / METRICS_CHAR_WIDTH),
  )
  const lines = Math.max(1, Math.ceil(node.metrics.length / charsPerLine))
  const headHeight =
    HEAD_PADDING_TOP + TITLE_LINE_HEIGHT + TITLE_METRICS_GAP +
    lines * METRICS_LINE_HEIGHT + HEAD_PADDING_BOTTOM
  const rowsHeight = node.status_list.length * ROW_HEIGHT
  return CARD_BORDER_Y + headHeight + rowsHeight
}

export function layoutGraph(nodes: GraphNode[], edges: GraphEdge[]): Record<string, XY> {
  if (nodes.length === 0) return {}

  const graph = new dagre.graphlib.Graph()
  graph.setGraph({ rankdir: 'LR', nodesep: 60, ranksep: 160, marginx: 40, marginy: 40 })
  graph.setDefaultEdgeLabel(() => ({}))

  const heights = new Map<string, number>()
  for (const node of nodes) {
    const height = estimateNodeHeight(node)
    heights.set(node.node_id, height)
    graph.setNode(node.node_id, { width: NODE_WIDTH, height })
  }

  const known = new Set(nodes.map(n => n.node_id))
  for (const edge of edges) {
    if (known.has(edge.from_node_id) && known.has(edge.to_node_id)) {
      graph.setEdge(edge.from_node_id, edge.to_node_id)
    }
  }

  dagre.layout(graph)

  // dagre 返回的是中心点，React Flow 用的是左上角
  return Object.fromEntries(
    nodes.map(node => {
      const laid = graph.node(node.node_id)
      const height = heights.get(node.node_id)!
      return [node.node_id, { x: laid.x - NODE_WIDTH / 2, y: laid.y - height / 2 }]
    }),
  )
}

/** 新建节点放到现有布局的右侧空白处，避免重排已有节点 */
export function placeNewNode(positions: Record<string, XY>): XY {
  const all = Object.values(positions)
  if (all.length === 0) return { x: 0, y: 0 }
  const maxX = Math.max(...all.map(p => p.x))
  const minY = Math.min(...all.map(p => p.y))
  return { x: maxX + NODE_WIDTH + NEW_NODE_GAP, y: minY }
}

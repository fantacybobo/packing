import type { XY } from './layout'

/** 边标签沿着连线放在哪一端。 */
export type EdgeLabelPlacement = 'left' | 'center' | 'right'

/**
 * 边标签放哪一端 —— 改这一行就换全图的摆法，界面上不提供开关。
 *
 * 'right'（靠近箭头）是默认：标签都挤在连线中点时，交叉的边会互相遮挡，
 * 而两端附近的密度低得多。'center' 是原来的行为，'left' 靠近起点。
 */
export const EDGE_LABEL_PLACEMENT: EdgeLabelPlacement = 'right'

/**
 * 标签锚点离端点留出的距离（沿曲线量）。箭头本身 18px，22 再加上锚点把整个标签
 * 推到端点的另一侧（见 EDGE_LABEL_ANCHOR），标签与箭头不会叠在一起。
 */
const END_GAP = 22

/** 采样段数。曲线越平滑采样越准，24 段对一条边的弧长估计误差已在 1px 以内。 */
const SAMPLES = 24

/**
 * 短于这个长度的边直接用中点。
 * 不能写成 `total === 0`：两端重合时贝塞尔求值会留下浮点残渣（4.999… / 5.000…1），
 * 弧长是个非零的极小值，于是「退回中点」这条路径实际永远走不到。
 * 而一条不足 1px 的边本来也谈不上靠哪一端。
 */
const MIN_CURVE_LENGTH = 1

/**
 * 标签相对锚点怎么摆。
 * 靠左时标签整个在锚点右侧、靠右时整个在锚点左侧 —— 这样即便 END_GAP 很小，
 * 标签也不会压到端点的箭头上；居中时才是常规的两向居中。
 */
export const EDGE_LABEL_ANCHOR: Record<EdgeLabelPlacement, string> = {
  left: 'translate(0, -50%)',
  center: 'translate(-50%, -50%)',
  right: 'translate(-100%, -50%)',
}

/**
 * 从 React Flow 生成的路径里取出三次贝塞尔的四个控制点。
 *
 * 直接解析路径字符串，而不是照抄一份 getBezierPath 的控制点算法：
 * 那份算法（曲率、端点朝向的处理）是 React Flow 的内部细节，抄一份就等于埋一个
 * 会随版本漂移、且漂移时毫无信号的副本。路径是它的输出，永远是对的。
 *
 * 形如 `M0,0 C50,0 50,100 100,100`；不是这个形状（直线边等）时返回 null。
 */
export function parseCubicPath(path: string): number[] | null {
  const numbers = path.match(/-?\d*\.?\d+(?:e[-+]?\d+)?/gi)?.map(Number)
  if (!numbers || numbers.length < 8 || numbers.some(n => !Number.isFinite(n))) return null
  return numbers.slice(0, 8)
}

/** 三次贝塞尔在参数 t 处的点。points 为 [x0,y0,x1,y1,x2,y2,x3,y3]。 */
export function cubicPointAt(points: number[], t: number): XY {
  const [x0, y0, x1, y1, x2, y2, x3, y3] = points
  const u = 1 - t
  const a = u * u * u
  const b = 3 * u * u * t
  const c = 3 * u * t * t
  const d = t * t * t
  return {
    x: a * x0 + b * x1 + c * x2 + d * x3,
    y: a * y0 + b * y1 + c * y2 + d * y3,
  }
}

/**
 * 标签锚点该落在曲线的哪个位置。
 *
 * 按弧长而不是按参数 t 取点：贝塞尔的 t 与弧长不是线性关系，
 * 直接取 t=0.8 在弯度大的边上会明显偏离「离箭头 22px」这个意图。
 * 短边上 END_GAP 会超过半条边，这时收敛到中点 —— 宁可退化成居中，
 * 也不能让「靠右」的标签跑到起点那一侧去。
 */
export function edgeLabelPoint(
  path: string,
  placement: EdgeLabelPlacement,
  fallback: XY,
): XY {
  if (placement === 'center') return fallback
  const points = parseCubicPath(path)
  if (!points) return fallback

  // 采样出等参数间隔的点与累计弧长
  const samples: { t: number; length: number }[] = [{ t: 0, length: 0 }]
  let previous = cubicPointAt(points, 0)
  let total = 0
  for (let i = 1; i <= SAMPLES; i++) {
    const t = i / SAMPLES
    const current = cubicPointAt(points, t)
    total += Math.hypot(current.x - previous.x, current.y - previous.y)
    samples.push({ t, length: total })
    previous = current
  }
  if (total < MIN_CURVE_LENGTH) return fallback

  const target = placement === 'left'
    ? Math.min(END_GAP, total / 2)
    : Math.max(total - END_GAP, total / 2)

  for (let i = 1; i < samples.length; i++) {
    const from = samples[i - 1]
    const to = samples[i]
    if (to.length < target) continue
    const span = to.length - from.length
    const ratio = span === 0 ? 0 : (target - from.length) / span
    return cubicPointAt(points, from.t + (to.t - from.t) * ratio)
  }
  return cubicPointAt(points, 1)
}

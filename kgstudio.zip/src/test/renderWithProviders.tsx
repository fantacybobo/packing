import type { ReactElement, ReactNode } from 'react'
import { render, type RenderOptions } from '@testing-library/react'
import { App as AntApp, ConfigProvider } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import { MemoryRouter } from 'react-router-dom'

interface Options extends Omit<RenderOptions, 'wrapper'> {
  /** 初始 URL 查询串，例如 '?nodes=N01&hop=1' */
  searchParams?: string
  /** 初始路径，默认 '/'。影响 NavLink 的选中态与 <Routes> 的匹配 */
  initialPath?: string
}

/**
 * 在与生产一致的 Provider 组合下渲染组件。
 * 关键是 ConfigProvider 的 autoInsertSpace: false —— 少了它 antd 会把
 * 「保存」渲染成「保 存」，所有按名查询按钮的测试都会失配。
 * 不注入 theme：测试不断言样式，省掉暗色算法的 CSS-in-JS 开销。
 *
 * 路径与查询串一起交给 MemoryRouter：查询状态现在只从 URL 单向读取
 * （useSearchParams），生产与测试是同一条路径，不再有第二个查询串真源。
 */
export function renderWithProviders(
  ui: ReactElement,
  { searchParams = '', initialPath = '/', ...options }: Options = {},
) {
  const Wrapper = ({ children }: { children: ReactNode }) => (
    <MemoryRouter initialEntries={[`${initialPath}${searchParams}`]}>
      <ConfigProvider locale={zhCN} button={{ autoInsertSpace: false }}>
        <AntApp>{children}</AntApp>
      </ConfigProvider>
    </MemoryRouter>
  )
  return render(ui, { wrapper: Wrapper, ...options })
}

import '@testing-library/jest-dom/vitest'
import { beforeAll, beforeEach, afterEach, afterAll } from 'vitest'
import { server } from '@/mocks/server'
import { DEMO_OBJECT, resetDb } from '@/mocks/db'
import { setGraphObjectRef } from '@/api/objectContext'
import { resetAuth } from '@/api/auth'

// antd 的响应式断点依赖 matchMedia，jsdom 未实现
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
  }),
})

// React Flow 的容器尺寸测量依赖 ResizeObserver，jsdom 未实现
globalThis.ResizeObserver = class {
  observe() {}
  unobserve() {}
  disconnect() {}
}

// MSW node server：拦截绝对 URL 请求，全部测试文件共用同一个实例与生命周期。
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }))

// 图对象标识是所有接口的前置条件（mock 会真的挡住缺失的请求），
// 所以每个用例开场都给一份，等价于「用户从带参数的深链进了编辑页」。
// 需要验证「没带标识会怎样」的用例自己 setGraphObjectRef(null)。
beforeEach(() => setGraphObjectRef(DEMO_OBJECT))

afterEach(() => {
  server.resetHandlers()
  resetDb()
  resetAuth()
  setGraphObjectRef(null)
})
afterAll(() => server.close())

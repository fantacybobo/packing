/**
 * 图对象的标识（object_id + object_version）。
 *
 * 编辑页面编辑的不是「那张图」，而是「某个对象的某个版本」下的那张图：
 * 同一批 node / edge 在另一个版本里可能完全不同。所以图谱页发出的**每一个**请求，
 * 无论 GET 还是 POST，都必须带上这两个字段（见 api/client.ts 的 buildUrl）。
 *
 * 放模块级而不是逐个参数透传：透传等于给每个调用点一次漏掉的机会，
 * 而漏掉的后果是静默的 —— 后端按默认版本返回数据，界面看起来完全正常，
 * 用户却在改另一个版本的图。这里集中一处，client 统一拼，没有第二条路径。
 *
 * 真源是 URL（进入编辑页时带进来），由 hooks/useGraphQuery.ts 的
 * useGraphObjectRefSync 在渲染期同步到这里。
 */

export interface GraphObjectRef {
  objectId: string
  objectVersion: string
}

/** 查询串里的字段名。前端、mock、后端共用这一份，避免三处各写一遍拼错。 */
export const OBJECT_ID_PARAM = 'object_id'
export const OBJECT_VERSION_PARAM = 'object_version'

let current: GraphObjectRef | null = null
let warned = false

export function setGraphObjectRef(next: GraphObjectRef | null): void {
  current = next
  // 换了对象就重新允许警告一次，否则第二次进入无标识的页面会静悄悄的
  if (next) warned = false
}

export function getGraphObjectRef(): GraphObjectRef | null {
  return current
}

export function isSameObjectRef(a: GraphObjectRef | null, b: GraphObjectRef | null): boolean {
  if (a === b) return true
  if (!a || !b) return false
  return a.objectId === b.objectId && a.objectVersion === b.objectVersion
}

/**
 * client 拼进查询串的键值对。没有标识时返回空对象并吼一次 ——
 * 不能悄悄发一个不带版本的请求：那种请求后端多半会用默认版本回一份看着正常的数据。
 */
export function objectParams(): Record<string, string> {
  if (!current) {
    if (!warned) {
      warned = true
      console.warn(
        `[kg-studio] 当前 URL 没有 ${OBJECT_ID_PARAM} / ${OBJECT_VERSION_PARAM}，` +
        '本次请求不会带上图对象标识，后端会拒绝。进入编辑页时请带上这两个参数。',
      )
    }
    return {}
  }
  return {
    [OBJECT_ID_PARAM]: current.objectId,
    [OBJECT_VERSION_PARAM]: current.objectVersion,
  }
}

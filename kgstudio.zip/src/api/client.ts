import type { ApiEnvelope } from '@/types/graph'
import { REQUEST_CREDENTIALS, authHeaders, notifyUnauthorized } from './auth'
import { objectParams } from './objectContext'

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api'

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

/**
 * GET 请求怎么带图对象标识：挂在查询串上，和其它查询条件放在一起。
 * GET 没有 body，这是唯一的去处。
 * path 自带查询串时（例如 /nodes/search?q=x）在其后合并，不会互相覆盖。
 */
function withScopeQuery(path: string): string {
  const [pathname, rawQuery = ''] = path.split('?')
  const search = new URLSearchParams(rawQuery)
  for (const [key, value] of Object.entries(objectParams())) search.set(key, value)
  const query = search.toString()
  return query ? `${pathname}?${query}` : pathname
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      ...init,
      credentials: REQUEST_CREDENTIALS,
      // authHeaders() 是接 SSO 时唯一要改的地方，见 api/auth.ts
      headers: { 'Content-Type': 'application/json', ...authHeaders(), ...init?.headers },
    })
  } catch {
    throw new ApiError('网络请求失败，请检查网络连接后重试', 0)
  }

  // 401 先交给统一处置（接 SSO 后在那里跳登录页 / 刷新 token），再照常抛错：
  // 调用方该看到的失败不能因为有了跳转就被吞掉。
  if (response.status === 401) notifyUnauthorized()

  let envelope: ApiEnvelope<T>
  try {
    envelope = (await response.json()) as ApiEnvelope<T>
  } catch {
    throw new ApiError(`服务返回了非法响应（HTTP ${response.status}）`, response.status)
  }

  // 失败与否只看 HTTP 状态与信封的 success。
  // 不能把 data === null 当成失败：后端对无内容响应返回
  // { success: true, data: null } 是常见做法，那是成功而不是错误。
  if (!response.ok || !envelope.success) {
    throw new ApiError(envelope.error ?? `请求失败（HTTP ${response.status}）`, response.status)
  }
  return envelope.data as T
}

/**
 * 后端只接受 GET 与 POST，所以这里只有这两个动词 —— 没有 putJson / deleteJson。
 * 更新与删除都走 POST，路径见 api/graph.ts（更新 POST /x/:id，删除 POST /x/:id/delete）。
 * 不要在这里补回 PUT / DELETE：那样的请求会被后端直接拒掉，而失败点会远离出错的地方。
 *
 * 两个动词各自怎么带图对象标识，是后端定的约定：
 *   - GET：挂查询串（没有 body，也只能这样）
 *   - POST：统一放进 payload，**不**出现在 URL 上
 * 差异集中在这两行里，业务模块一律只管传自己的业务载荷。
 */
export const getJson = <T>(path: string) => request<T>(withScopeQuery(path))

/**
 * 不带图对象标识的 GET。
 *
 * 总览页的分类树与图谱列表是跨对象的，它们不属于「某个对象的某个版本」这个作用域。
 * 硬塞进去不只是多两个没用的参数：objectContext 的 ref 在离开图谱页时不会清，
 * 用户从 /graph?object_id=A 回到总览，这两个接口就会带上一个跟它们毫无关系的 A，
 * 而且 objectParams() 还会在没有 ref 时吼一句「后端会拒绝」的警告 —— 对这些接口是假警报。
 *
 * 判据很简单：这个接口的语义里有没有「哪个对象的哪个版本」。有就用 getJson。
 */
export const getUnscopedJson = <T>(path: string) => request<T>(path)

/**
 * body 必须是个对象：图对象标识要合并进去。类型上就挡住传数组或基本类型 ——
 * 那样展开出来会是 { 0: …, 1: … } 这种没人看得懂的 payload，而且不会报错。
 *
 * 标识放在展开的最后一位：它是这次请求作用在哪张图的哪个版本上的权威来源，
 * 业务载荷里万一有同名字段也不该盖过它。
 */
export const postJson = <T>(path: string, body: object) =>
  request<T>(path, {
    method: 'POST',
    body: JSON.stringify({ ...body, ...objectParams() }),
  })

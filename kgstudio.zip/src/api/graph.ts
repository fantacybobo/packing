import { getJson, postJson } from './client'
import type {
  EdgePayload, GraphEdge, GraphNode, GraphQueryRequest,
  GraphQueryResponse, NodeDocument, NodePayload,
} from '@/types/graph'

/**
 * 图谱页的全部接口。后端只接受 GET 与 POST：
 *   - 更新走 POST /资源/:id（与「新建」的 POST /资源 按路径区分）
 *   - 删除走 POST /资源/:id/delete（没有 body 可以区分，所以路径上写明动作）
 * 每个请求还会自动带上 object_id / object_version，由 api/client.ts 统一拼，
 * 这里不用、也不该逐个传（见 api/objectContext.ts）。
 */

export const searchNodes = (q: string) =>
  getJson<GraphNode[]>(`/nodes/search?q=${encodeURIComponent(q)}`)

export const queryGraph = (req: GraphQueryRequest) =>
  postJson<GraphQueryResponse>('/graph/query', req)

export const createNodeApi = (payload: NodePayload) =>
  postJson<GraphNode>('/nodes', payload)

export const updateNodeApi = (nodeId: string, payload: NodePayload) =>
  postJson<GraphNode>(`/nodes/${encodeURIComponent(nodeId)}`, payload)

export const deleteNodeApi = (nodeId: string) =>
  postJson<{ deleted_edge_ids: string[] }>(`/nodes/${encodeURIComponent(nodeId)}/delete`, {})

export const createEdgeApi = (payload: EdgePayload) =>
  postJson<GraphEdge>('/edges', payload)

export const updateEdgeApi = (edgeId: string, payload: EdgePayload) =>
  postJson<GraphEdge>(`/edges/${encodeURIComponent(edgeId)}`, payload)

export const deleteEdgeApi = (edgeId: string) =>
  postJson<{ edge_id: string }>(`/edges/${encodeURIComponent(edgeId)}/delete`, {})

export const getDocument = (documentId: string) =>
  getJson<NodeDocument>(`/documents/${encodeURIComponent(documentId)}`)

export const updateDocument = (doc: NodeDocument) =>
  postJson<NodeDocument>(`/documents/${encodeURIComponent(doc.document_id)}`, doc)

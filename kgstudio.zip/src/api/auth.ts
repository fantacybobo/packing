/**
 * 认证接入点 —— 全应用唯一一处往请求上挂身份信息的地方。
 *
 * 现在还没有登录，`authHeaders()` 返回空对象，所有请求都是匿名的。
 * 将来接公司 SSO 时**只改这个文件**，api/client.ts 与各业务模块一行都不用动：
 *
 *   1. 拿到 token 之后调 `setAuthToken(token)`（SSO 回调页、或者刷新 token 的定时器里）。
 *      如果公司的 SSO 是 Cookie 模式而不是 Bearer 模式，改 `REQUEST_CREDENTIALS`
 *      为 'include' 即可，token 那条路可以整个不用。
 *   2. 需要带别的头（租户 id、X-Request-Id、语言……）就往 `extraHeaders` 里塞，
 *      `authHeaders()` 会把它们和 Authorization 合并后交给 client。
 *   3. 401 的统一处置（跳登录页 / 静默刷新 token / 弹窗）写在
 *      `setUnauthorizedHandler` 注册的回调里，client 在收到 401 时会调它一次。
 *      注册的动作适合放在 main.tsx 的 bootstrap 里。
 *
 * 为什么是模块级可变状态而不是 React context：发请求的 api/client.ts 不是组件，
 * 拿不到 context；而把 token 逐层透传进每个 api 函数，等于给每个调用点一次漏掉的机会 ——
 * 「统一带上」这件事就不再有保证。同理见 api/objectContext.ts。
 */

type UnauthorizedHandler = () => void

let token: string | null = null
let extraHeaders: Readonly<Record<string, string>> = {}
let onUnauthorized: UnauthorizedHandler | null = null

/**
 * Cookie 模式的 SSO 把这里改成 'include'（跨站时还需要后端放开 CORS 的
 * Access-Control-Allow-Credentials）。默认 'same-origin' 与 fetch 的默认值一致，
 * 写出来是为了让「改哪里」一眼可见。
 */
export const REQUEST_CREDENTIALS: RequestCredentials = 'same-origin'

/** SSO 登录成功 / 刷新 token 后调用；传 null 表示登出。 */
export function setAuthToken(next: string | null): void {
  token = next
}

export function getAuthToken(): string | null {
  return token
}

/** 除 Authorization 之外还要随每个请求发出去的头。整份替换，不做合并。 */
export function setExtraHeaders(headers: Record<string, string>): void {
  extraHeaders = { ...headers }
}

/** 注册 401 的统一处置。传 null 取消注册。 */
export function setUnauthorizedHandler(handler: UnauthorizedHandler | null): void {
  onUnauthorized = handler
}

/** client 在收到 401 时调用。没注册处置时什么都不做，不能因此让请求本身失败。 */
export function notifyUnauthorized(): void {
  onUnauthorized?.()
}

/** client 给每个请求合并进 headers 的内容。没有 token 时不产出 Authorization 头。 */
export function authHeaders(): Record<string, string> {
  return token ? { ...extraHeaders, Authorization: `Bearer ${token}` } : { ...extraHeaders }
}

/** 仅供测试与登出使用：把这个模块恢复到初始状态。 */
export function resetAuth(): void {
  token = null
  extraHeaders = {}
  onUnauthorized = null
}

import { describe, it, expect, vi, afterEach } from 'vitest'
import { ApiError, getJson, postJson } from './client'
import { setAuthToken, setExtraHeaders, setUnauthorizedHandler } from './auth'
import { setGraphObjectRef } from './objectContext'

function mockFetchOnce(body: unknown, init: { status?: number; ok?: boolean } = {}) {
  const status = init.status ?? 200
  vi.stubGlobal('fetch', vi.fn(async () => ({
    ok: init.ok ?? status < 400,
    status,
    json: async () => body,
  })))
}

afterEach(() => {
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

describe('getJson', () => {
  it('成功时解开信封只返回 data', async () => {
    mockFetchOnce({ success: true, data: { node_id: 'N01' }, error: null })
    await expect(getJson('/nodes/N01')).resolves.toEqual({ node_id: 'N01' })
  })

  it('success 为 true 但 data 为 null 时视为成功，不抛错', async () => {
    mockFetchOnce({ success: true, data: null, error: null })
    await expect(getJson('/edges/E001')).resolves.toBeNull()
  })

  it('信封 success 为 false 时抛出 ApiError 并带上后端错误文案', async () => {
    mockFetchOnce({ success: false, data: null, error: '节点不存在' }, { status: 404 })
    await expect(getJson('/nodes/NONE')).rejects.toThrow(ApiError)
    await expect(getJson('/nodes/NONE')).rejects.toThrow('节点不存在')
  })

  it('HTTP 200 但 success 为 false 时同样视为失败', async () => {
    mockFetchOnce({ success: false, data: null, error: '参数非法' }, { status: 200 })
    await expect(getJson('/nodes/x')).rejects.toThrow('参数非法')
  })

  it('响应不是合法 JSON 时抛出可读错误', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({
      ok: false,
      status: 500,
      json: async () => { throw new SyntaxError('Unexpected token') },
    })))
    await expect(getJson('/nodes')).rejects.toThrow('HTTP 500')
  })

  it('网络中断时抛出 status 为 0 的 ApiError', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch') }))
    await expect(getJson('/nodes')).rejects.toMatchObject({ status: 0 })
  })
})

describe('postJson', () => {
  it('以 JSON 方式发送请求体', async () => {
    const fetchMock = vi.fn(async () => ({ ok: true, status: 200, json: async () => ({ success: true, data: { ok: 1 }, error: null }) }))
    vi.stubGlobal('fetch', fetchMock)
    setGraphObjectRef(null)
    vi.spyOn(console, 'warn').mockImplementation(() => {})
    await postJson('/edges', { priority: 3 })
    const [, init] = (fetchMock.mock.calls[0] as unknown[]) as [string, RequestInit]
    expect(init.method).toBe('POST')
    // 图对象标识也会合并进 body（见下面的「POST：放进 payload」），这里只看业务载荷本身
    expect(init.body).toBe(JSON.stringify({ priority: 3 }))
  })
})

// —— 图对象标识 ——
// 编辑页的每个请求都必须带上 object_id / object_version（见 api/objectContext.ts）。
// 靠 client 统一拼，而不是各调用点自己传：这里是「统一带上」这条保证的唯一凭证。
//
// 两个动词的去处不同，是后端定的约定：GET 挂查询串，POST 放 payload。
// 这组用例同时钉住「带上了」和「没带到另一个地方去」两件事 ——
// 只断言前者的话，一个两头都塞的实现同样能过。
describe('图对象标识', () => {
  const urlOf = (fetchMock: { mock: { calls: unknown[][] } }) =>
    new URL(fetchMock.mock.calls[0][0] as string, 'http://localhost')
  const bodyOf = (fetchMock: { mock: { calls: unknown[][] } }) =>
    JSON.parse((fetchMock.mock.calls[0][1] as RequestInit).body as string)

  const stubOk = () => {
    const fetchMock = vi.fn(async () => ({
      ok: true, status: 200, json: async () => ({ success: true, data: null, error: null }),
    }))
    vi.stubGlobal('fetch', fetchMock)
    return fetchMock
  }

  describe('GET：挂在查询串上', () => {
    it('带上两个字段', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await getJson('/nodes/N01')
      const url = urlOf(fetchMock)
      expect(url.pathname).toBe('/api/nodes/N01')
      expect(url.searchParams.get('object_id')).toBe('OBJ-7')
      expect(url.searchParams.get('object_version')).toBe('v9')
    })

    it('路径自带查询串时是合并而不是覆盖', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await getJson('/nodes/search?q=TASK%20PROCESSOR')
      const url = urlOf(fetchMock)
      expect(url.searchParams.get('q')).toBe('TASK PROCESSOR')
      expect(url.searchParams.get('object_version')).toBe('v9')
    })

    it('没有标识时不硬塞空值进去', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef(null)
      vi.spyOn(console, 'warn').mockImplementation(() => {})
      await getJson('/nodes/N01')
      const url = urlOf(fetchMock)
      expect(url.searchParams.has('object_id')).toBe(false)
      expect(url.searchParams.has('object_version')).toBe(false)
    })
  })

  describe('POST：放进 payload', () => {
    it('两个字段进 body', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await postJson('/graph/query', { node_ids: ['N01'], hop: 1 })
      expect(bodyOf(fetchMock)).toEqual({
        node_ids: ['N01'], hop: 1, object_id: 'OBJ-7', object_version: 'v9',
      })
    })

    // 后端要的是「POST 统一放 payload」，不是「两头都塞一份」。
    // URL 上再留一份等于同一个事实有两个来源，两边对不上时谁说了算没有定论。
    it('URL 上不再出现这两个参数', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await postJson('/graph/query', { node_ids: ['N01'], hop: 1 })
      const url = urlOf(fetchMock)
      expect(url.pathname).toBe('/api/graph/query')
      expect(url.search).toBe('')
    })

    it('没有 body 内容的接口（删除）也照样带上', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await postJson('/nodes/N01/delete', {})
      expect(bodyOf(fetchMock)).toEqual({ object_id: 'OBJ-7', object_version: 'v9' })
    })

    it('业务载荷里的同名字段盖不过真正的标识', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
      await postJson('/nodes', { entity: 'X', object_id: '伪造的' })
      expect(bodyOf(fetchMock).object_id).toBe('OBJ-7')
    })

    it('没有标识时 body 里就不该出现这两个键', async () => {
      const fetchMock = stubOk()
      setGraphObjectRef(null)
      vi.spyOn(console, 'warn').mockImplementation(() => {})
      await postJson('/graph/query', { node_ids: ['N01'], hop: 1 })
      expect(bodyOf(fetchMock)).toEqual({ node_ids: ['N01'], hop: 1 })
    })
  })
})

// —— SSO 接入点 ——
// 这几条用例的作用是把 api/auth.ts 钉成「唯一要改的地方」：
// 真接上 SSO 时只要 setAuthToken / setExtraHeaders，请求就自带身份，
// 各业务模块一行都不用动。
describe('认证信息', () => {
  const stubOk = (status = 200) => {
    const fetchMock = vi.fn(async () => ({
      ok: status < 400, status,
      json: async () => ({ success: status < 400, data: null, error: '未登录' }),
    }))
    vi.stubGlobal('fetch', fetchMock)
    return fetchMock
  }
  const headersOf = (fetchMock: { mock: { calls: unknown[][] } }) =>
    (fetchMock.mock.calls[0][1] as RequestInit).headers as Record<string, string>

  it('没有 token 时不产出 Authorization 头', async () => {
    const fetchMock = stubOk()
    await getJson('/nodes/N01')
    expect(headersOf(fetchMock)).not.toHaveProperty('Authorization')
  })

  it('setAuthToken 之后每个请求自带 Bearer 头', async () => {
    const fetchMock = stubOk()
    setAuthToken('sso-token')
    await getJson('/nodes/N01')
    expect(headersOf(fetchMock).Authorization).toBe('Bearer sso-token')
  })

  it('setExtraHeaders 里的头一并带上（租户 id、追踪 id 之类）', async () => {
    const fetchMock = stubOk()
    setExtraHeaders({ 'X-Tenant-Id': 'meshy' })
    await getJson('/nodes/N01')
    expect(headersOf(fetchMock)['X-Tenant-Id']).toBe('meshy')
  })

  it('401 会通知统一处置，但请求本身照样抛错', async () => {
    stubOk(401)
    const onUnauthorized = vi.fn()
    setUnauthorizedHandler(onUnauthorized)
    await expect(getJson('/nodes/N01')).rejects.toThrow(ApiError)
    expect(onUnauthorized).toHaveBeenCalledTimes(1)
  })

  it('没注册处置时 401 不会因此变成另一种崩溃', async () => {
    stubOk(401)
    setUnauthorizedHandler(null)
    await expect(getJson('/nodes/N01')).rejects.toMatchObject({ status: 401 })
  })
})

import { getUnscopedJson } from './client'
import type { CategoryNode, KnowledgeObjectSummary } from '@/types/overview'

/**
 * 总览页的接口。
 *
 * 两个都走 getUnscopedJson：它们是跨图对象的，不该带 object_id / object_version。
 * 用 getJson 的话，用户从 /graph?object_id=A 回到总览后，这两个请求会莫名其妙
 * 带上 A —— objectContext 的 ref 离开图谱页时并不会清。
 *
 * TODO(后端): 路径与返回信封是按现有约定拟的（信封同 ApiEnvelope）。
 * 真实契约定下来后改这两行即可，调用方不用动。
 */

export const fetchCategoryTree = () => getUnscopedJson<CategoryNode[]>('/categories')

export const fetchKnowledgeObjects = (categoryId: string, domainId: string) =>
  getUnscopedJson<KnowledgeObjectSummary[]>(
    `/knowledge-objects?category_id=${encodeURIComponent(categoryId)}` +
    `&domain_id=${encodeURIComponent(domainId)}`,
  )

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import {
  getGraphObjectRef, isSameObjectRef, objectParams, setGraphObjectRef,
} from './objectContext'

beforeEach(() => setGraphObjectRef(null))
afterEach(() => vi.restoreAllMocks())

describe('setGraphObjectRef / objectParams', () => {
  it('把标识拼成 client 要的查询参数', () => {
    setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
    expect(objectParams()).toEqual({ object_id: 'OBJ-7', object_version: 'v9' })
  })

  it('没有标识时给空对象，而不是塞两个空串进去', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {})
    expect(objectParams()).toEqual({})
  })

  // 静默是这里最危险的失败方式：后端若按默认版本回一份看着正常的数据，
  // 用户会以为自己在改 A 版本，实际改的是 B。至少要在控制台留个信号。
  it('没有标识时吼一声，但不连着吼', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    objectParams()
    objectParams()
    objectParams()
    expect(warn).toHaveBeenCalledTimes(1)
    expect(warn.mock.calls[0][0]).toContain('object_id')
  })

  it('换了对象之后再次缺失时会重新吼，不会因为吼过一次就永远闭嘴', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    objectParams()
    setGraphObjectRef({ objectId: 'OBJ-7', objectVersion: 'v9' })
    setGraphObjectRef(null)
    objectParams()
    expect(warn).toHaveBeenCalledTimes(2)
  })

  it('读得回刚设进去的值', () => {
    const ref = { objectId: 'OBJ-7', objectVersion: 'v9' }
    setGraphObjectRef(ref)
    expect(getGraphObjectRef()).toEqual(ref)
  })
})

describe('isSameObjectRef', () => {
  it('按值比较，不按引用', () => {
    expect(isSameObjectRef(
      { objectId: 'A', objectVersion: '1' },
      { objectId: 'A', objectVersion: '1' },
    )).toBe(true)
  })

  it('版本不同就是不同的对象', () => {
    expect(isSameObjectRef(
      { objectId: 'A', objectVersion: '1' },
      { objectId: 'A', objectVersion: '2' },
    )).toBe(false)
  })

  it('两个 null 相同，一个 null 不同', () => {
    expect(isSameObjectRef(null, null)).toBe(true)
    expect(isSameObjectRef(null, { objectId: 'A', objectVersion: '1' })).toBe(false)
    expect(isSameObjectRef({ objectId: 'A', objectVersion: '1' }, null)).toBe(false)
  })
})

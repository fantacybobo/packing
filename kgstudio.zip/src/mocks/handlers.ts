import { http, HttpResponse } from 'msw'
import { db, expandGraph, nextEdgeId, nextNodeId, nextStatusId } from './db'
import { OBJECT_ID_PARAM, OBJECT_VERSION_PARAM } from '@/api/objectContext'
import type { EdgePayload, GraphEdge, GraphNode, NodePayload, NodeDocument } from '@/types/graph'
import { CATEGORY_TREE, KNOWLEDGE_OBJECTS } from './overviewDb'

const ok = <T>(data: T) => HttpResponse.json({ success: true, data, error: null })
const fail = (error: string, status: number) =>
  HttpResponse.json({ success: false, data: null, error }, { status })

// —— 写接口的校验 ——
// 读接口（POST /api/graph/query）按 spec 挡住了边界，写接口原本什么都不查：
// POST /api/edges 会愉快地收下引用不存在节点/状态的边，正是 Item 1 那种孤儿边的
// 服务端来源。mock 是后端作者的实现说明书，这些约束必须写在这里。
// 前端 canvasPolicy 同样拦自环与重复边 —— 那是有意的纵深防御，不是可以合并掉的重复。

const isFilled = (value: unknown) => typeof value === 'string' && value.trim().length > 0

// —— 图对象标识（object_id / object_version）——
// 编辑页的每一个接口都在「某个对象的某个版本」下工作，两个字段缺一不可。
// mock 在这里真的挡住，是因为漏带的后果在界面上完全看不出来：后端若宽容地按默认版本
// 返回数据，用户会以为自己在改 A 版本，实际改的是 B。失败必须发生在开发期，而不是上线后。
//
// 两个动词的取处不同，这是后端定的约定：
//   - GET 从查询串取（没有 body）
//   - POST 从 payload 取，URL 上不会有
const SCOPE_KEYS = [OBJECT_ID_PARAM, OBJECT_VERSION_PARAM]

const missingScope = (missing: string[]): string | null =>
  missing.length > 0
    ? `缺少图对象标识：${missing.join('、')}（图谱页的所有接口都必须带上）`
    : null

const scopeError = (request: Request): string | null => {
  const params = new URL(request.url).searchParams
  return missingScope(SCOPE_KEYS.filter(key => !(params.get(key) ?? '').trim()))
}

const bodyScopeError = (payload: unknown): string | null => {
  const body = (payload ?? {}) as Record<string, unknown>
  return missingScope(SCOPE_KEYS.filter(key => {
    const value = body[key]
    return typeof value !== 'string' || value.trim().length === 0
  }))
}

/**
 * 把图对象标识从业务载荷里摘掉。
 *
 * 【后端契约】这两个字段是「这次请求作用在哪张图的哪个版本上」的定址信息，
 * 不是实体的字段。原样存进库里，节点 / 边 / 文档上就会多出两个谁也没声明过的键，
 * 下一次读出来又原样发回前端 —— 一个字段就这样凭空长进了数据模型里。
 */
function withoutScope<T extends object>(payload: T): T {
  const rest = { ...payload } as Record<string, unknown>
  for (const key of SCOPE_KEYS) delete rest[key]
  return rest as T
}

const nodeError = (payload: NodePayload): string | null => {
  if (!isFilled(payload?.entity)) return 'entity 不能为空'
  if (!isFilled(payload?.metrics)) return 'metrics 不能为空'
  return null
}

const DOCUMENT_FIELDS: (keyof NodeDocument)[] = [
  'document_id', 'prerequisite', 'check_question',
  'evaluation_method', 'description', 'flow_reason', 'remark',
]

const documentError = (payload: NodeDocument): string | null => {
  // spec §5：文档更新是全量覆盖，7 个字段一个都不能少（允许为空串，用户可以清空备注）
  const missing = DOCUMENT_FIELDS.filter(field => typeof payload?.[field] !== 'string')
  return missing.length > 0 ? `文档更新必须全量回传 7 个字段，缺少：${missing.join('、')}` : null
}

const sameEndpoints = (edge: GraphEdge, payload: EdgePayload) =>
  edge.from_node_id === payload.from_node_id &&
  edge.to_node_id === payload.to_node_id &&
  edge.from_status_id === payload.from_status_id &&
  edge.to_status_id === payload.to_status_id

/** 返回 [错误文案, HTTP 状态]，合法时返回 null。ignoreEdgeId 用于「编辑时不跟自己比重复」 */
function edgeError(payload: EdgePayload, ignoreEdgeId?: string): [string, number] | null {
  const from = db.nodes.find(n => n.node_id === payload?.from_node_id)
  const to = db.nodes.find(n => n.node_id === payload?.to_node_id)
  if (!from || !to) return ['边引用的节点不存在', 400]
  if (!from.status_list.some(s => s.status_id === payload.from_status_id)) {
    return ['from_status_id 不属于 from_node_id', 400]
  }
  if (!to.status_list.some(s => s.status_id === payload.to_status_id)) {
    return ['to_status_id 不属于 to_node_id', 400]
  }
  // status_id 全局唯一（带 node 前缀），相等即同一个状态
  if (payload.from_status_id === payload.to_status_id) return ['不能把一个状态连到它自己', 400]
  if (db.edges.some(e => e.edge_id !== ignoreEdgeId && sameEndpoints(e, payload))) {
    return ['这两个状态之间已经有一条边了', 409]
  }
  return null
}

export const handlers = [
  // ── 总览页 ──
  // 这两个接口是跨图对象的，刻意**不**校验 object_id / object_version：
  // 前端那边走的是 getUnscopedJson，根本不会带。这里跟着一起放行，
  // 否则一个「宽容地接受了标识」的 mock 会把前端的错误用法一路放到线上。
  http.get('*/api/categories', () => ok(CATEGORY_TREE)),

  http.get('*/api/knowledge-objects', ({ request }) => {
    const query = new URL(request.url).searchParams
    const categoryId = query.get('category_id')
    const domainId = query.get('domain_id')
    if (!isFilled(categoryId) || !isFilled(domainId)) {
      return fail('缺少 category_id 或 domain_id', 400)
    }
    // 认不出来的分类回空列表，不是 404：一个没有图谱的分类是正常状态，不是错误
    return ok(KNOWLEDGE_OBJECTS[`${domainId}/${categoryId}`] ?? [])
  }),

  http.get('*/api/nodes/search', ({ request }) => {
    const outOfScope = scopeError(request)
    if (outOfScope) return fail(outOfScope, 400)
    const q = (new URL(request.url).searchParams.get('q') ?? '').trim().toLowerCase()
    const matched = q
      ? db.nodes.filter(n => `${n.entity} ${n.metrics} ${n.node_id}`.toLowerCase().includes(q))
      : db.nodes
    return ok(matched)
  }),

  http.post('*/api/graph/query', async ({ request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const body = raw as { node_ids?: string[]; hop?: number }
    const nodeIds = body.node_ids ?? []
    const hop = body.hop ?? 2
    // mock 同时是给后端看的契约文档，spec 写明的边界必须真的挡住：
    // 否则前端的 clamp 逻辑一旦回退，开发期不会有任何信号。
    if (nodeIds.length < 1 || nodeIds.length > 2) return fail('node_ids 长度必须为 1 或 2', 400)
    if (!Number.isInteger(hop) || hop < 1 || hop > 6) return fail('hop 必须是 1 到 6 的整数', 400)
    return ok(expandGraph(nodeIds, hop))
  }),

  http.post('*/api/nodes', async ({ request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const payload = withoutScope(raw as NodePayload)
    const invalid = nodeError(payload)
    if (invalid) return fail(invalid, 400)
    const nodeId = nextNodeId()
    const node: GraphNode = {
      node_id: nodeId,
      entity: payload.entity,
      metrics: payload.metrics,
      tone: 'default',
      document_id: [],
      status_list: payload.status_list.map(s => ({
        status_id: nextStatusId(nodeId),
        node_id: nodeId,
        status_description: s.status_description,
      })),
    }
    db.nodes = [...db.nodes, node]
    return ok(node)
  }),

  // 更新走 POST /api/nodes/:nodeId —— 后端只接受 GET 与 POST，没有 PUT。
  // 与上面的「新建」按路径区分：有 :nodeId 段的是更新，没有的是新建。
  http.post('*/api/nodes/:nodeId', async ({ params, request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const nodeId = params.nodeId as string
    const existing = db.nodes.find(n => n.node_id === nodeId)
    if (!existing) return fail('节点不存在', 404)
    const payload = withoutScope(raw as NodePayload)
    const invalid = nodeError(payload)
    if (invalid) return fail(invalid, 400)
    const updated: GraphNode = {
      ...existing,
      entity: payload.entity,
      metrics: payload.metrics,
      status_list: payload.status_list.map(s => ({
        // 新增的状态没有 status_id，由后端生成；格式与种子数据保持一致
        status_id: s.status_id ?? nextStatusId(nodeId),
        node_id: nodeId,
        status_description: s.status_description,
      })),
    }
    db.nodes = db.nodes.map(n => (n.node_id === nodeId ? updated : n))
    // 状态行被删掉时，挂在它上面的边必须跟着级联删除 —— 与删除节点同一条规则。
    // 否则库里留下引用已不存在 status_id 的孤儿边：前端的 sourceHandle/targetHandle
    // 挂不到任何 handle 上，边从画布上消失，却仍然躺在库里，谁也看不到、删不掉。
    const liveStatusIds = new Set(updated.status_list.map(s => s.status_id))
    const orphaned = (e: GraphEdge) =>
      (e.from_node_id === nodeId && !liveStatusIds.has(e.from_status_id)) ||
      (e.to_node_id === nodeId && !liveStatusIds.has(e.to_status_id))
    db.edges = db.edges.filter(e => !orphaned(e))
    return ok(updated)
  }),

  // 删除走 POST /api/nodes/:nodeId/delete：没有 DELETE 动词可用，而删除又没有
  // 能跟「更新」区分开的 body，所以把动作写在路径上。
  http.post('*/api/nodes/:nodeId/delete', async ({ params, request }) => {
    const outOfScope = bodyScopeError(await request.json())
    if (outOfScope) return fail(outOfScope, 400)
    const nodeId = params.nodeId as string
    if (!db.nodes.some(n => n.node_id === nodeId)) return fail('节点不存在', 404)
    const removed = db.edges.filter(e => e.from_node_id === nodeId || e.to_node_id === nodeId)
    db.nodes = db.nodes.filter(n => n.node_id !== nodeId)
    db.edges = db.edges.filter(e => !removed.includes(e))
    return ok({ deleted_edge_ids: removed.map(e => e.edge_id) })
  }),

  http.post('*/api/edges', async ({ request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const payload = withoutScope(raw as EdgePayload)
    const invalid = edgeError(payload)
    if (invalid) return fail(...invalid)
    const edge: GraphEdge = { ...payload, tone: 'default', edge_id: nextEdgeId() }
    db.edges = [...db.edges, edge]
    return ok(edge)
  }),

  http.post('*/api/edges/:edgeId', async ({ params, request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const edgeId = params.edgeId as string
    const existing = db.edges.find(e => e.edge_id === edgeId)
    if (!existing) return fail('边不存在', 404)
    const payload = withoutScope(raw as EdgePayload)
    const invalid = edgeError(payload, edgeId)
    if (invalid) return fail(...invalid)
    const updated: GraphEdge = { ...existing, ...payload, tone: 'default' }
    db.edges = db.edges.map(e => (e.edge_id === edgeId ? updated : e))
    return ok(updated)
  }),

  http.post('*/api/edges/:edgeId/delete', async ({ params, request }) => {
    const outOfScope = bodyScopeError(await request.json())
    if (outOfScope) return fail(outOfScope, 400)
    const edgeId = params.edgeId as string
    if (!db.edges.some(e => e.edge_id === edgeId)) return fail('边不存在', 404)
    db.edges = db.edges.filter(e => e.edge_id !== edgeId)
    return ok({ edge_id: edgeId })
  }),

  http.get('*/api/documents/:documentId', ({ params, request }) => {
    const outOfScope = scopeError(request)
    if (outOfScope) return fail(outOfScope, 400)
    const doc = db.documents.find(d => d.document_id === params.documentId)
    return doc ? ok(doc) : fail('文档不存在', 404)
  }),

  http.post('*/api/documents/:documentId', async ({ params, request }) => {
    const raw = await request.json()
    const outOfScope = bodyScopeError(raw)
    if (outOfScope) return fail(outOfScope, 400)
    const documentId = params.documentId as string
    if (!db.documents.some(d => d.document_id === documentId)) return fail('文档不存在', 404)
    const payload = withoutScope(raw as NodeDocument)
    const invalid = documentError(payload)
    if (invalid) return fail(invalid, 400)
    const updated: NodeDocument = { ...payload, document_id: documentId }
    db.documents = db.documents.map(d => (d.document_id === documentId ? updated : d))
    return ok(updated)
  }),
]

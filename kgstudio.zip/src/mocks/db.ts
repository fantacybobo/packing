import type { GraphEdge, GraphNode, GraphQueryResponse, NodeDocument, Tone } from '@/types/graph'

export interface MockDb {
  nodes: GraphNode[]
  edges: GraphEdge[]
  documents: NodeDocument[]
}

const status = (nodeId: string, seq: number, description: string) => ({
  status_id: `${nodeId}-ST${String(seq).padStart(2, '0')}`,
  node_id: nodeId,
  status_description: description,
})

function seed(): MockDb {
  const nodes: GraphNode[] = [
    {
      node_id: 'N01', entity: 'TASK PROCESSOR', tone: 'default', document_id: ['DOC-2026-0001'],
      metrics: '从队列拉取待处理任务，按批次执行并产出结构化结果。',
      status_list: [status('N01', 1, 'Pending'), status('N01', 2, 'Running'), status('N01', 3, 'Active')],
    },
    {
      node_id: 'N02', entity: 'DECISION GATE', tone: 'default', document_id: ['DOC-2026-0002'],
      metrics: '按重试次数与超时阈值分流，决定进入重试或失败分支。',
      status_list: [status('N02', 1, 'Active'), status('N02', 2, 'Active'), status('N02', 3, 'Failed'), status('N02', 4, 'Inactive')],
    },
    {
      node_id: 'N03', entity: 'ERROR HANDLER', tone: 'default', document_id: ['DOC-2026-0003'],
      metrics: '捕获上游失败并决定是否回滚，同时向值班同学告警。',
      status_list: [status('N03', 1, 'Active'), status('N03', 2, 'Pending'), status('N03', 3, 'Active'), status('N03', 4, 'Active')],
    },
    {
      node_id: 'N04', entity: 'COMPLETE', tone: 'default', document_id: ['DOC-2026-0004'],
      metrics: '收口成功与失败两条出口，写入最终状态并通知下游。',
      status_list: [status('N04', 1, 'Inactive'), status('N04', 2, 'Active')],
    },
  ]

  const link = (seq: number, from: [string, number], to: [string, number], priority: number): GraphEdge => ({
    edge_id: `E${String(seq).padStart(3, '0')}`,
    from_node_id: from[0], from_status_id: `${from[0]}-ST${String(from[1]).padStart(2, '0')}`,
    to_node_id: to[0], to_status_id: `${to[0]}-ST${String(to[1]).padStart(2, '0')}`,
    priority, tone: 'default',
  })

  const edges: GraphEdge[] = [
    link(1, ['N01', 1], ['N02', 1], 1),
    link(2, ['N01', 2], ['N02', 2], 2),
    link(3, ['N01', 3], ['N02', 3], 3),
    link(4, ['N02', 1], ['N03', 1], 1),
    link(5, ['N02', 2], ['N03', 2], 5),
    link(6, ['N02', 2], ['N03', 3], 2),
    link(7, ['N02', 4], ['N04', 1], 9),
    link(8, ['N02', 3], ['N04', 2], 4),
    link(9, ['N03', 3], ['N04', 2], 7),
    link(10, ['N03', 4], ['N04', 1], 8),
  ]

  const documents: NodeDocument[] = [
    { document_id: 'DOC-2026-0001', prerequisite: '任务队列可读，且上游 Kafka topic task.queue.v2 已完成分区扩容。', check_question: '本批次任务是否全部落库且无重复消费？', evaluation_method: '对比 source_count 与 sink_count，偏差 > 0.1% 判定失败。', description: '从队列拉取待处理任务，按批次执行并产出结构化结果。', flow_reason: '成功后进入决策网关做重试与超时分流。', remark: '失败超过 5 次进入死信队列，需人工介入。' },
    { document_id: 'DOC-2026-0002', prerequisite: '上游任务节点已产出结果，且重试计数可从状态存储读取。', check_question: '当前重试次数是否小于阈值 5，且未触发超时？', evaluation_method: '读取 retry_count 与 elapsed_ms，按配置中心阈值判定分支。', description: '按重试次数与超时阈值分流，决定进入重试或失败分支。', flow_reason: '按判定结果分别进入错误处理或直接收口。', remark: '阈值变更需灰度发布，禁止直接改线上配置。' },
    { document_id: 'DOC-2026-0003', prerequisite: '已捕获到上游失败事件，并取得对应幂等键。', check_question: '该失败是否可回滚，回滚后数据是否一致？', evaluation_method: '校验幂等键与事务日志，回滚后重新执行一致性检查。', description: '捕获上游失败并决定是否回滚，同时向值班同学告警。', flow_reason: '回滚成功走 done 收口，否则升级告警至值班。', remark: '回滚动作不可重入，触发前需确认幂等键。' },
    { document_id: 'DOC-2026-0004', prerequisite: '上游成功或失败分支至少有一条到达，且结果存储可写。', check_question: '最终状态是否已写入 result_store 并通知下游？', evaluation_method: '检查写入返回码与下游回执，缺回执则重发三次。', description: '收口成功与失败两条出口，写入最终状态并通知下游。', flow_reason: '流程终点，用于收口成功与失败两条出口。', remark: '成功与失败分别通知不同下游订阅方。' },
  ]

  return { nodes, edges, documents }
}

/**
 * mock 数据库代表的那个「图对象 + 版本」。
 * 开发时进入编辑页要带的深链就是
 *   /graph?object_id=KG-2026-0001&object_version=v3&nodes=N01&hop=2
 * 真实后端上这两个值由上游页面带过来，这里只是给开发和 E2E 一个确定的取值。
 */
export const DEMO_OBJECT = { objectId: 'KG-2026-0001', objectVersion: 'v3' } as const

export let db: MockDb = seed()

// mock 的全部可变状态都放在这里，由 resetDb 一次性重置。
// 计数器从 100 / 50 起，保证生成的 id 永远不会撞上种子数据里的 N01-N04 / ST01-ST04。
let nodeSeq = 100
let edgeSeq = 100
let statusSeq = 50

export const nextNodeId = () => `N${String(++nodeSeq)}`
export const nextEdgeId = () => `E${String(++edgeSeq)}`
export const nextStatusId = (nodeId: string) => `${nodeId}-ST${String(++statusSeq).padStart(2, '0')}`

export function resetDb(): void {
  db = seed()
  nodeSeq = 100
  edgeSeq = 100
  statusSeq = 50
}

// node_ids 里的位置决定候选序号：第 0 个是候选 1，第 1 个是候选 2。
// 请求最多带 2 个种子（handlers.ts 里挡住），多出来的位置没有对应的 tone。
const CANDIDATE_TONES: Tone[] = ['candidate_1', 'candidate_2']

/**
 * 本次查询里这个节点该标成什么 tone。
 * 依据是它在 seedIds 里的位置，不是节点自身的属性 —— 同一个节点换个候选位就换个颜色。
 */
function toneForSeed(nodeId: string, seedIds: string[]): Tone {
  const index = seedIds.indexOf(nodeId)
  return CANDIDATE_TONES[index] ?? 'default'
}

/** 以 seedIds 为起点，在边集上做无向 BFS 向外扩展 hop 跳 */
export function expandGraph(seedIds: string[], hop: number): GraphQueryResponse {
  const adjacency = new Map<string, Set<string>>()
  const touch = (id: string) => {
    if (!adjacency.has(id)) adjacency.set(id, new Set())
    return adjacency.get(id)!
  }
  for (const edge of db.edges) {
    touch(edge.from_node_id).add(edge.to_node_id)
    touch(edge.to_node_id).add(edge.from_node_id)
  }

  const known = new Set(db.nodes.map(n => n.node_id))
  const visited = new Set(seedIds.filter(id => known.has(id)))
  let frontier = [...visited]

  for (let depth = 0; depth < hop && frontier.length > 0; depth++) {
    const next: string[] = []
    for (const id of frontier) {
      for (const neighbour of adjacency.get(id) ?? []) {
        if (!visited.has(neighbour)) {
          visited.add(neighbour)
          next.push(neighbour)
        }
      }
    }
    frontier = next
  }

  // tone 是「这一次查询」的产物，只出现在响应里，绝不写回 db：
  // 一旦落库，换一组候选再搜时上一轮的绿/蓝会残留在卡片上。
  const nodes = db.nodes
    .filter(n => visited.has(n.node_id))
    .map(n => ({ ...n, tone: toneForSeed(n.node_id, seedIds) }))
  const edges = db.edges.filter(e => visited.has(e.from_node_id) && visited.has(e.to_node_id))
  return { nodes, edges }
}

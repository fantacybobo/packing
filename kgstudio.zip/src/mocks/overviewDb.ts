import type { CategoryNode, KnowledgeObjectSummary } from '@/types/overview'

/**
 * 总览页的 mock 数据。
 *
 * 刻意做成三层且各层深浅不一：
 *   - 「运营」下面直接挂叶子（两层）
 *   - 「风控」下面还有一层（三层）
 *   - 「归档」是一个空 children 的顶层节点 —— 它本身就是叶子
 * 树的渲染必须靠 children 判叶子而不是靠深度，这份数据就是用来钉住这件事的。
 *
 * category_index 故意不按数组顺序给，用来验证前端真的排了序。
 */
export const CATEGORY_TREE: CategoryNode[] = [
  {
    category_id: 'CAT-RISK', category_name: '风控', category_index: 2,
    domain_id: 'DOM-FIN', domain_name: '金融域',
    children: [
      {
        category_id: 'CAT-RISK-RULE', category_name: '规则引擎', category_index: 1,
        domain_id: 'DOM-FIN', domain_name: '金融域',
        children: [
          { category_id: 'CAT-RISK-RULE-AML', category_name: '反洗钱', category_index: 1, domain_id: 'DOM-FIN', domain_name: '金融域' },
          { category_id: 'CAT-RISK-RULE-CREDIT', category_name: '授信', category_index: 2, domain_id: 'DOM-FIN', domain_name: '金融域' },
        ],
      },
      { category_id: 'CAT-RISK-MODEL', category_name: '模型', category_index: 2, domain_id: 'DOM-FIN', domain_name: '金融域' },
    ],
  },
  {
    category_id: 'CAT-OPS', category_name: '运营', category_index: 1,
    domain_id: 'DOM-SUPPLY', domain_name: '供应链域',
    children: [
      { category_id: 'CAT-OPS-FULFILL', category_name: '履约', category_index: 1, domain_id: 'DOM-SUPPLY', domain_name: '供应链域' },
      { category_id: 'CAT-OPS-AFTER', category_name: '售后', category_index: 2, domain_id: 'DOM-SUPPLY', domain_name: '供应链域' },
    ],
  },
  // children 是空数组：顶层节点同样可以是叶子
  {
    category_id: 'CAT-ARCHIVE', category_name: '归档', category_index: 3,
    domain_id: 'DOM-SUPPLY', domain_name: '供应链域', children: [],
  },
]

/**
 * 图谱列表，按「domain_id/category_id」索引。
 *
 * 「履约」这条的 object_id / object_version 与 DEMO_OBJECT 一致，
 * 所以从总览点「编修」能真的打开一张有内容的图。
 */
export const KNOWLEDGE_OBJECTS: Record<string, KnowledgeObjectSummary[]> = {
  'DOM-SUPPLY/CAT-OPS-FULFILL': [
    { object_id: 'KG-2026-0001', object_version: 'v3', knowledge_object_name: '供应链履约图谱', status: '草稿' },
    { object_id: 'KG-2026-0001', object_version: 'v2', knowledge_object_name: '供应链履约图谱', status: '已发布' },
    { object_id: 'KG-2026-0001', object_version: 'v1', knowledge_object_name: '供应链履约图谱', status: '已下线' },
  ],
  'DOM-SUPPLY/CAT-OPS-AFTER': [
    { object_id: 'KG-2026-0007', object_version: 'v1', knowledge_object_name: '售后工单图谱', status: '审核中' },
  ],
  'DOM-FIN/CAT-RISK-RULE-AML': [
    { object_id: 'KG-2026-0002', object_version: 'v2', knowledge_object_name: '反洗钱规则图谱', status: '已发布' },
    { object_id: 'KG-2026-0002', object_version: 'v1', knowledge_object_name: '反洗钱规则图谱', status: '已下线' },
  ],
  'DOM-FIN/CAT-RISK-RULE-CREDIT': [
    { object_id: 'KG-2026-0003', object_version: 'v1', knowledge_object_name: '授信规则图谱', status: '已发布' },
  ],
  'DOM-FIN/CAT-RISK-MODEL': [
    { object_id: 'KG-2026-0004', object_version: 'v5', knowledge_object_name: '风险评分模型图谱', status: '已废弃' },
  ],
  // 「归档」下面一个都没有：列表的空态得有东西能验
  'DOM-SUPPLY/CAT-ARCHIVE': [],
}

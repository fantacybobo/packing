import { describe, it, expect, beforeEach } from 'vitest'
import { DEMO_OBJECT, db, expandGraph, resetDb } from './db'
import type { GraphQueryResponse } from '@/types/graph'

beforeEach(() => resetDb())

/**
 * 给裸 fetch 带上图对象标识。这些用例绕开了 api/client（那里会自动拼），所以要自己带。
 * 去处按动词分，和 client 一致：GET 挂查询串，POST 放 payload。
 */
const SCOPE = { object_id: DEMO_OBJECT.objectId, object_version: DEMO_OBJECT.objectVersion }

const scopedUrl = (path: string) => {
  const url = new URL(path, 'http://localhost')
  for (const [key, value] of Object.entries(SCOPE)) url.searchParams.set(key, value)
  return url.toString()
}

const sendJson = (method: string, path: string, body?: object) => {
  const isGet = method.toUpperCase() === 'GET'
  return fetch(isGet ? scopedUrl(path) : new URL(path, 'http://localhost').toString(), {
    method,
    headers: { 'Content-Type': 'application/json' },
    ...(isGet ? {} : { body: JSON.stringify({ ...body, ...SCOPE }) }),
  })
}

describe('expandGraph', () => {
  it('hop 为 0 时只返回种子节点本身', () => {
    const { nodes } = expandGraph(['N01'], 0)
    expect(nodes.map(n => n.node_id)).toEqual(['N01'])
  })

  it('hop 为 1 时带出直接相邻的节点', () => {
    const { nodes } = expandGraph(['N01'], 1)
    expect(nodes.map(n => n.node_id).sort()).toEqual(['N01', 'N02'])
  })

  it('hop 越大命中的节点越多，且具有单调性', () => {
    const one = expandGraph(['N01'], 1).nodes.length
    const two = expandGraph(['N01'], 2).nodes.length
    const three = expandGraph(['N01'], 3).nodes.length
    expect(two).toBeGreaterThan(one)
    expect(three).toBeGreaterThanOrEqual(two)
  })

  it('反向也算一跳：从末端节点出发能回溯到上游', () => {
    const { nodes } = expandGraph(['N04'], 1)
    expect(nodes.map(n => n.node_id)).toContain('N02')
  })

  it('只返回两端都在结果集中的边', () => {
    const { nodes, edges } = expandGraph(['N01'], 1)
    const ids = new Set(nodes.map(n => n.node_id))
    for (const e of edges) {
      expect(ids.has(e.from_node_id)).toBe(true)
      expect(ids.has(e.to_node_id)).toBe(true)
    }
  })

  it('种子 id 不存在时返回空结果而不抛错', () => {
    expect(expandGraph(['NOT_EXIST'], 2)).toEqual({ nodes: [], edges: [] })
  })

  it('两个种子的结果是各自扩展的并集', () => {
    const merged = expandGraph(['N01', 'N04'], 1).nodes.map(n => n.node_id).sort()
    expect(merged).toContain('N01')
    expect(merged).toContain('N04')
    expect(merged).toContain('N02')
  })
})

describe('POST /api/graph/query 边界校验', () => {
  // MSW server 的 listen/resetHandlers/close 由 src/test/setup.ts 全局统一管理，此处不再重复。
  const postQuery = (body: object) => sendJson('POST', '/api/graph/query', body)

  it('node_ids 超过 2 个时返回 400', async () => {
    const res = await postQuery({ node_ids: ['N01', 'N02', 'N03'], hop: 1 })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ success: false })
  })

  it('hop 超出 1-6 范围时返回 400', async () => {
    const res = await postQuery({ node_ids: ['N01'], hop: 999 })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ success: false })
  })

  // tone 由服务端标注，前端只负责上色。这里同时是给后端的契约说明：
  // 标记依据是 node_ids 里的位置，不是节点自身属性 —— 同一个节点换个位置搜就换个颜色。
  it('node_ids 里第一个是 candidate_1、第二个是 candidate_2，其余为 default', async () => {
    const res = await postQuery({ node_ids: ['N01', 'N04'], hop: 3 })
    const { data } = (await res.json()) as { data: GraphQueryResponse }
    const toneOf = (id: string) => data.nodes.find(n => n.node_id === id)?.tone

    expect(toneOf('N01')).toBe('candidate_1')
    expect(toneOf('N04')).toBe('candidate_2')
    expect(toneOf('N02')).toBe('default')
    expect(toneOf('N03')).toBe('default')
  })

  it('只给一个候选时，没有任何节点被标成 candidate_2', async () => {
    const res = await postQuery({ node_ids: ['N04'], hop: 3 })
    const { data } = (await res.json()) as { data: GraphQueryResponse }

    expect(data.nodes.find(n => n.node_id === 'N04')?.tone).toBe('candidate_1')
    expect(data.nodes.map(n => n.tone)).not.toContain('candidate_2')
  })

  // tone 是查询的产物，不是节点的持久属性。写回库里会让下一次换候选搜索时
  // 上一轮的绿/蓝残留在卡片上。
  it('标记不写回库，换一组候选重搜时旧颜色不残留', async () => {
    await postQuery({ node_ids: ['N01'], hop: 3 })
    expect(db.nodes.find(n => n.node_id === 'N01')?.tone).toBe('default')

    const res = await postQuery({ node_ids: ['N02'], hop: 3 })
    const { data } = (await res.json()) as { data: GraphQueryResponse }
    expect(data.nodes.find(n => n.node_id === 'N01')?.tone).toBe('default')
    expect(data.nodes.find(n => n.node_id === 'N02')?.tone).toBe('candidate_1')
  })

  it('合法请求仍然成功', async () => {
    const res = await postQuery({ node_ids: ['N01'], hop: 1 })
    expect(res.status).toBe(200)
    await expect(res.json()).resolves.toMatchObject({ success: true })
  })
})

describe('POST /api/nodes/:node_id 的级联删边', () => {
  // 这是后端契约，必须独立于 store 钉住：mock handler 就是后端作者的实现说明书。
  // 服务端不级联的话，库里会留下引用已不存在 status_id 的孤儿边 ——
  // 两端节点都还在，所以每次查询都会把它再发回前端，而前端画布永远画不出它。
  const putNode = (nodeId: string, body: object) =>
    sendJson('POST', `/api/nodes/${nodeId}`, body)

  const queryEdges = async (nodeIds: string[], hop: number) => {
    const res = await sendJson('POST', '/api/graph/query', { node_ids: nodeIds, hop })
    const envelope = (await res.json()) as { data: GraphQueryResponse }
    return envelope.data.edges
  }

  it('状态行被删掉时，引用该状态的边一并从库里删除', async () => {
    expect(db.edges.some(e => e.from_status_id === 'N01-ST01')).toBe(true)

    const res = await putNode('N01', {
      entity: 'TASK PROCESSOR', metrics: '从队列拉取待处理任务。', tone: 'default',
      status_list: [
        { status_id: 'N01-ST02', status_description: 'Running' },
        { status_id: 'N01-ST03', status_description: 'Active' },
      ],
    })
    expect(res.status).toBe(200)

    expect(db.edges.some(e => e.from_status_id === 'N01-ST01')).toBe(false)
    // 其余状态上的边不受影响
    expect(db.edges.map(e => e.edge_id)).toEqual(expect.arrayContaining(['E002', 'E003']))

    // 再查一次：孤儿边不能因为两端节点都还在，就被重新发回给前端
    const edges = await queryEdges(['N01'], 1)
    expect(edges.some(e => e.from_status_id === 'N01-ST01')).toBe(false)
  })

  it('to 侧引用被删状态的边同样级联', async () => {
    // E001 的 to 侧、E004 的 from 侧都是 N02-ST01
    const res = await putNode('N02', {
      entity: 'DECISION GATE', metrics: '按重试次数与超时阈值分流。', tone: 'default',
      status_list: [
        { status_id: 'N02-ST02', status_description: 'Active' },
        { status_id: 'N02-ST03', status_description: 'Failed' },
        { status_id: 'N02-ST04', status_description: 'Inactive' },
      ],
    })
    expect(res.status).toBe(200)

    const ids = db.edges.map(e => e.edge_id)
    expect(ids).not.toContain('E001')
    expect(ids).not.toContain('E004')
    expect(ids).toEqual(expect.arrayContaining(['E002', 'E003']))
  })

  it('状态一个没少时，边一条都不该被删', async () => {
    const before = db.edges.map(e => e.edge_id)
    const res = await putNode('N01', {
      entity: 'RENAMED', metrics: '只改名字，状态原样保留。', tone: 'default',
      status_list: [
        { status_id: 'N01-ST01', status_description: 'Pending' },
        { status_id: 'N01-ST02', status_description: 'Running' },
        { status_id: 'N01-ST03', status_description: 'Active' },
      ],
    })
    expect(res.status).toBe(200)
    expect(db.edges.map(e => e.edge_id)).toEqual(before)
  })
})

describe('POST /api/edges 的引用完整性校验', () => {
  // 这是 Item 1 的服务端另一半：写接口不查引用，库里就会出现指向不存在
  // 节点/状态的孤儿边 —— 前端画布永远画不出它，用户也就永远删不掉它。
  const postEdge = (body: object) => sendJson('POST', '/api/edges', body)

  const valid = {
    from_node_id: 'N01', to_node_id: 'N04',
    from_status_id: 'N01-ST01', to_status_id: 'N04-ST01',
    priority: 1, tone: 'default',
  }

  it('四个 id 都对得上时正常建边', async () => {
    const before = db.edges.length
    const res = await postEdge(valid)
    expect(res.status).toBe(200)
    expect(db.edges).toHaveLength(before + 1)
  })

  it('引用不存在的节点时返回 400，且不落库', async () => {
    const before = db.edges.length
    const res = await postEdge({ ...valid, to_node_id: 'N99', to_status_id: 'N99-ST01' })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ success: false, error: '边引用的节点不存在' })
    expect(db.edges).toHaveLength(before)
  })

  it('status_id 不属于声明的节点时返回 400', async () => {
    // N02-ST01 是存在的状态，但它不属于 from_node_id 声明的 N01
    const before = db.edges.length
    const res = await postEdge({ ...valid, from_status_id: 'N02-ST01' })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ error: 'from_status_id 不属于 from_node_id' })
    expect(db.edges).toHaveLength(before)
  })

  it('to_status_id 不属于 to_node_id 时返回 400', async () => {
    const res = await postEdge({ ...valid, to_status_id: 'N03-ST01' })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ error: 'to_status_id 不属于 to_node_id' })
  })

  it('状态连到自己时返回 400', async () => {
    const res = await postEdge({
      ...valid, to_node_id: 'N01', from_status_id: 'N01-ST01', to_status_id: 'N01-ST01',
    })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ error: '不能把一个状态连到它自己' })
  })

  it('四个 id 与已有边完全相同时返回 409', async () => {
    // E001 就是 N01-ST01 → N02-ST01
    const before = db.edges.length
    const res = await postEdge({
      ...valid, to_node_id: 'N02', to_status_id: 'N02-ST01',
    })
    expect(res.status).toBe(409)
    await expect(res.json()).resolves.toMatchObject({ error: '这两个状态之间已经有一条边了' })
    expect(db.edges).toHaveLength(before)
  })

  it('改边时不会把边自己算成重复', async () => {
    const res = await sendJson('POST', '/api/edges/E001', {
      from_node_id: 'N01', to_node_id: 'N02',
      from_status_id: 'N01-ST01', to_status_id: 'N02-ST01',
      priority: 42, tone: 'default',
    })
    expect(res.status).toBe(200)
    expect(db.edges.find(e => e.edge_id === 'E001')?.priority).toBe(42)
  })
})

describe('写接口的必填校验', () => {
  const send = sendJson

  it('POST /api/nodes：entity 为空时 400', async () => {
    const before = db.nodes.length
    const res = await send('POST', '/api/nodes', { entity: '  ', metrics: '有描述', tone: 'default', status_list: [] })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ error: 'entity 不能为空' })
    expect(db.nodes).toHaveLength(before)
  })

  it('POST /api/nodes/:id：metrics 缺失时 400，且节点保持原样', async () => {
    const res = await send('POST', '/api/nodes/N01', { entity: 'TASK PROCESSOR', tone: 'default', status_list: [] })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ error: 'metrics 不能为空' })
    expect(db.nodes.find(n => n.node_id === 'N01')?.status_list).toHaveLength(3)
  })

  it('POST /api/documents/:id：少传字段时 400，文档不被改写', async () => {
    const res = await send('POST', '/api/documents/DOC-2026-0001', {
      document_id: 'DOC-2026-0001', description: '只传了一部分',
    })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({ success: false })
    expect(db.documents.find(d => d.document_id === 'DOC-2026-0001')?.description)
      .toBe('从队列拉取待处理任务，按批次执行并产出结构化结果。')
  })

  it('POST /api/documents/:id：7 个字段齐全时正常保存', async () => {
    const current = db.documents.find(d => d.document_id === 'DOC-2026-0001')!
    const res = await send('POST', '/api/documents/DOC-2026-0001', { ...current, remark: '' })
    expect(res.status).toBe(200)
    // 空串是合法值：备注可以被清空，只是字段不能缺席
    expect(db.documents.find(d => d.document_id === 'DOC-2026-0001')?.remark).toBe('')
  })
})


describe('图对象标识（object_id / object_version）', () => {
  // 这是给后端的契约：编辑页的每个接口都在「某个对象的某个版本」下工作。
  // 后端若宽容地按默认版本回一份数据，界面看起来完全正常，用户却在改另一个版本 ——
  // 所以缺失必须是硬错误，而且要在开发期就炸。
  const unscoped = (method: string, path: string, body?: object) =>
    fetch(`http://localhost${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    })

  it('读接口缺少标识时返回 400', async () => {
    const res = await unscoped('GET', '/api/nodes/search?q=TASK')
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({
      success: false,
      error: expect.stringContaining('object_id'),
    })
  })

  it('写接口缺少标识时返回 400，且不落库', async () => {
    const before = db.nodes.length
    const res = await unscoped('POST', '/api/nodes', {
      entity: 'NEW', metrics: '描述', tone: 'default', status_list: [],
    })
    expect(res.status).toBe(400)
    expect(db.nodes).toHaveLength(before)
  })

  it('POST 只在 payload 里带一半标识时同样返回 400', async () => {
    const res = await unscoped('POST', '/api/graph/query', {
      node_ids: ['N01'], hop: 1, object_id: 'KG-2026-0001',
    })
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({
      error: expect.stringContaining('object_version'),
    })
  })

  // 后端约定的是「POST 放 payload」。把标识塞在 URL 上而 body 里没有，
  // 必须被当成没带 —— 否则两种写法并存，后端要同时支持两条取值路径。
  it('POST 把标识放在查询串上不算数', async () => {
    const res = await fetch(
      'http://localhost/api/graph/query?object_id=KG-2026-0001&object_version=v3',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ node_ids: ['N01'], hop: 1 }),
      },
    )
    expect(res.status).toBe(400)
    await expect(res.json()).resolves.toMatchObject({
      error: expect.stringContaining('object_id'),
    })
  })

  // 【后端契约】标识是定址信息，不是实体字段。原样落库的话，节点 / 边 / 文档上会多出
  // 两个谁也没声明过的键，下次读出来又原样发回前端 —— 字段就这样凭空长进了数据模型。
  it('标识不会被当成业务字段存进库里', async () => {
    await sendJson('POST', '/api/nodes', {
      entity: 'SCOPE TEST', metrics: '描述', tone: 'default',
      status_list: [{ status_description: 'Pending' }],
    })
    const created = db.nodes.find(n => n.entity === 'SCOPE TEST')!
    expect(created).not.toHaveProperty('object_id')
    expect(created).not.toHaveProperty('object_version')

    const current = db.documents.find(d => d.document_id === 'DOC-2026-0001')!
    await sendJson('POST', '/api/documents/DOC-2026-0001', { ...current, remark: '改过' })
    const saved = db.documents.find(d => d.document_id === 'DOC-2026-0001')!
    expect(Object.keys(saved).sort()).toEqual([
      'check_question', 'description', 'document_id', 'evaluation_method',
      'flow_reason', 'prerequisite', 'remark',
    ])
  })

  it('两个都带上时照常工作', async () => {
    const res = await sendJson('POST', '/api/graph/query', { node_ids: ['N01'], hop: 1 })
    expect(res.status).toBe(200)
  })
})

/**
 * 节点在「本次查询」里扮演的角色，由服务端按 node_ids 的位置标注，不是节点的持久属性。
 * 取语义名而不是颜色名：配色属于前端主题（见 theme.ts 的 TONE_COLORS），
 * 将来换配色不该动后端契约。
 */
export type Tone = 'default' | 'candidate_1' | 'candidate_2'

export interface NodeStatus {
  status_id: string
  node_id: string
  status_description: string
}

export interface GraphNode {
  node_id: string
  entity: string
  metrics: string
  tone: Tone
  document_id: string[]
  status_list: NodeStatus[]
}

export interface GraphEdge {
  edge_id: string
  from_node_id: string
  to_node_id: string
  from_status_id: string
  to_status_id: string
  priority: number
  tone: Tone
}

export interface NodeDocument {
  document_id: string
  prerequisite: string
  check_question: string
  evaluation_method: string
  description: string
  flow_reason: string
  remark: string
}

/** 新建状态时没有 status_id，由后端生成 */
export interface NodeStatusDraft {
  status_id?: string
  status_description: string
}

export interface NodePayload {
  entity: string
  metrics: string
  tone: Tone
  status_list: NodeStatusDraft[]
}

export interface EdgePayload {
  from_node_id: string
  to_node_id: string
  from_status_id: string
  to_status_id: string
  priority: number
  tone: Tone
}

export interface GraphQueryRequest {
  node_ids: string[]
  hop: number
}

export interface GraphQueryResponse {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

export interface ApiEnvelope<T> {
  success: boolean
  data: T | null
  error: string | null
}

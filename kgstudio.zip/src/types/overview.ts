/**
 * 总览页的后端契约。
 *
 * 这一组接口**不属于**「某个图对象的某个版本」那个作用域（见 api/objectContext.ts）——
 * 分类树和图谱列表是跨对象的，所以它们走 api/client.ts 的 getUnscopedJson。
 */

/**
 * 分类树的一个节点。
 *
 * 界面上只展示 category_name；其余字段是点中叶子后查图谱列表要传的参数。
 * children 为空或缺席就是叶子 —— 这是「能不能点出列表」的唯一判据，
 * 不要改成看层级深度（后端随时可能多插一层）。
 */
export interface CategoryNode {
  category_id: string
  category_name: string
  domain_id: string
  domain_name: string
  /** 同级之间的排序权重，小的在前 */
  category_index: number
  children?: CategoryNode[]
}

/** 图谱列表里的一行。列表按 category_id + domain_id 查，一行就是一个知识对象的一个版本 */
export interface KnowledgeObjectSummary {
  object_id: string
  object_version: string
  knowledge_object_name: string
  /**
   * 状态。值域后端还没给，所以前端只把它原样显示出来，不做任何按值分支或配色 ——
   * 猜一套枚举写死在这里，等真值下来就会静默地全部落到「其它」分支上。
   */
  status: string
}

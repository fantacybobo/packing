import { theme, type ThemeConfig } from 'antd'
import type { Tone } from '@/types/graph'

export interface Highlight {
  /** 卡片边框，选中时还兼作外发光的颜色 */
  border: string
  /** 卡片标题的文字色 */
  title: string
}

// 候选色与搜索栏两个候选框的圆点同源：候选 1 = --accent-start（绿），候选 2 = --accent-end（蓝）。
// 用户在搜索栏看到什么色，画布上就该高亮什么色。
//
// 边框与标题同色，是为了让「这张卡片属于哪个候选」只有一个视觉信号而不是两个：
// 只染边框、标题保持白色的话，选中时标题突然变黄就成了一条没有对应关系的孤立规则。
export const TONE_COLORS: Record<Tone, Highlight> = {
  // 非候选节点不参与配色：中性边框 + 常规强调文字色
  default: { border: '#233442', title: 'var(--color-text-strong)' },
  candidate_1: { border: '#4ade80', title: '#4ade80' },
  candidate_2: { border: '#60a5fa', title: '#60a5fa' },
}

/**
 * 选中态的黄色，优先级高于 tone。
 * 不在 tokens.css 里留一份副本：选中色是经 StatusNode 注入 --node-highlight 下去的，
 * CSS 侧没有任何地方需要直接引用它，多存一份只会变成没人消费的死 token。
 */
export const SELECTED_COLOR = '#fbbf24'

/**
 * 连线与箭头的颜色。箭头是 React Flow 生成到 <defs> 里的 SVG marker，
 * 取不到 CSS class 上的 stroke，只能由 JS 把色值传进去；
 * 和 tokens.css 的 --color-edge 因此天然是两份副本；e2e/smoke.spec.ts 里
 * 「箭头与连线同色」那条用例负责让两份不会各自漂移 —— 它比对的是浏览器算出的
 * 实际颜色，不是源文件里的字面量。
 */
export const EDGE_COLOR = '#51687e'

/**
 * 节点卡片该用哪种高亮色。选中优先于 tone —— 选中是用户此刻的操作焦点，
 * 而 tone 只是这一次查询的来源标记，前者盖住后者。
 *
 * tone 来自服务端，是不可信输入：类型之外的值一律退回 default，
 * 不能让 undefined 流进 style 里（那会直接抹掉边框色）。
 */
export function nodeHighlight(tone: Tone, selected: boolean): Highlight {
  if (selected) return { border: SELECTED_COLOR, title: SELECTED_COLOR }
  return TONE_COLORS[tone] ?? TONE_COLORS.default
}

export const antdTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorBgBase: '#070c12',
    colorBgContainer: '#0d151d',
    colorBgElevated: '#0b131b',
    colorBorder: '#23323f',
    colorBorderSecondary: '#1d2b38',
    colorText: '#c9d6e3',
    colorTextHeading: '#e9f1f8',
    colorPrimary: '#3d7fa8',
    colorError: '#dc2626',
    borderRadius: 6,
    fontSize: 13,
    // 指回 tokens.css，避免字体栈在 CSS 和 antd 主题里各维护一份
    fontFamily: 'var(--font-sans)',
    fontFamilyCode: 'var(--font-mono)',
  },
}

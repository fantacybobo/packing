import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { AppShell } from './components/app-shell/AppShell'
import { GRAPH_PATH, OVERVIEW_PATH } from './components/app-shell/navigation'
import { OverviewPage } from './pages/OverviewPage'
import { GraphPage } from './pages/GraphPage'
import { NotFoundPage } from './pages/NotFoundPage'

/**
 * 根路径的落点。
 *
 * 裸 `/`（没有查询串）去总览页 —— 那是应用的入口，用户是来挑图谱的。
 *
 * 但带查询串的 `/` 必须仍然去图谱页，并**原样保留那串查询**：
 * 查询状态的唯一真源是 URL（见 useGraphQuery），历史遗留的深链和书签全是
 * `/?object_id=..&object_version=..&nodes=..&hop=..` 这个形状。
 * 一律送去总览的话，这些链接会在当事人毫无察觉的情况下全部失效 ——
 * 页面正常打开，只是打开的是另一个地方，而他要的那张图再也回不去了。
 *
 * 判据取「有没有查询串」而不是「查询串里有没有 object_id」：前者简单且覆盖了
 * 所有已知的深链形状。代价是 `/?from=email` 这种无关参数也会被送去图谱页，
 * 内部工具里这种链接不会出现，真出现了再把判据收紧到具体参数名。
 */
function RootRedirect() {
  const { search } = useLocation()
  return <Navigate to={search ? `${GRAPH_PATH}${search}` : OVERVIEW_PATH} replace />
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route element={<AppShell />}>
        <Route path={OVERVIEW_PATH} element={<OverviewPage />} />
        <Route path={GRAPH_PATH} element={<GraphPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  )
}

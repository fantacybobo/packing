import { describe, it, expect, vi } from 'vitest'
import { renderHook, act, waitFor } from '@testing-library/react'
import { useRequest } from './useRequest'
import { ApiError } from '@/api/client'

/** 手动控制何时兑现的 promise，用来摆出「先发的后回来」这种顺序 */
function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (reason: unknown) => void
  const promise = new Promise<T>((res, rej) => { resolve = res; reject = rej })
  return { promise, resolve, reject }
}

describe('useRequest', () => {
  it('key 为 null 时停在 idle，不发请求', () => {
    const run = vi.fn()
    const { result } = renderHook(() => useRequest(null, run))

    expect(result.current.status).toBe('idle')
    expect(run).not.toHaveBeenCalled()
  })

  it('key 有值时取一次，成功后进 ready', async () => {
    const { result } = renderHook(() => useRequest('a', () => Promise.resolve([1, 2])))

    expect(result.current.status).toBe('loading')
    await waitFor(() => expect(result.current.status).toBe('ready'))
    expect(result.current.data).toEqual([1, 2])
  })

  it('失败时把后端文案原样交出来', async () => {
    const { result } = renderHook(() =>
      useRequest('a', () => Promise.reject(new ApiError('分类不存在', 404))),
    )

    await waitFor(() => expect(result.current.status).toBe('error'))
    expect(result.current.error).toBe('分类不存在')
  })

  it('key 变了就重新取，并且用的是新闭包', async () => {
    const run = vi.fn((key: string) => Promise.resolve(key))
    const { result, rerender } = renderHook(
      ({ key }) => useRequest(key, () => run(key)),
      { initialProps: { key: 'a' } },
    )
    await waitFor(() => expect(result.current.data).toBe('a'))

    rerender({ key: 'b' })
    await waitFor(() => expect(result.current.data).toBe('b'))
    expect(run).toHaveBeenCalledTimes(2)
  })

  // 这条是这个 hook 存在的主要理由。连着点两个分类时，先发的请求完全可能后回来；
  // 不认 token 的话，晚到的旧响应会盖掉新分类的列表 —— 没有报错、没有闪烁，就是内容不对。
  it('先发的请求后回来时，不会盖掉新 key 的结果', async () => {
    const first = deferred<string>()
    const second = deferred<string>()
    const byKey: Record<string, Promise<string>> = { a: first.promise, b: second.promise }

    const { result, rerender } = renderHook(
      ({ key }) => useRequest(key, () => byKey[key]),
      { initialProps: { key: 'a' } },
    )

    rerender({ key: 'b' })
    // 后发的先回
    await act(async () => { second.resolve('b 的结果'); await second.promise })
    expect(result.current.data).toBe('b 的结果')

    // 先发的现在才回来，它必须被丢掉
    await act(async () => { first.resolve('a 的结果'); await first.promise })
    expect(result.current.data).toBe('b 的结果')
    expect(result.current.status).toBe('ready')
  })

  it('迟到的失败同样不会打断新 key 的结果', async () => {
    const first = deferred<string>()
    const second = deferred<string>()
    const byKey: Record<string, Promise<string>> = { a: first.promise, b: second.promise }

    const { result, rerender } = renderHook(
      ({ key }) => useRequest(key, () => byKey[key]),
      { initialProps: { key: 'a' } },
    )
    rerender({ key: 'b' })

    await act(async () => { second.resolve('b 的结果'); await second.promise })
    await act(async () => {
      first.reject(new ApiError('a 超时', 504))
      await first.promise.catch(() => {})
    })

    expect(result.current.status).toBe('ready')
    expect(result.current.error).toBeNull()
  })

  it('retry 会重新取一次同一个 key', async () => {
    const run = vi.fn().mockRejectedValueOnce(new ApiError('挂了', 500)).mockResolvedValueOnce('好了')
    const { result } = renderHook(() => useRequest('a', run))

    await waitFor(() => expect(result.current.status).toBe('error'))
    act(() => result.current.retry())
    await waitFor(() => expect(result.current.status).toBe('ready'))
    expect(result.current.data).toBe('好了')
  })
})

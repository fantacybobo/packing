import { describe, it, expect } from 'vitest'
import {
  HOP_DEFAULT, HOP_MAX, HOP_MIN,
  clampHop, parseNodeIds, parseObjectRef, sanitizeNodeIds, serializeNodeIds,
} from './queryParams'

describe('clampHop', () => {
  it('合法整数原样返回', () => {
    expect(clampHop(3)).toBe(3)
  })

  it('小于下界时收敛到下界', () => {
    expect(clampHop(0)).toBe(HOP_MIN)
    expect(clampHop(-5)).toBe(HOP_MIN)
  })

  it('大于上界时收敛到上界', () => {
    expect(clampHop(99)).toBe(HOP_MAX)
  })

  it('小数向下取整', () => {
    expect(clampHop(2.9)).toBe(2)
  })

  it('非数字回落到默认值', () => {
    expect(clampHop(null)).toBe(HOP_DEFAULT)
    expect(clampHop(undefined)).toBe(HOP_DEFAULT)
    expect(clampHop('abc')).toBe(HOP_DEFAULT)
    expect(clampHop(NaN)).toBe(HOP_DEFAULT)
  })

  it('数字字符串可以接受', () => {
    expect(clampHop('4')).toBe(4)
  })
})

describe('parseNodeIds', () => {
  it('逗号分隔解析成数组', () => {
    expect(parseNodeIds('N01,N04')).toEqual(['N01', 'N04'])
  })

  it('去掉空白与空项', () => {
    expect(parseNodeIds(' N01 , , N04 ')).toEqual(['N01', 'N04'])
  })

  it('超过两个时只取前两个', () => {
    expect(parseNodeIds('N01,N02,N03,N04')).toEqual(['N01', 'N02'])
  })

  it('去重，避免把同一个节点传两次', () => {
    expect(parseNodeIds('N01,N01')).toEqual(['N01'])
  })

  it('空值返回空数组', () => {
    expect(parseNodeIds(null)).toEqual([])
    expect(parseNodeIds('')).toEqual([])
    expect(parseNodeIds(' , ')).toEqual([])
  })
})

describe('sanitizeNodeIds', () => {
  it('去重后再截断，两条规则叠加时结果正确', () => {
    expect(sanitizeNodeIds(['N01', 'N01', 'N02', 'N03'])).toEqual(['N01', 'N02'])
  })

  it('与 parseNodeIds 使用同一套规则，读写两端不会漂移', () => {
    expect(sanitizeNodeIds([' N01 ', '', 'N04'])).toEqual(parseNodeIds(' N01 , , N04 '))
  })
})

describe('serializeNodeIds', () => {
  it('用逗号拼接', () => {
    expect(serializeNodeIds(['N01', 'N04'])).toBe('N01,N04')
  })

  it('空数组序列化成空串，作为「没有选任何候选」的查询键', () => {
    expect(serializeNodeIds([])).toBe('')
  })
})

describe('parseObjectRef', () => {
  const parse = (search: string) => parseObjectRef(new URLSearchParams(search))

  it('两个字段齐全时解析出标识', () => {
    expect(parse('?object_id=OBJ-7&object_version=v9'))
      .toEqual({ objectId: 'OBJ-7', objectVersion: 'v9' })
  })

  it('去掉首尾空白', () => {
    expect(parse('?object_id=%20OBJ-7%20&object_version=%20v9%20'))
      .toEqual({ objectId: 'OBJ-7', objectVersion: 'v9' })
  })

  // 半截标识没有意义：与其带着一半去请求（后端只能猜另一半），不如当成没有，
  // 让 objectContext 吼出来。
  it('只有一个字段时视为没有标识', () => {
    expect(parse('?object_id=OBJ-7')).toBeNull()
    expect(parse('?object_version=v9')).toBeNull()
    expect(parse('?object_id=OBJ-7&object_version=')).toBeNull()
    expect(parse('?object_id=%20%20&object_version=v9')).toBeNull()
  })

  it('两个都没有时返回 null', () => {
    expect(parse('?nodes=N01&hop=2')).toBeNull()
  })
})

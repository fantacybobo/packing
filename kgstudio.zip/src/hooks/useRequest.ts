import { useCallback, useEffect, useRef, useState } from 'react'
import { errorMessage } from '@/lib/errors'

export type RequestStatus = 'idle' | 'loading' | 'ready' | 'error'

export interface RequestState<T> {
  status: RequestStatus
  data: T | null
  error: string | null
  /** 重新取一次。失败后给用户的那个「重试」按钮用 */
  retry: () => void
}

/**
 * 「key 变了就重新取一次」的最小封装。
 *
 * key 为 null 表示现在没有可取的东西（总览页还没选分类就是这个状态）：停在 idle，
 * 不发请求也不显示加载中 —— 空态和加载中是两回事，混成一个用户会一直等一个不会来的结果。
 *
 * 那个 token 是关键：连着点两个分类时，先发的请求完全可能后回来。
 * 不认它的话，晚到的旧响应会盖掉新分类的列表，而界面上一点异常都看不出来
 * （没有报错、没有闪烁，就是内容不对）。
 */
export function useRequest<T>(key: string | null, run: () => Promise<T>): RequestState<T> {
  const [state, setState] = useState<Omit<RequestState<T>, 'retry'>>({
    status: 'idle', data: null, error: null,
  })
  const [attempt, setAttempt] = useState(0)

  // run 每次渲染都是新闭包，放进依赖会让 effect 每次都重跑。
  // 这个 effect 必须声明在取数 effect **之前**：同一组件里 effect 按声明顺序执行，
  // 这样取数时 ref 里一定已经是本次渲染的闭包，而不是上一次的。
  const runRef = useRef(run)
  useEffect(() => { runRef.current = run })

  const token = useRef(0)

  useEffect(() => {
    if (key === null) {
      setState({ status: 'idle', data: null, error: null })
      return
    }
    const mine = ++token.current
    setState({ status: 'loading', data: null, error: null })

    runRef.current().then(
      data => { if (token.current === mine) setState({ status: 'ready', data, error: null }) },
      e => { if (token.current === mine) setState({ status: 'error', data: null, error: errorMessage(e) }) },
    )
  }, [key, attempt])

  const retry = useCallback(() => setAttempt(n => n + 1), [])

  return { ...state, retry }
}

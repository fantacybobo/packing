import { useCallback, useEffect, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  getGraphObjectRef, isSameObjectRef, setGraphObjectRef, type GraphObjectRef,
} from '@/api/objectContext'
import { useGraphStore } from '@/store/useGraphStore'
import { clampHop, parseNodeIds, parseObjectRef, sanitizeNodeIds, serializeNodeIds } from './queryParams'

/**
 * URL 是单向的：URL → 页面。
 *
 * 进入编辑页时 URL 带着 object_id / object_version / nodes / hop 进来，页面据此加载；
 * 之后在页面里点「搜索」只会重新拉数据，**不会**把新参数写回 URL。
 * 于是刷新、前进后退、粘贴链接永远回到「进来时那一份」参数，
 * 而不是一个被页面操作改写过、说不清来历的中间状态。
 *
 * 这个 hook 只读参数、无任何副作用，可以被多个组件同时调用。
 */
export function useGraphQueryParams() {
  const [searchParams] = useSearchParams()
  return {
    nodeIds: parseNodeIds(searchParams.get('nodes')),
    hop: clampHop(searchParams.get('hop')),
    objectRef: parseObjectRef(searchParams),
  }
}

/**
 * 把 URL 上的图对象标识同步进 api/objectContext，让之后每个请求都带上它。
 * 全应用只需要一个宿主，当前是 GraphPage。
 *
 * 同步动作放在渲染期而不是 useEffect 里：React 的 effect 是子先父后，
 * 而真正发请求的 effect 住在子组件 SearchBar 里 —— 放进父组件的 effect，
 * 首次加载那一发请求会赶在同步之前出去，正好漏掉标识。
 * 这个写法是幂等的（值没变就不写），StrictMode 下重复渲染也没有副作用。
 */
export function useGraphObjectRefSync(): GraphObjectRef | null {
  const { objectRef } = useGraphQueryParams()
  if (!isSameObjectRef(getGraphObjectRef(), objectRef)) setGraphObjectRef(objectRef)
  return objectRef
}

/**
 * 独占「URL 变化 → 发起查询」这个副作用，并对外提供「点搜索 → 直接发起查询」。
 * 全应用只能调用一次，否则每次 URL 变化会重复发请求。当前唯一调用方是 SearchBar。
 */
export function useGraphQuerySync() {
  const { nodeIds, hop } = useGraphQueryParams()
  const searchGraph = useGraphStore(s => s.searchGraph)
  const reset = useGraphStore(s => s.reset)

  // nodeIds 每次渲染都是新数组，所以依赖用序列化后的字符串，避免 effect 反复触发
  const queryKey = `${serializeNodeIds(nodeIds)}|${hop}`
  const lastKey = useRef<string | null>(null)

  useEffect(() => {
    if (lastKey.current === queryKey) return
    lastKey.current = queryKey
    const [rawIds, rawHop] = queryKey.split('|')
    const ids = parseNodeIds(rawIds)
    if (ids.length === 0) {
      reset()
      return
    }
    void searchGraph(ids, Number(rawHop))
  }, [queryKey, searchGraph, reset])

  /**
   * 点「搜索」：直接发请求，不碰 URL。
   *
   * 也因此不需要「失败后放开守卫」那类补丁 —— 上面的 lastKey 只管 URL 驱动的那条路径，
   * 用户原样再点一次搜索，这里每次都会真的发出去。
   */
  const runQuery = useCallback(
    (ids: string[], nextHop: number) => {
      void searchGraph(sanitizeNodeIds(ids), clampHop(nextHop))
    },
    [searchGraph],
  )

  return { nodeIds, hop, runQuery }
}

import { describe, it, expect, afterEach, beforeEach, vi } from 'vitest'
import type { ReactNode } from 'react'
import { act, renderHook, waitFor } from '@testing-library/react'
import { MemoryRouter, useLocation } from 'react-router-dom'
import { getGraphObjectRef, setGraphObjectRef } from '@/api/objectContext'
import { useGraphStore } from '@/store/useGraphStore'
import { useGraphObjectRefSync, useGraphQuerySync } from './useGraphQuery'

const makeWrapper = (entry: string) =>
  function Wrapper({ children }: { children: ReactNode }) {
    return <MemoryRouter initialEntries={[entry]}>{children}</MemoryRouter>
  }

const wrapper = makeWrapper('/graph?nodes=N01&hop=1')

// reset() 只还原 state 字段，不还原被换掉的 action ——
// 少了这个 afterEach，下一个用例会继承上一个用例装进 store 的 searchGraph mock。
const realSearchGraph = useGraphStore.getState().searchGraph

const stubSearchGraph = () => {
  const searchGraph = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(async () => {})
  useGraphStore.setState({ searchGraph })
  return searchGraph
}

describe('useGraphQuerySync', () => {
  beforeEach(() => {
    useGraphStore.getState().reset()
  })

  afterEach(() => {
    useGraphStore.setState({ searchGraph: realSearchGraph })
  })

  it('挂载时按 URL 里的查询发起一次请求，URL 没变就不会重复发', () => {
    const searchGraph = stubSearchGraph()

    const { rerender } = renderHook(() => useGraphQuerySync(), { wrapper })

    expect(searchGraph).toHaveBeenCalledTimes(1)
    expect(searchGraph).toHaveBeenCalledWith(['N01'], 1)

    // 再渲染两次，URL 没变——nodeIds 每次都是新数组，但不应该重复发请求
    rerender()
    rerender()
    expect(searchGraph).toHaveBeenCalledTimes(1)
  })

  // queryKey 没变，但 searchGraph 的引用变了（例如 store 被替换/热更新）时，
  // lastKey ref 是唯一挡住重复请求的东西——effect 的依赖数组本身会因为
  // searchGraph 引用变化而判定为「变了」，从而重新执行 effect 函数体。
  it('查询没变时，即使 store 里的 searchGraph 引用发生变化，也不会重复发起同一次查询', () => {
    const searchGraph1 = stubSearchGraph()

    renderHook(() => useGraphQuerySync(), { wrapper })
    expect(searchGraph1).toHaveBeenCalledTimes(1)

    const searchGraph2 = vi.fn<(nodeIds: string[], hop: number) => Promise<void>>(async () => {})
    act(() => {
      useGraphStore.setState({ searchGraph: searchGraph2 })
    })

    expect(searchGraph2).not.toHaveBeenCalled()
    expect(searchGraph1).toHaveBeenCalledTimes(1)
  })

  it('URL 里没有 nodes 时不发请求，只清空画布', () => {
    const searchGraph = stubSearchGraph()
    useGraphStore.setState({ nodes: [{ node_id: 'N01' }] as never })

    renderHook(() => useGraphQuerySync(), { wrapper: makeWrapper('/graph') })

    expect(searchGraph).not.toHaveBeenCalled()
    expect(useGraphStore.getState().nodes).toHaveLength(0)
  })

  it('URL 里的 hop 越界时按上界查询，且不把清洗后的值写回 URL', async () => {
    const searchGraph = stubSearchGraph()

    const { result } = renderHook(
      () => ({ sync: useGraphQuerySync(), location: useLocation() }),
      { wrapper: makeWrapper('/graph?nodes=N01&hop=99') },
    )

    expect(searchGraph).toHaveBeenCalledWith(['N01'], 6)
    // 旧实现会把 clamp 后的 hop 原地写回 URL。URL 单向之后它必须原样留着：
    // 页面只读 URL，不修改它。
    await act(async () => {})
    expect(result.current.location.search).toBe('?nodes=N01&hop=99')
  })

  describe('runQuery（点「搜索」）', () => {
    it('直接发起查询，并且一个字都不写回 URL', async () => {
      const searchGraph = stubSearchGraph()

      const { result } = renderHook(
        () => ({ sync: useGraphQuerySync(), location: useLocation() }),
        { wrapper },
      )
      expect(searchGraph).toHaveBeenCalledTimes(1)

      act(() => {
        result.current.sync.runQuery(['N04'], 3)
      })

      expect(searchGraph).toHaveBeenLastCalledWith(['N04'], 3)
      // 这是这次改动的核心保证：URL 是进入页面时那一份，页面操作不会改写它。
      // 断言完整的 search 串而不是「不包含 N04」——后者在 URL 被清空时同样成立。
      await waitFor(() => expect(result.current.location.search).toBe('?nodes=N01&hop=1'))
    })

    it('净化调用方传进来的 ids：去重、截断到两个；hop 越界收敛', () => {
      const searchGraph = stubSearchGraph()
      const { result } = renderHook(() => useGraphQuerySync(), { wrapper })

      act(() => {
        result.current.runQuery(['N01', 'N01', 'N02', 'N03'], 99)
      })

      expect(searchGraph).toHaveBeenLastCalledWith(['N01', 'N02'], 6)
    })

    // 失败后用户什么都不改、原样再点一次「搜索」，是最自然的反应。
    // 请求不再经过 URL，也就不再有「参数没变所以被守卫挡住」这回事。
    it('原样重提同一组参数，每次都会真的再发一次请求', () => {
      const searchGraph = stubSearchGraph()
      const { result } = renderHook(() => useGraphQuerySync(), { wrapper })
      expect(searchGraph).toHaveBeenCalledTimes(1)

      act(() => { result.current.runQuery(['N01'], 1) })
      act(() => { result.current.runQuery(['N01'], 1) })

      expect(searchGraph).toHaveBeenCalledTimes(3)
    })
  })
})

describe('useGraphObjectRefSync', () => {
  beforeEach(() => setGraphObjectRef(null))

  it('把 URL 上的 object_id / object_version 同步给 api 层', () => {
    renderHook(() => useGraphObjectRefSync(), {
      wrapper: makeWrapper('/graph?object_id=OBJ-7&object_version=v9&nodes=N01'),
    })
    expect(getGraphObjectRef()).toEqual({ objectId: 'OBJ-7', objectVersion: 'v9' })
  })

  // 同步必须发生在渲染期：发请求的 effect 住在子组件里，子 effect 先于父 effect 运行，
  // 放进父组件的 useEffect 会让首次加载那一发请求漏掉标识。这里用「渲染函数返回时
  // 模块里已经有值」来钉住它 —— 若改回 effect 实现，renderHook 返回前不会有值。
  it('在渲染期就完成同步，而不是等到 effect', () => {
    let seenDuringRender: unknown
    renderHook(
      () => {
        useGraphObjectRefSync()
        seenDuringRender = getGraphObjectRef()
      },
      { wrapper: makeWrapper('/graph?object_id=OBJ-7&object_version=v9') },
    )
    expect(seenDuringRender).toEqual({ objectId: 'OBJ-7', objectVersion: 'v9' })
  })

  it('两个字段只有一个时视为没有标识，不带半截标识去请求', () => {
    renderHook(() => useGraphObjectRefSync(), {
      wrapper: makeWrapper('/graph?object_id=OBJ-7&nodes=N01'),
    })
    expect(getGraphObjectRef()).toBeNull()
  })
})

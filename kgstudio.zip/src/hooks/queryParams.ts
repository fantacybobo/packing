import { OBJECT_ID_PARAM, OBJECT_VERSION_PARAM, type GraphObjectRef } from '@/api/objectContext'

export const HOP_MIN = 1
export const HOP_MAX = 6
export const HOP_DEFAULT = 2

const MAX_SEEDS = 2

export function clampHop(raw: unknown): number {
  const value = typeof raw === 'string' ? Number(raw) : raw
  if (typeof value !== 'number' || !Number.isFinite(value)) return HOP_DEFAULT
  return Math.min(HOP_MAX, Math.max(HOP_MIN, Math.floor(value)))
}

export function parseNodeIds(raw: string | null): string[] {
  if (!raw) return []
  const cleaned = raw.split(',').map(s => s.trim()).filter(Boolean)
  return [...new Set(cleaned)].slice(0, MAX_SEEDS)
}

export function serializeNodeIds(ids: string[]): string {
  return ids.join(',')
}

/**
 * 净化调用方传进来的 node ids：去空、去重、截断到 2 个。
 * 复用 parseNodeIds 的规则，保证「从 URL 读进来的」和「用户在搜索栏选的」
 * 经过同一套约束，不会各自漂移。
 */
export function sanitizeNodeIds(ids: string[]): string[] {
  return parseNodeIds(ids.join(','))
}

/**
 * 从 URL 解析图对象标识。两个字段缺一不可 —— 只有一半的标识没有意义，
 * 与其带着半截去请求，不如当成没有，由 objectContext 吼一声。
 */
export function parseObjectRef(searchParams: URLSearchParams): GraphObjectRef | null {
  const objectId = (searchParams.get(OBJECT_ID_PARAM) ?? '').trim()
  const objectVersion = (searchParams.get(OBJECT_VERSION_PARAM) ?? '').trim()
  if (!objectId || !objectVersion) return null
  return { objectId, objectVersion }
}

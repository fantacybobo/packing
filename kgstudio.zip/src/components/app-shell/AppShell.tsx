import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { TopBar } from './TopBar'
import { APP_NAME, PAGE_TITLES } from './navigation'
import './app-shell.css'

/**
 * 标签页标题跟着路由走。
 *
 * 多页应用里，读屏用户点了导航除了 DOM 变化没有任何「我现在在哪一页」的信号，
 * 很容易以为点击没生效。标题是最低成本、也最不打扰人的那个信号
 * （把焦点强行移到新页面标题是另一半，那个更容易做得烦人，暂时没做）。
 *
 * 落在这个布局路由下却不在 PAGE_TITLES 里的路径，只可能是 404 —— 其余路径都声明过了。
 */
function usePageTitle() {
  const { pathname } = useLocation()
  const label = PAGE_TITLES[pathname] ?? '页面不存在'

  useEffect(() => {
    document.title = `${label} · ${APP_NAME}`
  }, [label])
}

/**
 * 所有页面共享的外壳：只有顶栏，页面本体由 <Outlet /> 注入。
 *
 * 外壳里没有侧边栏，也没有工具条 —— 它们各自只属于一个页面：
 * 侧边栏（图谱清单树）是总览页的，工具条（搜索栏）是图谱页的。
 * 放进外壳的话，另一页就会继承一条空栏。
 */
export function AppShell() {
  usePageTitle()

  return (
    <div className="app-shell">
      <TopBar />
      <Outlet />
    </div>
  )
}

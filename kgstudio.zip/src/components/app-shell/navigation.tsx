export interface NavItem {
  key: string
  path: string
  label: string
}

/** 产品名。侧边栏品牌区和 document.title 共用，避免两处各写一份 */
export const APP_NAME = 'KG Studio'

/** 总览页。侧边栏上半部分唯一的导航项，也是图谱列表的入口 */
export const OVERVIEW_PATH = '/overview'

/** 图谱编辑页。要跳回主编辑界面用 graphPathFor()，它会带上图对象标识 */
export const GRAPH_PATH = '/graph'

/**
 * 图谱页的深链。
 *
 * 编辑的不是「那张图」，而是某个对象的某个版本 —— 不带 object_id / object_version
 * 进去，所有接口都会被后端拒掉（见 mocks/handlers.ts 的 scopeError）。
 * 侧边栏的树状导航和总览页的列表都从这里取地址，两边不各拼一份查询串。
 */
export function graphPathFor(objectId: string, objectVersion: string): string {
  const query = new URLSearchParams({ object_id: objectId, object_version: objectVersion })
  return `${GRAPH_PATH}?${query.toString()}`
}

/**
 * 路径 → 页面名，document.title 从这里取。
 *
 * 和 NAV_ITEMS 分开：图谱页不在侧边栏的导航区里（它由树状导航和总览列表进入），
 * 但它同样需要一个标题。两者合一的话，「不在侧边栏」就等于「标题是 404」。
 */
export const PAGE_TITLES: Record<string, string> = {
  [OVERVIEW_PATH]: '总览',
  [GRAPH_PATH]: '图谱',
}

/**
 * 顶栏的快捷导航。
 *
 * 图谱编辑页**不在**这里，这是刻意的：从顶栏点进去的地址不带图对象标识，
 * 那样的编辑页搜什么都会被后端拒。进编辑页只有一条路 —— 总览页列表行上的
 * 「编辑」，它用 graphPathFor() 把标识一起带过去。
 *
 * 各版本图谱也不在这里：它们是数据，归总览页左侧的 GraphTree 管。
 *
 * 注意这份清单已经不再是 <Routes> 的全部：/graph 有路由但没有导航项，
 * 路由表在 App.tsx 里逐条声明，页面标题走 PAGE_TITLES。
 */
export const NAV_ITEMS: NavItem[] = [
  { key: 'overview', path: OVERVIEW_PATH, label: '总览' },
]

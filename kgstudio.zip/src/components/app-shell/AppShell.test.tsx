import { describe, it, expect } from 'vitest'
import { screen, within } from '@testing-library/react'
import { Route, Routes } from 'react-router-dom'
import { AppShell } from './AppShell'
import { GRAPH_PATH, NAV_ITEMS } from './navigation'
import { renderWithProviders } from '@/test/renderWithProviders'

/** AppShell 是布局路由，页面本体由 <Outlet /> 注入，所以要挂在一张路由表下渲染 */
const renderShell = (initialPath = '/graph') =>
  renderWithProviders(
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/overview" element={<div data-testid="content" />} />
        <Route path="/graph" element={<div data-testid="content" />} />
      </Route>
    </Routes>,
    { initialPath },
  )

const mainNav = () => screen.getByRole('navigation', { name: '主导航' })

describe('AppShell', () => {
  it('渲染产品名', () => {
    renderShell()
    expect(screen.getByText('KG Studio')).toBeInTheDocument()
  })

  it('使用语义化结构：导航、页头，以及由页面提供的主内容', () => {
    renderShell()
    expect(mainNav()).toBeInTheDocument()
    expect(screen.getByRole('banner')).toBeInTheDocument()
    expect(screen.getByTestId('content')).toBeInTheDocument()
  })

  it('头像的无障碍名真的生效（裸 span 上的 aria-label 会被读屏忽略）', () => {
    renderShell()
    expect(screen.getByRole('img', { name: '当前用户' })).toBeInTheDocument()
  })

  // 侧边栏归总览页自己所有（那里放的是图谱清单树），不是外壳的一部分。
  // 放回外壳的话，图谱页会继承一条与它无关的图谱清单。
  it('外壳里没有侧边栏，导航只在顶栏这一处', () => {
    renderShell()
    expect(screen.queryByRole('navigation', { name: '图谱快速导航' })).not.toBeInTheDocument()
    expect(screen.getAllByRole('navigation')).toHaveLength(1)
  })
})

describe('顶栏快捷导航', () => {
  it('每一项都是指向自己路由的链接', () => {
    renderShell()
    for (const item of NAV_ITEMS) {
      expect(within(mainNav()).getByRole('link', { name: item.label })).toHaveAttribute(
        'href',
        item.path,
      )
    }
    expect(within(mainNav()).getAllByRole('link')).toHaveLength(NAV_ITEMS.length)
  })

  // 顶栏进去的地址不带图对象标识，那样的编辑页搜什么都会被后端拒。
  // 把图谱页放进导航等于摆一个走不通的入口 —— 进编辑页只有总览列表上的「编辑」一条路。
  it('图谱编辑页不出现在导航里', () => {
    renderShell('/graph')
    expect(within(mainNav()).queryByRole('link', { name: '图谱' })).not.toBeInTheDocument()
    for (const link of within(mainNav()).getAllByRole('link')) {
      expect(link.getAttribute('href')).not.toBe(GRAPH_PATH)
    }
  })

  it('导航项不带任何图对象标识', () => {
    renderShell()
    for (const link of within(mainNav()).getAllByRole('link')) {
      expect(link.getAttribute('href')).not.toContain('object_id')
    }
  })

  it('当前页那一项带 aria-current="page"', () => {
    renderShell('/overview')
    expect(within(mainNav()).getByRole('link', { name: '总览' })).toHaveAttribute(
      'aria-current',
      'page',
    )
  })

  // 视觉选中态和无障碍的「当前页」必须来自同一个判断。
  // 只断言 aria-current 的话，视觉高亮写死在某一项上也能通过。
  it('视觉选中态跟着路由走，而不是写死在总览项上', () => {
    const { unmount } = renderShell('/overview')
    expect(within(mainNav()).getByRole('link', { name: '总览' })).toHaveClass('top-nav__item--active')
    unmount()

    renderShell('/graph')
    expect(within(mainNav()).getByRole('link', { name: '总览' })).not.toHaveClass(
      'top-nav__item--active',
    )
  })
})

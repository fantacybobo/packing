import { NavLink } from 'react-router-dom'
import { APP_NAME, NAV_ITEMS } from './navigation'

/**
 * 顶栏：品牌 + 页面级快捷导航 + 用户。
 *
 * 导航放在顶栏而不是侧边栏：侧边栏现在归总览页自己所有（那里放的是图谱清单树），
 * 不是所有页面共享的东西。页面之间的切换是全局的，该待在全局的位置上。
 *
 * NavLink 命中时自动加 aria-current="page"，视觉选中态由 --active 承担，
 * 两者来自同一个 isActive，不会出现「读屏说在 A、看起来在 B」。
 */
export function TopBar() {
  return (
    <header className="top-bar">
      <span className="top-bar__brand">
        <span className="top-bar__mark" aria-hidden="true">
          <svg width="17" height="17" viewBox="0 0 18 18">
            <circle cx="4" cy="9" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
            <circle cx="14" cy="4" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
            <circle cx="14" cy="14" r="2.4" fill="none" stroke="var(--accent-start)" strokeWidth="1.4" />
            <line x1="6" y1="8" x2="12" y2="5" stroke="var(--accent-start)" strokeWidth="1.2" />
            <line x1="6" y1="10" x2="12" y2="13" stroke="var(--accent-start)" strokeWidth="1.2" />
          </svg>
        </span>
        {APP_NAME}
      </span>

      <nav className="top-nav" aria-label="主导航">
        {NAV_ITEMS.map(item => (
          <NavLink
            key={item.key}
            to={item.path}
            className={({ isActive }) => `top-nav__item${isActive ? ' top-nav__item--active' : ''}`}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* 裸 <span> 上的 aria-label 会被读屏忽略（没有 role 就不允许命名），
          给它 role="img"，这个名字才真的存在 */}
      <span className="top-bar__avatar" role="img" aria-label="当前用户">N</span>
    </header>
  )
}

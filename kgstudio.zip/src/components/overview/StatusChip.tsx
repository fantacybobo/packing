import { statusTone } from './status'

interface StatusChipProps {
  status: string
}

/**
 * 列表里的状态标签：一个色点 + 文字。
 *
 * 颜色在这里是冗余信息 —— 状态本身是写出来的文字，色点只是让人扫得更快。
 * 所以色觉障碍用户不会因此丢掉任何东西（WCAG 1.4.1）。
 *
 * 颜色由 data-tone 交给 CSS 挑，不写行内 style：
 * hover / 主题切换这类事只有样式表接得住。
 */
export function StatusChip({ status }: StatusChipProps) {
  // 后端可能回空串。空标签在表格里看起来和「渲染挂了」一样，用破折号占住位置
  if (!status) return <span className="status-chip status-chip--empty">—</span>

  return (
    <span className="status-chip" data-tone={statusTone(status)}>
      <span className="status-chip__dot" aria-hidden="true" />
      {status}
    </span>
  )
}

import type { CategoryNode } from '@/types/overview'

/**
 * 树上一个节点的唯一标识。
 *
 * 用 domain_id + category_id 而不是光 category_id：后端没说过 category_id
 * 在所有 domain 之间全局唯一。如果不唯一，光用它做 key 会让两个不同分类被 React
 * 当成同一个，选中态也会一起亮。配对在两种情况下都对。
 */
export const categoryKey = (node: CategoryNode): string =>
  `${node.domain_id}/${node.category_id}`

/**
 * 是不是叶子。
 *
 * children 为空或缺席就是叶子 —— 这是「点它能不能查出列表」的唯一判据。
 * 不要改成看层级深度：后端随时可能在中间多插一层。
 */
export const isLeaf = (node: CategoryNode): boolean =>
  !node.children || node.children.length === 0

/**
 * 按 category_index 递归排序，返回新数组（不改传进来的那份）。
 *
 * 后端多半已经排好了，那样这里就是个幂等的空操作；但不排的话，
 * 树的顺序就取决于后端这次恰好怎么返回，两次刷新可能不一样。
 */
export function sortCategories(nodes: readonly CategoryNode[]): CategoryNode[] {
  return [...nodes]
    .sort((a, b) => a.category_index - b.category_index)
    .map(node => (node.children ? { ...node, children: sortCategories(node.children) } : node))
}

/**
 * 图谱状态的语义色档。
 *
 * 取语义名而不是颜色名（和 types/graph.ts 的 Tone 同一套做法）：
 * 配色属于前端主题，将来换配色不该动这张表，也不该动后端契约。
 * 每一档对应的实际颜色在 src/styles/tokens.css 的 --status-* 里。
 */
export type StatusTone = 'neutral' | 'info' | 'progress' | 'positive' | 'danger'

/**
 * status 原值 → 色档。**改文案就改这一张表**，别处不用动。
 *
 * TODO(后端): 这里的键是按常见叫法拟的，真实值域还没给。
 * 对不上的值会落到 DEFAULT_TONE 并在控制台吼一句（见 statusTone），
 * 所以真值下来时你会立刻知道该补哪几行，而不是对着一列灰色的标签发呆。
 */
export const STATUS_TONES: Record<string, StatusTone> = {
  草稿: 'progress',
  编辑中: 'progress',
  审核中: 'info',
  待发布: 'info',
  已发布: 'positive',
  已下线: 'neutral',
  已归档: 'neutral',
  已废弃: 'danger',
  审核不通过: 'danger',
}

/** 认不出来的状态用哪一档。中性色 —— 不能猜成绿色或红色，那是在编造语义 */
export const DEFAULT_TONE: StatusTone = 'neutral'

// 同一个未知值只吼一次，否则一张 50 行的列表会刷 50 条一模一样的警告。
// 做法与 api/objectContext.ts 的 warned 一致。
const warned = new Set<string>()

/**
 * 这个状态该用哪一档颜色。
 *
 * 认不出来时**必须出声**。默默退回中性色的话，后端换了文案（或者本来就和这里对不上）
 * 在界面上看起来完全正常 —— 一整列灰标签，没有任何人会发现配色早就失效了。
 */
export function statusTone(status: string): StatusTone {
  // 空状态是「没有状态」，不是「未知状态」，不该报警
  if (!status) return DEFAULT_TONE

  const tone = STATUS_TONES[status]
  if (tone) return tone

  if (!warned.has(status)) {
    warned.add(status)
    console.warn(
      `[kg-studio] 未知的图谱状态「${status}」，按中性色渲染。` +
      '请在 src/components/overview/status.ts 的 STATUS_TONES 里补上它。',
    )
  }
  return DEFAULT_TONE
}

/** 仅供测试重置去重记录用。生产代码不要调它 */
export function resetStatusWarnings(): void {
  warned.clear()
}

import { useState } from 'react'
import type { CategoryNode } from '@/types/overview'
import { categoryKey, isLeaf } from './categories'

interface CategoryTreeProps {
  nodes: readonly CategoryNode[]
  /** 当前选中的叶子的 categoryKey()，没选就是 null */
  selectedKey: string | null
  onSelect: (node: CategoryNode) => void
}

function ChevronIcon() {
  // 折叠态指向右、展开态指向下，由 CSS 的 transform: rotate 完成 —— 不换图标、不动布局
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
      <path d="M3.5 1.5 L7 5 L3.5 8.5" fill="none" stroke="currentColor" strokeWidth="1.5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/**
 * 分类树。
 *
 * 两类节点的职责严格分开：
 *   - 有 children 的父节点：**只**负责展开/折叠，点它不查任何东西
 *   - 没有 children 的叶子：点它才去查图谱列表
 * 所以父节点和叶子都是 <button>，但语义不同 —— 父节点带 aria-expanded，
 * 叶子带 aria-current。用同一种交互反馈会让人以为点父节点也能出列表。
 *
 * 这里没有一个链接：选分类不改变地址，纯粹是页内状态。
 * 也因此这不是 <nav> —— 什么都没导航到的东西不该占一个导航地标。
 *
 * 没有用 role="tree"：那套 ARIA 要配一整套方向键 / Home / End / 首字母跳转才成立，
 * 半套的 tree 比一组普通按钮更难用。这里是嵌套列表 + 展开按钮（disclosure）模式，
 * Tab 键天然可达，读屏会念「按钮，风控，已展开」。
 */
export function CategoryTree({ nodes, selectedKey, onSelect }: CategoryTreeProps) {
  // 默认全收起：树可以有三层甚至更深，一进来全摊开会把叶子顶出视口。
  const [expanded, setExpanded] = useState<ReadonlySet<string>>(new Set())

  const toggle = (key: string) =>
    setExpanded(prev => {
      // 不在原集合上增删：状态对象换新的，React 才认得出变化
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })

  const renderLevel = (level: readonly CategoryNode[], depth: number) => (
    <ul className={depth === 0 ? 'category-tree__list' : 'category-tree__children'}>
      {level.map(node => {
        const key = categoryKey(node)

        if (isLeaf(node)) {
          const isSelected = selectedKey === key
          return (
            <li key={key}>
              <button
                type="button"
                className={`category-tree__row category-tree__row--leaf${isSelected ? ' category-tree__row--selected' : ''}`}
                // 不是 aria-current="page"：页面没变。这是「这一组里当前选的是它」
                aria-current={isSelected ? 'true' : undefined}
                onClick={() => onSelect(node)}
              >
                {node.category_name}
              </button>
            </li>
          )
        }

        const isOpen = expanded.has(key)
        const listId = `category-${key.replace('/', '-')}`
        return (
          <li key={key}>
            <button
              type="button"
              className="category-tree__row category-tree__row--group"
              aria-expanded={isOpen}
              aria-controls={listId}
              onClick={() => toggle(key)}
            >
              <span className={`category-tree__chevron${isOpen ? ' category-tree__chevron--open' : ''}`}>
                <ChevronIcon />
              </span>
              <span className="category-tree__label">{node.category_name}</span>
            </button>

            {/* 折叠时整段移出 DOM，而不是 display:none —— 收起来的按钮不该还能被 Tab 到 */}
            {isOpen && <div id={listId}>{renderLevel(node.children!, depth + 1)}</div>}
          </li>
        )
      })}
    </ul>
  )

  return renderLevel(nodes, 0)
}

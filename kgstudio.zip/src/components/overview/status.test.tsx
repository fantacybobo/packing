import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import { DEFAULT_TONE, STATUS_TONES, statusTone, resetStatusWarnings } from './status'
import { StatusChip } from './StatusChip'

beforeEach(() => resetStatusWarnings())
afterEach(() => vi.restoreAllMocks())

describe('statusTone', () => {
  it('表里的状态各自拿到自己那一档', () => {
    expect(statusTone('已发布')).toBe('positive')
    expect(statusTone('草稿')).toBe('progress')
    expect(statusTone('已下线')).toBe('neutral')
    expect(statusTone('已废弃')).toBe('danger')
  })

  it('认不出来的状态退回中性色，不猜成绿色或红色', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {})
    expect(statusTone('某个后端新加的状态')).toBe(DEFAULT_TONE)
  })

  // 这条是这套映射能活下去的关键。默默退回中性色的话，后端换了文案在界面上
  // 看起来完全正常 —— 一整列灰标签，没有任何人会发现配色早就失效了。
  it('认不出来的状态会在控制台吼一句，并指出该改哪个文件', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    statusTone('PENDING_REVIEW')

    expect(warn).toHaveBeenCalledTimes(1)
    const [message] = warn.mock.calls[0]
    expect(message).toContain('PENDING_REVIEW')
    expect(message).toContain('STATUS_TONES')
  })

  // 一张 50 行的列表不该刷 50 条一模一样的警告
  it('同一个未知值只吼一次，不同的值各吼一次', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    statusTone('甲')
    statusTone('甲')
    statusTone('乙')

    expect(warn).toHaveBeenCalledTimes(2)
  })

  // 空状态是「没有状态」，不是「未知状态」
  it('空状态不报警', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    expect(statusTone('')).toBe(DEFAULT_TONE)
    expect(warn).not.toHaveBeenCalled()
  })

  it('表里每个值都落在合法的色档上', () => {
    const tones = new Set(['neutral', 'info', 'progress', 'positive', 'danger'])
    for (const tone of Object.values(STATUS_TONES)) expect(tones).toContain(tone)
  })
})

describe('StatusChip', () => {
  it('把色档挂在 data-tone 上，颜色交给样式表挑', () => {
    render(<StatusChip status="已发布" />)
    expect(screen.getByText('已发布')).toHaveAttribute('data-tone', 'positive')
  })

  // 空标签在表格里看起来和「渲染挂了」一样
  it('状态为空时用破折号占位，而不是留一个空格子', () => {
    render(<StatusChip status="" />)
    expect(screen.getByText('—')).toBeInTheDocument()
  })

  // 状态本身是写出来的文字，色点只是让人扫得更快 —— 色觉障碍用户不会丢掉信息
  it('文字本身始终在，颜色只是冗余信号', () => {
    render(<StatusChip status="审核中" />)
    expect(screen.getByText('审核中')).toBeInTheDocument()
  })
})

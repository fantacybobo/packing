import { describe, it, expect } from 'vitest'
import { categoryKey, isLeaf, sortCategories } from './categories'
import type { CategoryNode } from '@/types/overview'

const node = (over: Partial<CategoryNode> = {}): CategoryNode => ({
  category_id: 'C1', category_name: '分类', category_index: 1,
  domain_id: 'D1', domain_name: '域', ...over,
})

describe('categoryKey', () => {
  // 后端没说过 category_id 在所有 domain 之间全局唯一。
  // 光用它做 key，两个不同分类会被 React 当成同一个，选中态也会一起亮。
  it('由 domain_id 和 category_id 一起构成', () => {
    expect(categoryKey(node({ domain_id: 'D2', category_id: 'C9' }))).toBe('D2/C9')
  })

  it('同一个 category_id 落在不同 domain 下时不会撞', () => {
    expect(categoryKey(node({ domain_id: 'D1' }))).not.toBe(categoryKey(node({ domain_id: 'D2' })))
  })
})

describe('isLeaf', () => {
  it('没有 children 是叶子', () => {
    expect(isLeaf(node())).toBe(true)
  })

  // 空数组和缺席是同一回事。只判 undefined 的话，后端回 children: [] 的顶层节点
  // 会变成一个点不出任何东西的父节点。
  it('children 是空数组也是叶子', () => {
    expect(isLeaf(node({ children: [] }))).toBe(true)
  })

  it('有 children 就不是叶子', () => {
    expect(isLeaf(node({ children: [node({ category_id: 'C2' })] }))).toBe(false)
  })
})

describe('sortCategories', () => {
  it('按 category_index 升序排', () => {
    const sorted = sortCategories([
      node({ category_id: 'B', category_index: 2 }),
      node({ category_id: 'A', category_index: 1 }),
    ])
    expect(sorted.map(n => n.category_id)).toEqual(['A', 'B'])
  })

  it('递归排到每一层', () => {
    const [root] = sortCategories([
      node({
        category_id: 'R',
        children: [
          node({ category_id: 'B', category_index: 2 }),
          node({ category_id: 'A', category_index: 1 }),
        ],
      }),
    ])
    expect(root.children!.map(n => n.category_id)).toEqual(['A', 'B'])
  })

  // 传进来的那份来自 useRequest 的 state，就地排会改到状态对象自己
  it('不改传进来的数组', () => {
    const input = [node({ category_id: 'B', category_index: 2 }), node({ category_id: 'A', category_index: 1 })]
    sortCategories(input)
    expect(input.map(n => n.category_id)).toEqual(['B', 'A'])
  })
})

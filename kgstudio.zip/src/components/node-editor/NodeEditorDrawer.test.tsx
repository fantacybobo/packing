import { describe, it, expect, beforeEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithProviders } from '@/test/renderWithProviders'
import { NodeEditorDrawer, hasStatusRemoval } from './NodeEditorDrawer'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import type { GraphNode, NodePayload } from '@/types/graph'

// renderWithProviders 而非裸 render(<AntApp>...)：它额外带上 ConfigProvider 的
// autoInsertSpace: false，否则「保存」会被渲染成「保 存」，按名查询按钮全部失配。
const renderDrawer = () => renderWithProviders(<NodeEditorDrawer />)

beforeEach(async () => {
  useGraphStore.getState().reset()
  useUiStore.setState({ nodeEditor: null, edgeEditor: null, documentPanel: null })
  await useGraphStore.getState().searchGraph(['N01'], 3)
})

describe('NodeEditorDrawer', () => {
  it('未打开时不渲染任何表单', () => {
    renderDrawer()
    expect(screen.queryByLabelText('ENTITY')).not.toBeInTheDocument()
  })

  it('编辑模式下用现有节点回填表单', async () => {
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    expect(await screen.findByDisplayValue('TASK PROCESSOR')).toBeInTheDocument()
  })

  it('新建模式下表单是空的，且不显示删除按钮', async () => {
    useUiStore.getState().openNodeEditor({ mode: 'create' })
    renderDrawer()
    expect(await screen.findByLabelText('ENTITY')).toHaveValue('')
    expect(screen.queryByRole('button', { name: '删除节点' })).not.toBeInTheDocument()
  })

  it('保存成功后抽屉关闭且节点进入 store', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'create' })
    renderDrawer()
    await user.type(await screen.findByLabelText('ENTITY'), 'NEW ENTITY')
    await user.type(screen.getByLabelText('METRICS'), '新节点描述')
    // 状态行必须填：空描述现在是显式校验错误，不再被悄悄滤掉
    await user.type(screen.getByLabelText('状态描述 1'), 'Pending')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await waitFor(() => expect(useUiStore.getState().nodeEditor).toBeNull())
    expect(useGraphStore.getState().nodes.some(n => n.entity === 'NEW ENTITY')).toBe(true)
  })

  it('保存失败时抽屉保持打开且不丢输入', async () => {
    const user = userEvent.setup()
    server.use(http.post('*/api/nodes', () =>
      HttpResponse.json({ success: false, data: null, error: '实体名重复' }, { status: 400 })))
    useUiStore.getState().openNodeEditor({ mode: 'create' })
    renderDrawer()
    await user.type(await screen.findByLabelText('ENTITY'), 'DUP')
    await user.type(screen.getByLabelText('METRICS'), '描述')
    await user.type(screen.getByLabelText('状态描述 1'), 'Pending')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await screen.findByText('实体名重复')
    expect(useUiStore.getState().nodeEditor).not.toBeNull()
    expect(screen.getByLabelText('ENTITY')).toHaveValue('DUP')
  })

  it('可以新增与移除 status 行', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await screen.findByDisplayValue('TASK PROCESSOR')
    const before = screen.getAllByLabelText(/^状态描述/).length
    await user.click(screen.getByRole('button', { name: '+ 添加状态' }))
    expect(screen.getAllByLabelText(/^状态描述/)).toHaveLength(before + 1)
    await user.click(screen.getAllByRole('button', { name: '删除该状态' })[0])
    expect(screen.getAllByLabelText(/^状态描述/)).toHaveLength(before)
  })

  it('新增的 status 行提交时不带 status_id，由后端生成', async () => {
    const user = userEvent.setup()
    let body: NodePayload | undefined
    server.use(http.post('*/api/nodes', async ({ request }) => {
      body = (await request.json()) as NodePayload
      return HttpResponse.json({
        success: true,
        error: null,
        data: {
          node_id: 'N999', entity: body.entity, metrics: body.metrics,
          tone: 'default', document_id: [],
          status_list: body.status_list.map((s, i) => ({
            status_id: `N999-ST0${i + 1}`, node_id: 'N999',
            status_description: s.status_description,
          })),
        },
      })
    }))

    useUiStore.getState().openNodeEditor({ mode: 'create' })
    renderDrawer()
    await user.type(await screen.findByLabelText('ENTITY'), 'NEW')
    await user.type(screen.getByLabelText('METRICS'), '新节点描述')
    await user.type(screen.getByLabelText('状态描述 1'), 'Pending')
    await user.click(screen.getByRole('button', { name: '保存' }))

    await waitFor(() => expect(body).toBeDefined())
    // 关键：整个 status_id 键都不存在，而不是 null/undefined ——
    // 后端据此区分「新建状态」与「沿用已有状态」。
    expect(body!.status_list).toHaveLength(1)
    expect(body!.status_list[0]).not.toHaveProperty('status_id')
    expect(body!.status_list[0].status_description).toBe('Pending')
  })

  it('编辑已有节点提交时沿用原有 status_id', async () => {
    const user = userEvent.setup()
    let body: NodePayload | undefined
    server.use(http.post('*/api/nodes/:nodeId', async ({ request }) => {
      body = (await request.json()) as NodePayload
      return HttpResponse.json({
        success: true,
        error: null,
        data: {
          node_id: 'N01', entity: body.entity, metrics: body.metrics,
          tone: 'default', document_id: ['DOC-2026-0001'],
          status_list: body.status_list.map((s, i) => ({
            status_id: s.status_id ?? `N01-ST0${i + 1}`, node_id: 'N01',
            status_description: s.status_description,
          })),
        },
      })
    }))

    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await screen.findByDisplayValue('TASK PROCESSOR')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await user.click(await screen.findByRole('button', { name: '确认保存' }))

    await waitFor(() => expect(body).toBeDefined())
    // 已有的三条状态（Pending/Running/Active）原样提交，status_id 全部保留，
    // 不因为编辑而被清空或替换成新生成的 id。
    expect(body!.status_list.map(s => s.status_id)).toEqual(['N01-ST01', 'N01-ST02', 'N01-ST03'])
  })

  it('状态描述被清空时拒绝保存：显式报错，行留在原地，边不会被悄悄级联删掉', async () => {
    // 旧实现把空描述的行 filter 掉再提交 —— 于是「清空文字」= 删除该状态，
    // 而删除状态会级联删边（Item 1）。用户没按过任何删除控件，边却消失了。
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await screen.findByDisplayValue('TASK PROCESSOR')

    await user.clear(screen.getByLabelText('状态描述 1'))
    await user.click(screen.getByRole('button', { name: '保存' }))

    await screen.findByText('有状态描述为空，请填写或删除该行')
    // 抽屉不关，行不消失：用户能看见要修的是哪一行
    expect(useUiStore.getState().nodeEditor).not.toBeNull()
    expect(screen.getAllByLabelText(/^状态描述/)).toHaveLength(3)
    // 没有提交，所以状态与边都原封不动
    expect(useGraphStore.getState().nodes.find(n => n.node_id === 'N01')?.status_list)
      .toHaveLength(3)
    expect(useGraphStore.getState().edges.some(e => e.from_status_id === 'N01-ST01')).toBe(true)
  })

  it('删除节点需要二次确认，确认后节点从 store 移除', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await user.click(await screen.findByRole('button', { name: '删除节点' }))
    await user.click(await screen.findByRole('button', { name: '确认删除' }))
    await waitFor(() => expect(useGraphStore.getState().nodes.some(n => n.node_id === 'N01')).toBe(false))
  })

  // 删节点会删掉**所有**连着它的边，比删状态狠得多，原先却只有一个
  // 「确认删除该节点及其相连的边？」的小气泡 —— 两个破坏性操作的告知必须一样重。
  it('删除节点的确认框用的是和保存时同一句关于边的文案', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await user.click(await screen.findByRole('button', { name: '删除节点' }))

    // 与「删状态」那条用例断言的是同一句写死的文案 —— 这就是「两处保持一致」的兑现凭证
    expect(await screen.findByText('此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。')).toBeInTheDocument()
  })

  it('取消删除时什么都不发生', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await user.click(await screen.findByRole('button', { name: '删除节点' }))
    await user.click(await screen.findByRole('button', { name: '再想想' }))

    expect(useGraphStore.getState().nodes.some(n => n.node_id === 'N01')).toBe(true)
    // 抽屉不关：取消的是这次删除，不是这次编辑
    expect(useUiStore.getState().nodeEditor).not.toBeNull()
  })
})

describe('保存前的二次确认', () => {
  it('编辑模式下保存要先确认，取消则什么都不发生', async () => {
    const user = userEvent.setup()
    let calls = 0
    server.use(http.post('*/api/nodes/:nodeId', () => {
      calls += 1
      return HttpResponse.json({ success: false, data: null, error: '不应被调用' }, { status: 400 })
    }))

    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await user.type(await screen.findByLabelText('ENTITY'), ' X')
    await user.click(screen.getByRole('button', { name: '保存' }))

    await user.click(await screen.findByRole('button', { name: '再改改' }))

    expect(calls).toBe(0)
    // 抽屉不关、输入不丢：取消的是这次保存，不是这次编辑
    expect(useUiStore.getState().nodeEditor).not.toBeNull()
    expect(screen.getByLabelText('ENTITY')).toHaveValue('TASK PROCESSOR X')
  })

  // 这是二次确认存在的全部理由：删掉一条状态会连带删掉挂在它上面的边，
  // 而那些边连着别的节点 —— 用户在这个抽屉里根本看不到它们。
  it('删掉状态时，确认框告知会连带删边（与删除节点用同一句文案）', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await screen.findByDisplayValue('TASK PROCESSOR')

    // 删掉第一条状态 Pending —— E001 (N01-ST01 → N02-ST01) 挂在它上面
    await user.click(screen.getAllByRole('button', { name: '删除该状态' })[0])
    await user.click(screen.getByRole('button', { name: '保存' }))

    // 不报数、不列清单：那个数是错的（画布只加载了查询范围内的边），
    // 而一个错的数字比没有数字更危险 —— 用户会拿它做决定
    expect(await screen.findByText('此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。')).toBeInTheDocument()
    expect(screen.queryByText(/连带删除 \d+ 条边/)).not.toBeInTheDocument()
  })

  it('确认之后才真的提交，状态与边一起被删掉', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await screen.findByDisplayValue('TASK PROCESSOR')

    await user.click(screen.getAllByRole('button', { name: '删除该状态' })[0])
    await user.click(screen.getByRole('button', { name: '保存' }))
    await user.click(await screen.findByRole('button', { name: '确认删除并保存' }))

    await waitFor(() =>
      expect(useGraphStore.getState().nodes.find(n => n.node_id === 'N01')?.status_list)
        .toHaveLength(2))
    expect(useGraphStore.getState().edges.some(e => e.edge_id === 'E001')).toBe(false)
  })

  it('没有删状态时，确认框明说这次保存不会影响任何边', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'edit', nodeId: 'N01' })
    renderDrawer()
    await user.type(await screen.findByLabelText('METRICS'), '改一下描述')
    await user.click(screen.getByRole('button', { name: '保存' }))

    expect(await screen.findByText('状态列表没有变化，保存不会影响任何边。')).toBeInTheDocument()
    expect(screen.queryByText(/会被删除/)).not.toBeInTheDocument()
  })

  it('新建节点不需要二次确认：没有可破坏的东西', async () => {
    const user = userEvent.setup()
    useUiStore.getState().openNodeEditor({ mode: 'create' })
    renderDrawer()
    await user.type(await screen.findByLabelText('ENTITY'), 'NEW ENTITY')
    await user.type(screen.getByLabelText('METRICS'), '新节点描述')
    await user.type(screen.getByLabelText('状态描述 1'), 'Pending')
    await user.click(screen.getByRole('button', { name: '保存' }))

    await waitFor(() => expect(useUiStore.getState().nodeEditor).toBeNull())
  })
})

describe('hasStatusRemoval', () => {
  const node: GraphNode = {
    node_id: 'N01', entity: 'A', metrics: 'm', tone: 'default', document_id: [],
    status_list: [
      { status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' },
      { status_id: 'N01-ST02', node_id: 'N01', status_description: 'Running' },
    ],
  }

  it('行还在就不算删除，哪怕描述改了', () => {
    expect(hasStatusRemoval(node, [
      { key: 'a', status_id: 'N01-ST01', status_description: '改过的描述' },
      { key: 'b', status_id: 'N01-ST02', status_description: 'Running' },
    ])).toBe(false)
  })

  it('少了一行就算删除', () => {
    expect(hasStatusRemoval(node, [
      { key: 'b', status_id: 'N01-ST02', status_description: 'Running' },
    ])).toBe(true)
  })

  // 新增的行还没有 status_id。拿「行数」或「有没有空 id」判的话，
  // 加一行会被误判成删了一条，用户平白无故看到一个删除警告。
  it('新增的行没有 status_id，不该把已有状态误判成被删', () => {
    expect(hasStatusRemoval(node, [
      { key: 'a', status_id: 'N01-ST01', status_description: 'Pending' },
      { key: 'b', status_id: 'N01-ST02', status_description: 'Running' },
      { key: 'c', status_description: '新加的' },
    ])).toBe(false)
  })

  it('新建节点（没有 existing）永远不算删除', () => {
    expect(hasStatusRemoval(undefined, [])).toBe(false)
  })
})

import { useEffect, useState } from 'react'
import { App as AntApp, Button, Drawer, Input, Space } from 'antd'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import { errorMessage } from '@/lib/errors'
import type { GraphNode } from '@/types/graph'
import { StatusListEditor, makeTempRow, type StatusRow } from './StatusListEditor'
import './node-editor.css'

/**
 * 这次保存会不会删掉状态。
 *
 * 只关心「有没有」，不关心「删了哪几条」：确认框的文案是写死的，不报数也不列清单。
 * 判据是 status_id —— 新增的行还没有 id，不能把已有状态误判成被删；
 * 只改了描述的行 id 还在，也不算删。
 */
export function hasStatusRemoval(existing: GraphNode | undefined, rows: StatusRow[]): boolean {
  if (!existing) return false
  const keptIds = new Set(rows.map(r => r.status_id).filter(Boolean))
  return existing.status_list.some(s => !keptIds.has(s.status_id))
}

/**
 * 删状态和删节点共用的那句话。
 *
 * 刻意**不报数、不列清单**。曾经是列的，但那个数是错的：画布只加载了本次查询范围内的
 * 连线（seeds 向外 hop 跳），落在范围边界上的节点，它指向范围之外的边根本不在 store 里。
 * 默认数据 + hop=1 就能撞上 —— 删 N02 时确认框说「连带删除 3 条边」，后端实际删 8 条；
 * 更糟的是删某条状态时它会说「没有边会被连带删除」，而那条边照样没了。
 *
 * 要报准数得后端给一个「这次删除会影响什么」的预检接口。在那之前，
 * 说清楚「会删边、不可撤销」就够了，一个错的数字比没有数字更危险。
 */
const EDGE_CASCADE_WARNING = '此操作会连带删除与之相连的边，且不可撤销。请确认你确实要这么做。'

export function NodeEditorDrawer() {
  const { message, modal } = AntApp.useApp()
  const target = useUiStore(s => s.nodeEditor)
  const close = useUiStore(s => s.closeNodeEditor)
  const nodes = useGraphStore(s => s.nodes)
  const createNode = useGraphStore(s => s.createNode)
  const updateNode = useGraphStore(s => s.updateNode)
  const deleteNode = useGraphStore(s => s.deleteNode)

  const isEdit = target?.mode === 'edit'
  const existing = isEdit ? nodes.find(n => n.node_id === target.nodeId) : undefined

  const [entity, setEntity] = useState('')
  const [metrics, setMetrics] = useState('')
  const [rows, setRows] = useState<StatusRow[]>([])
  const [saving, setSaving] = useState(false)

  // 每次打开抽屉时重置表单；失败时不会走到这里，输入得以保留
  useEffect(() => {
    if (!target) return
    setEntity(existing?.entity ?? '')
    setMetrics(existing?.metrics ?? '')
    setRows(
      existing
        ? existing.status_list.map(s => ({
            key: s.status_id, status_id: s.status_id, status_description: s.status_description,
          }))
        : [makeTempRow()],
    )
  }, [target?.mode, target?.nodeId])

  const submit = async (statusList: { status_id?: string; status_description: string }[]) => {
    if (!target) return
    setSaving(true)
    try {
      const payload = {
        entity: entity.trim(),
        metrics: metrics.trim(),
        tone: 'default' as const,
        status_list: statusList,
      }
      if (isEdit && target.nodeId) {
        await updateNode(target.nodeId, payload)
        message.success('节点已更新')
      } else {
        await createNode(payload)
        message.success('节点已创建')
      }
      close()
    } catch (e) {
      message.error(errorMessage(e, '保存失败'))
    } finally {
      setSaving(false)
    }
  }

  const save = async () => {
    if (!target) return

    // 描述为空的行不能被悄悄滤掉。那等于把「清空这行文字」偷偷变成「删除这条状态」，
    // 而删除状态会级联清掉挂在它上面的边（见 store.updateNode）——
    // 用户从头到尾没碰过任何删除控件，边却没了。显式拦下，并把行留在原地给他改。
    const statusList = rows.map(r => ({
      status_id: r.status_id,
      status_description: r.status_description.trim(),
    }))
    if (statusList.some(s => !s.status_description)) {
      message.error('有状态描述为空，请填写或删除该行')
      return
    }

    // 新建节点没有可破坏的东西，直接存。二次确认只在编辑已有节点时出现。
    if (!isEdit || !existing) {
      await submit(statusList)
      return
    }

    const destructive = hasStatusRemoval(existing, rows)

    modal.confirm({
      title: destructive ? '这次保存会删除状态，确认吗？' : '确认保存对该节点的修改？',
      okText: destructive ? '确认删除并保存' : '确认保存',
      cancelText: '再改改',
      okButtonProps: { danger: destructive },
      content: (
        <p className="save-confirm__lead">
          {destructive ? EDGE_CASCADE_WARNING : '状态列表没有变化，保存不会影响任何边。'}
        </p>
      ),
      onOk: () => submit(statusList),
    })
  }

  const remove = async () => {
    if (!target?.nodeId) return
    try {
      await deleteNode(target.nodeId)
      message.success('节点已删除')
      close()
    } catch (e) {
      message.error(errorMessage(e, '删除失败'))
    }
  }

  /**
   * 删除节点的二次确认，和保存时那个同构。
   *
   * 原来这里是一个 Popconfirm，只说「确认删除该节点及其相连的边？」——
   * 而删节点会删掉**所有**连着它的边，比删状态狠得多，却是两者里说得最少的那个。
   * 现在两处都用 modal.confirm，并共用 EDGE_CASCADE_WARNING 那一句写死的文案。
   */
  const confirmRemove = () => {
    if (!existing) return

    modal.confirm({
      title: '确认删除这个节点吗？',
      okText: '确认删除',
      cancelText: '再想想',
      okButtonProps: { danger: true },
      content: <p className="save-confirm__lead">{EDGE_CASCADE_WARNING}</p>,
      onOk: remove,
    })
  }

  return (
    <Drawer
      open={!!target}
      onClose={close}
      size="33.33vw"
      styles={{ wrapper: { minWidth: 380 } }}
      closeIcon={false}
      title={
        <div>
          <div className="panel__kicker">{isEdit ? 'EDIT NODE' : 'NEW NODE'}</div>
          <div className="panel__id">{existing?.node_id ?? '待保存'}</div>
        </div>
      }
      extra={
        <button type="button" className="panel__close" aria-label="关闭" onClick={close}>
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true">
            <line x1="1" y1="1" x2="13" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            <line x1="13" y1="1" x2="1" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </button>
      }
      footer={
        <div className="panel__footer">
          {isEdit ? <Button danger onClick={confirmRemove}>删除节点</Button> : <span />}
          <Space>
            <Button onClick={close}>关闭</Button>
            <Button type="primary" loading={saving} onClick={save}>保存</Button>
          </Space>
        </div>
      }
    >
      <div className="panel__field">
        <span className="panel__kicker">ENTITY</span>
        <Input.TextArea aria-label="ENTITY" rows={1} value={entity} onChange={e => setEntity(e.target.value)} />
      </div>
      <div className="panel__field">
        <span className="panel__kicker">METRICS</span>
        <Input.TextArea aria-label="METRICS" rows={3} value={metrics} onChange={e => setMetrics(e.target.value)} />
      </div>
      <StatusListEditor rows={rows} onChange={setRows} />
    </Drawer>
  )
}

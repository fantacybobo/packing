import { describe, it, expect, beforeEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithProviders } from '@/test/renderWithProviders'
import { DocumentDrawer } from './DocumentDrawer'
import { useUiStore } from '@/store/useUiStore'
import { getDocument } from '@/api/graph'

// renderWithProviders 而非裸 render(<AntApp>...)：它额外带上 ConfigProvider 的
// autoInsertSpace: false，否则「保存」会被渲染成「保 存」，按名查询按钮全部失配；
// AntApp 同时让 App.useApp() 里的 message 能正常工作。
const open = () => useUiStore.getState().openDocument({ nodeId: 'N01', documentId: 'DOC-2026-0001' })
const renderDrawer = () => renderWithProviders(<DocumentDrawer />)

beforeEach(() => useUiStore.setState({ nodeEditor: null, edgeEditor: null, documentPanel: null }))

describe('DocumentDrawer', () => {
  it('未打开时不渲染', () => {
    renderDrawer()
    expect(screen.queryByText('NODE DOCUMENT')).not.toBeInTheDocument()
  })

  it('打开后按 document_id 拉取并展示内容', async () => {
    open()
    renderDrawer()
    expect(await screen.findByText(/任务队列可读/)).toBeInTheDocument()
    expect(screen.getByText('DOC-2026-0001')).toBeInTheDocument()
  })

  it('prerequisite 与 check_question 是只读展示，不是输入框', async () => {
    open()
    renderDrawer()
    await screen.findByText(/任务队列可读/)
    expect(screen.queryByLabelText('PREREQUISITE')).not.toBeInTheDocument()
    expect(screen.getByLabelText('EVALUATION METHOD')).toBeInTheDocument()
  })

  it('保存时回传全部 7 个字段（外加图对象标识），而不只是可编辑的 4 个', async () => {
    const user = userEvent.setup()
    let received: Record<string, unknown> = {}
    server.use(http.post('*/api/documents/:id', async ({ request }) => {
      received = (await request.json()) as Record<string, unknown>
      return HttpResponse.json({ success: true, data: received, error: null })
    }))
    open()
    renderDrawer()
    await user.type(await screen.findByLabelText('REMARK'), '补充说明')
    await user.click(screen.getByRole('button', { name: '保存' }))
    // 7 个业务字段 + 两个图对象标识。标识由 api/client 统一合并进 POST 的 payload
    // （见 client.test 的「POST：放进 payload」），组件自己不管这件事。
    await waitFor(() => expect(Object.keys(received).sort()).toEqual([
      'check_question', 'description', 'document_id', 'evaluation_method',
      'flow_reason', 'object_id', 'object_version', 'prerequisite', 'remark',
    ]))
  })

  it('保存成功后抽屉关闭且改动已落库', async () => {
    const user = userEvent.setup()
    open()
    renderDrawer()
    await user.clear(await screen.findByLabelText('REMARK'))
    await user.type(screen.getByLabelText('REMARK'), '新备注')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await waitFor(() => expect(useUiStore.getState().documentPanel).toBeNull())
    expect((await getDocument('DOC-2026-0001')).remark).toBe('新备注')
  })

  it('保存失败时抽屉保持打开，且用户已输入的改动未丢失', async () => {
    const user = userEvent.setup()
    server.use(http.post('*/api/documents/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '文档已被他人修改' }, { status: 409 })))
    open()
    renderDrawer()
    await user.clear(await screen.findByLabelText('REMARK'))
    await user.type(screen.getByLabelText('REMARK'), '来不及保存的改动')
    await user.click(screen.getByRole('button', { name: '保存' }))
    await screen.findByText('文档已被他人修改')
    // 两半都要断言：抽屉没关，且输入框里的内容还是用户刚打的那份，
    // 不能只验证“还开着”而对内容是否被清空/回滚保持沉默。
    expect(useUiStore.getState().documentPanel).not.toBeNull()
    expect(screen.getByLabelText('REMARK')).toHaveValue('来不及保存的改动')
  })

  it('拉取失败时展示错误而不是空白', async () => {
    server.use(http.get('*/api/documents/:id', () =>
      HttpResponse.json({ success: false, data: null, error: '文档不存在' }, { status: 404 })))
    open()
    renderDrawer()
    expect(await screen.findByText('文档不存在')).toBeInTheDocument()
  })
})

import { memo, type CSSProperties } from 'react'
import { Handle, Position, type NodeProps } from '@xyflow/react'
import { nodeHighlight } from '@/theme'
import { useUiStore } from '@/store/useUiStore'
import { NODE_WIDTH } from '@/lib/layout'
import type { StatusFlowNode } from '@/lib/adapters'
import './graph.css'

/**
 * 卡片分两段：
 *   - 标题区（__head）带内边距，放 entity / metrics / 两个操作按钮，同时是拖拽把手；
 *   - 状态区（__rows）通栏，左右两端就是卡片两端，行与行之间只用一条横线分隔。
 *
 * 状态区必须通栏：连线的 Handle 挂在行上，行内缩多少，连线端点就内缩多少，
 * 终点箭头会被卡片自身盖住。所以 .status-node 的 padding 为 0，行也没有左右边框。
 *
 * node_id 不出现在卡片上 —— 它是给接口用的标识，对着图看的人只关心 entity。
 */
function StatusNodeImpl({ data, selected }: NodeProps<StatusFlowNode>) {
  const { node } = data
  const highlight = nodeHighlight(node.tone, Boolean(selected))
  const openNodeEditor = useUiStore(s => s.openNodeEditor)
  const openDocument = useUiStore(s => s.openDocument)
  const documentId = node.document_id[0]

  return (
    <article
      className={`status-node${selected ? ' status-node--selected' : ''}`}
      // 两个高亮色都走 CSS 变量而不是内联 color/borderColor：
      // 边框和外发光共用 --node-highlight，标题用 --node-title，
      // 具体怎么消费留给 graph.css，组件只负责把 nodeHighlight 的决定传下去。
      // CSSProperties 不认自定义属性名，断言一次是标准写法。
      style={{
        width: NODE_WIDTH,
        '--node-highlight': highlight.border,
        '--node-title': highlight.title,
      } as CSSProperties}
    >
      <header className="status-node__head">
        <div className="status-node__head-top">
          {/* 边框和标题同色：候选 1 绿、候选 2 蓝、选中黄、其余保持常规文字色。
              颜色的取舍全在 nodeHighlight 里，这里只负责把它交给 CSS。 */}
          <h3 className="status-node__title">
            {node.entity}
          </h3>
          <div className="status-node__actions">
            <button
              type="button"
              className="status-node__icon nodrag"
              disabled={!documentId}
              aria-label={documentId ? '节点文档' : '该节点暂无文档'}
              title={documentId ? '节点文档' : '该节点暂无文档'}
              onClick={() => documentId && openDocument({ nodeId: node.node_id, documentId })}
            >
              <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
                <rect x="2" y="1" width="8" height="10" rx="1.5" fill="none" stroke="currentColor" strokeWidth="1.2" />
                <line x1="4" y1="4" x2="8" y2="4" stroke="currentColor" strokeWidth="1.2" />
                <line x1="4" y1="6.5" x2="8" y2="6.5" stroke="currentColor" strokeWidth="1.2" />
              </svg>
            </button>
            <button
              type="button"
              className="status-node__icon nodrag"
              aria-label="编辑节点"
              title="编辑节点"
              onClick={() => openNodeEditor({ mode: 'edit', nodeId: node.node_id })}
            >
              <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true">
                <circle cx="3.6" cy="10.4" r="2.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
                <rect x="5.6" y="2.2" width="3" height="7.2" rx="1.2" transform="rotate(45 7.1 5.8)"
                  fill="none" stroke="currentColor" strokeWidth="1.3" />
              </svg>
            </button>
          </div>
        </div>
        <p className="status-node__metrics">{node.metrics}</p>
      </header>

      <ul className="status-node__rows">
        {node.status_list.map(status => (
          <li key={status.status_id} className="status-node__row">
            <Handle type="target" position={Position.Left} id={status.status_id} className="status-node__port" />
            <span className="status-node__row-label">Status:</span>
            <span className="status-node__row-value">{status.status_description}</span>
            <Handle type="source" position={Position.Right} id={status.status_id} className="status-node__port" />
          </li>
        ))}
      </ul>
    </article>
  )
}

export const StatusNode = memo(StatusNodeImpl)

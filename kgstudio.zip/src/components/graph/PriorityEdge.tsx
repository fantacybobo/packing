import { BaseEdge, EdgeLabelRenderer, getBezierPath, type EdgeProps } from '@xyflow/react'
import { useUiStore } from '@/store/useUiStore'
import { EDGE_LABEL_ANCHOR, EDGE_LABEL_PLACEMENT, edgeLabelPoint } from '@/lib/edgeLabel'
import './graph.css'

export function PriorityEdge({
  id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, data, markerEnd,
}: EdgeProps) {
  const placement = EDGE_LABEL_PLACEMENT
  const openEdgeEditor = useUiStore(s => s.openEdgeEditor)
  const [path, centerX, centerY] = getBezierPath({
    sourceX, sourceY, sourcePosition, targetX, targetY, targetPosition,
  })

  // getBezierPath 只给中点；靠左 / 靠右的锚点按弧长从路径里算出来（见 lib/edgeLabel）
  const point = edgeLabelPoint(path, placement, { x: centerX, y: centerY })
  const priority = String(data?.priority ?? '')

  return (
    <>
      <BaseEdge id={id} path={path} markerEnd={markerEnd} className="priority-edge" />
      <EdgeLabelRenderer>
        {/*
          标签必须是个真按钮，不能是块带 cursor: pointer 的死文字。
          它就压在连线上，pointer-events 一开就会把本该落到边上的点击全吃掉 ——
          用户点了、指针也变成了手形，却什么都没发生。既然挡在路上，就让它
          做和点边一样的事：打开这条边的编辑器。顺带也就键盘可达了。
        */}
        <button
          type="button"
          className="priority-edge__label nodrag nopan"
          data-placement={placement}
          aria-label={`编辑这条边，当前优先级 ${priority}`}
          style={{
            // transform 从右往左生效：先挪到锚点，再按摆法做自身偏移
            transform: `${EDGE_LABEL_ANCHOR[placement]} translate(${point.x}px, ${point.y}px)`,
          }}
          onClick={() => openEdgeEditor({ mode: 'edit', edgeId: id })}
        >
          pri: {priority}
        </button>
      </EdgeLabelRenderer>
    </>
  )
}

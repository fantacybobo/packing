import { describe, it, expect, beforeEach } from 'vitest'
import type { ComponentProps } from 'react'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ReactFlowProvider } from '@xyflow/react'
import { StatusNode } from './StatusNode'
import { useUiStore } from '@/store/useUiStore'
import { renderWithProviders } from '@/test/renderWithProviders'
import { SELECTED_COLOR, TONE_COLORS } from '@/theme'
import type { GraphNode } from '@/types/graph'

const node: GraphNode = {
  node_id: 'N01', entity: 'TASK PROCESSOR', metrics: '从队列拉取待处理任务。',
  tone: 'default', document_id: ['DOC-2026-0001'],
  status_list: [
    { status_id: 'N01-ST01', node_id: 'N01', status_description: 'Pending' },
    { status_id: 'N01-ST02', node_id: 'N01', status_description: 'Running' },
  ],
}

// xyflow v12 的 NodeProps 字段较多，测试里只关心其中几个，
// 用组件自身的 props 类型收敛，避免逐个补齐无关字段
type StatusNodeProps = ComponentProps<typeof StatusNode>

const renderNode = (data: GraphNode = node, selected = false) => {
  const props = {
    id: data.node_id,
    type: 'statusNode',
    data: { node: data },
    selected,
    dragging: false,
    zIndex: 0,
    isConnectable: true,
    positionAbsoluteX: 0,
    positionAbsoluteY: 0,
  } as unknown as StatusNodeProps

  // renderWithProviders 提供与生产一致的 ConfigProvider/AntApp；
  // ReactFlowProvider 是 StatusNode 使用 <Handle> 所必需的额外上下文。
  return renderWithProviders(
    <ReactFlowProvider>
      <StatusNode {...props} />
    </ReactFlowProvider>,
  )
}

beforeEach(() => {
  useUiStore.setState({ nodeEditor: null, edgeEditor: null, documentPanel: null })
})

describe('StatusNode', () => {
  it('标题是 entity，描述是 metrics', () => {
    renderNode()
    expect(screen.getByRole('heading', { level: 3 })).toHaveTextContent('TASK PROCESSOR')
    expect(screen.getByText('从队列拉取待处理任务。')).toBeInTheDocument()
  })

  // node_id 是给接口用的标识，对着图看的人只关心 entity。
  // 断言「整张卡片任何位置都不出现 N01」，而不只是断言标题不是它 ——
  // 否则把 id 挪到副标题、角标上仍然算通过。
  it('卡片上任何位置都不展示 node_id', () => {
    const { container } = renderNode()
    expect(container.textContent).not.toContain('N01')
  })

  it('每条 status 渲染一行', () => {
    renderNode()
    expect(screen.getByText('Pending')).toBeInTheDocument()
    expect(screen.getByText('Running')).toBeInTheDocument()
  })

  it('每条 status 左右各一个 handle，id 就是 status_id，左侧为 target、右侧为 source', () => {
    const { container } = renderNode()
    // 覆盖两条 status，而不只是第一条；同时断言 handle 类型，
    // 防止左右 target/source 被悄悄调换（连线方向会因此整体反转）。
    for (const statusId of ['N01-ST01', 'N01-ST02']) {
      const left = container.querySelector(`[data-handleid="${statusId}"][data-handlepos="left"]`)
      const right = container.querySelector(`[data-handleid="${statusId}"][data-handlepos="right"]`)
      expect(left).toBeTruthy()
      expect(right).toBeTruthy()
      expect(left).toHaveClass('target')
      expect(right).toHaveClass('source')
    }
  })

  it('点编辑按钮打开节点编辑抽屉', async () => {
    const user = userEvent.setup()
    renderNode()
    await user.click(screen.getByRole('button', { name: '编辑节点' }))
    expect(useUiStore.getState().nodeEditor).toEqual({ mode: 'edit', nodeId: 'N01' })
  })

  it('点文档按钮用第一个 document_id 打开文档面板', async () => {
    const user = userEvent.setup()
    renderNode()
    await user.click(screen.getByRole('button', { name: '节点文档' }))
    expect(useUiStore.getState().documentPanel).toEqual({ nodeId: 'N01', documentId: 'DOC-2026-0001' })
  })

  it('document_id 为空时文档按钮禁用', () => {
    renderNode({ ...node, document_id: [] })
    expect(screen.getByRole('button', { name: '该节点暂无文档' })).toBeDisabled()
  })
})

// 高亮色写在 --node-highlight 上，边框与外发光都取它。
// 断言这个变量而不是 borderColor：变量是唯一的决定点，borderColor 只是它的一个消费方。
describe('StatusNode 的高亮', () => {
  const highlightOf = (container: HTMLElement) =>
    container.querySelector<HTMLElement>('.status-node')!.style.getPropertyValue('--node-highlight')

  const titleOf = (container: HTMLElement) =>
    container.querySelector<HTMLElement>('.status-node')!.style.getPropertyValue('--node-title')

  it('default tone 用中性边框色', () => {
    expect(highlightOf(renderNode().container)).toBe(TONE_COLORS.default.border)
  })

  it('候选 1 绿、候选 2 蓝', () => {
    expect(highlightOf(renderNode({ ...node, tone: 'candidate_1' }).container))
      .toBe(TONE_COLORS.candidate_1.border)
    expect(highlightOf(renderNode({ ...node, tone: 'candidate_2' }).container))
      .toBe(TONE_COLORS.candidate_2.border)
  })

  // 边框和标题必须一起变色。只染边框的话，选中时标题突然变黄就成了一条
  // 没有对应关系的孤立规则 —— 用户会觉得两套高亮各说各话。
  it('候选节点的标题文字也染成对应的绿 / 蓝', () => {
    expect(titleOf(renderNode({ ...node, tone: 'candidate_1' }).container))
      .toBe(TONE_COLORS.candidate_1.title)
    expect(titleOf(renderNode({ ...node, tone: 'candidate_2' }).container))
      .toBe(TONE_COLORS.candidate_2.title)
  })

  it('非候选节点的标题保持常规文字色，不会被染绿', () => {
    expect(titleOf(renderNode().container)).toBe(TONE_COLORS.default.title)
  })

  // 用候选节点而不是 default 节点来验证选中态：default 本来就没有颜色，
  // 拿它测「黄色覆盖」等于什么都没测。
  it('选中候选节点时边框和标题都被黄色盖掉', () => {
    const { container } = renderNode({ ...node, tone: 'candidate_1' }, true)
    expect(highlightOf(container)).toBe(SELECTED_COLOR)
    expect(titleOf(container)).toBe(SELECTED_COLOR)
  })
})

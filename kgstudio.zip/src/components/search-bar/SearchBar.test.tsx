import { describe, it, expect, beforeEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useLocation } from 'react-router-dom'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithProviders } from '@/test/renderWithProviders'
import { SearchBar } from './SearchBar'
import { useGraphStore } from '@/store/useGraphStore'

const renderBar = (search = '') => renderWithProviders(<SearchBar />, { searchParams: search })

beforeEach(() => useGraphStore.getState().reset())

describe('SearchBar', () => {
  it('候选一为空时搜索按钮禁用', () => {
    renderBar()
    expect(screen.getByRole('button', { name: '搜索' })).toBeDisabled()
  })

  it('选中候选一后搜索按钮可点击', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')
    await user.click(await screen.findByText(/TASK PROCESSOR/))
    expect(screen.getByRole('button', { name: '搜索' })).toBeEnabled()
  })

  it('hop 默认是 2', () => {
    renderBar()
    expect(screen.getByLabelText('跳数')).toHaveValue('2')
  })

  it('URL 中带 hop 时用 URL 的值', () => {
    renderBar('?nodes=N01&hop=4')
    expect(screen.getByLabelText('跳数')).toHaveValue('4')
  })

  it('URL 中 hop 越界时收敛到上界', () => {
    renderBar('?nodes=N01&hop=99')
    expect(screen.getByLabelText('跳数')).toHaveValue('6')
  })

  it('深链进入时按响应回填候选框的显示文案', async () => {
    renderBar('?nodes=N01&hop=1')
    // antd 内部 title 与 label 是两条独立的计算路径：
    // title 只是 hover 提示，屏幕上真正显示的是 label。
    // 只断言 title 的话，label 计算整个坏掉测试依然会绿 —— 两条都要钉住。
    // 二者渲染在同一个 .ant-select-selection-item 元素上，可以一次断完。
    const selected = await screen.findByTitle('TASK PROCESSOR')
    expect(selected).toHaveTextContent('从队列拉取待处理任务')
  })

  it('深链进入时自动发起查询并把图灌进 store', async () => {
    renderBar('?nodes=N01&hop=1')
    await waitFor(() => expect(useGraphStore.getState().nodes).toHaveLength(2))
  })

  // node_id 在画布上从不显示（见 StatusNode 的注释），下拉里摆一个别处见不到的标识，
  // 对正在挑节点的人没有意义，只会把真正要读的 entity / metrics 挤窄。
  it('下拉行只展示 entity 与 metrics，不出现 node id', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')
    await screen.findByText('TASK PROCESSOR')

    const rows = document.querySelectorAll('.search-bar__option')
    expect(rows.length).toBeGreaterThan(0)
    for (const row of rows) {
      expect(row.textContent).toContain('TASK PROCESSOR')
      expect(row.textContent).toContain('从队列拉取待处理任务')
      expect(row.textContent).not.toMatch(/N\d{2}/)
    }
  })

  it('按 node id 仍然搜得到，只是不展示它', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('N02')
    expect(await screen.findByText('DECISION GATE')).toBeInTheDocument()
  })

  it('工具条上有发版入口', async () => {
    const user = userEvent.setup()
    renderBar()
    const release = screen.getByRole('button', { name: '发版' })
    expect(release).toBeEnabled()
    // 接口还没定。按得动却毫无反应的按钮和坏掉的按钮长得一模一样，所以先给一句明确的反馈。
    await user.click(release)
    expect(await screen.findByText('发版功能尚未接入')).toBeInTheDocument()
  })

  it('节点搜索失败时明说失败，而不是谎报「无匹配节点」', async () => {
    // 500、断网、真的没匹配 —— 三件事被压成同一句文案时，用户会以为节点不存在。
    // spec §11：不静默吞掉任何错误。
    const user = userEvent.setup()
    server.use(http.get('*/api/nodes/search', () =>
      HttpResponse.json({ success: false, data: null, error: '节点服务暂时不可用' }, { status: 500 })))

    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')

    expect(await screen.findByText('节点服务暂时不可用')).toBeInTheDocument()
    expect(screen.queryByText('无匹配节点')).not.toBeInTheDocument()
  })

  it('搜索恢复正常后错误提示消失', async () => {
    const user = userEvent.setup()
    renderBar()
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('TASK')
    expect(await screen.findByText(/TASK PROCESSOR/)).toBeInTheDocument()
    expect(screen.queryByText(/暂时不可用/)).not.toBeInTheDocument()
  })
})

// URL 是单向的：进入页面时带进来的参数决定首屏，之后页面里点「搜索」
// 只重新拉数据，不把新参数写回 URL。于是刷新 / 前进后退永远回到「进来时那一份」，
// 而不是一个被页面操作改写过、说不清来历的中间状态。
describe('URL 单向', () => {
  function LocationProbe() {
    const { search } = useLocation()
    return <div data-testid="search">{search}</div>
  }

  const renderWithProbe = (search: string) =>
    renderWithProviders(
      <>
        <SearchBar />
        <LocationProbe />
      </>,
      { initialPath: '/graph', searchParams: search },
    )

  // 查询进行中时按钮是 loading 态，antd 会把无障碍名变成「loading 搜索」，
  // 而那个 loading 图标在状态落地后还会多留一帧。用正则取名字避开这层时序，
  // 工具条里只有这一个按钮的名字含「搜索」，不会取错。
  const clickSearch = async (user: ReturnType<typeof userEvent.setup>) => {
    await waitFor(() => expect(useGraphStore.getState().status).toBe('ready'))
    await user.click(screen.getByRole('button', { name: /搜索/ }))
  }

  it('点「搜索」会重新查询，但不改 URL', async () => {
    const user = userEvent.setup()
    renderWithProbe('?nodes=N01&hop=1')
    await waitFor(() => expect(useGraphStore.getState().nodes).toHaveLength(2))

    // 换一个候选并提高 hop，再点搜索
    await user.click(screen.getByLabelText('候选节点 1'))
    await user.keyboard('COMPLETE')
    await user.click(await screen.findByText(/收口成功与失败两条出口/))
    await clickSearch(user)

    // 图换了……
    await waitFor(() =>
      expect(useGraphStore.getState().nodes.some(n => n.node_id === 'N04')).toBe(true))
    // ……URL 一个字都没动。断言完整的查询串而不是「不含 N04」——
    // 后者在 URL 被清空时同样成立。
    expect(screen.getByTestId('search')).toHaveTextContent('?nodes=N01&hop=1')
  })

  it('改 hop 不会写回 URL，URL 里越界的值也原样留着', async () => {
    const user = userEvent.setup()
    renderWithProbe('?nodes=N01&hop=99')
    // 输入框按上界回填，URL 保持原样：页面只读 URL，不修改它
    expect(screen.getByLabelText('跳数')).toHaveValue('6')
    await waitFor(() => expect(useGraphStore.getState().status).toBe('ready'))
    await user.clear(screen.getByLabelText('跳数'))
    await user.type(screen.getByLabelText('跳数'), '3')
    await clickSearch(user)
    expect(screen.getByTestId('search')).toHaveTextContent('?nodes=N01&hop=99')
  })
})

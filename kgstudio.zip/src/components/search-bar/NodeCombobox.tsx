import { useCallback, useEffect, useRef, useState } from 'react'
import { Select, Spin } from 'antd'
import { searchNodes } from '@/api/graph'
import { errorMessage } from '@/lib/errors'
import type { GraphNode } from '@/types/graph'

const DEBOUNCE_MS = 300

export interface NodeOption {
  value: string
  label: string
  // antd option 上独立于 label 的字段，专门用来控制收起态展示的原生 title 属性：
  // label 优先展示更具体的 metrics 长描述，但 title 固定用 entity 短名，
  // 与下拉行里 entity 作为次要标识的用法保持一致
  title: string
  entity: string
  metrics: string
}

export const toOption = (node: GraphNode): NodeOption => ({
  value: node.node_id,
  label: node.metrics || node.entity,
  title: node.entity,
  entity: node.entity,
  metrics: node.metrics,
})

interface NodeComboboxProps {
  value: string | null
  onChange: (id: string | null) => void
  placeholder: string
  dotColor: string
  label: string
  extraOptions?: NodeOption[]
}

export function NodeCombobox({ value, onChange, placeholder, dotColor, label, extraOptions = [] }: NodeComboboxProps) {
  const [options, setOptions] = useState<NodeOption[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  useEffect(() => () => clearTimeout(timer.current), [])

  const handleSearch = useCallback((keyword: string) => {
    clearTimeout(timer.current)
    timer.current = setTimeout(async () => {
      setLoading(true)
      try {
        setOptions((await searchNodes(keyword)).map(toOption))
        setError(null)
      } catch (e) {
        // 500、断网、和「真的一个都没匹配上」必须是三回事。
        // 都显示成「无匹配节点」，等于告诉用户这个节点不存在 ——
        // spec §11 明确要求不静默吞掉任何错误，DocumentDrawer 也是这么区分的。
        setOptions([])
        setError(errorMessage(e, '节点搜索失败，请重试'))
      } finally {
        setLoading(false)
      }
    }, DEBOUNCE_MS)
  }, [])

  // 深链进入时 URL 只有 id，用外部补进来的选项保证能显示文案
  const merged = [...extraOptions.filter(o => !options.some(x => x.value === o.value)), ...options]

  return (
    <div className="search-bar__field">
      <span className="search-bar__dot" style={{ background: dotColor }} aria-hidden="true" />
      <Select
        aria-label={label}
        className="search-bar__select"
        variant="borderless"
        showSearch
        allowClear
        value={value}
        placeholder={placeholder}
        filterOption={false}
        notFoundContent={
          loading
            ? <Spin size="small" />
            : error
              ? <span className="search-bar__error" role="alert">{error}</span>
              : '无匹配节点'
        }
        onSearch={handleSearch}
        onFocus={() => handleSearch('')}
        onChange={next => onChange(next ?? null)}
        options={merged}
        // 下拉行只说 entity 与 metrics。node_id 不上屏 —— 画布上的卡片从不显示它
        // （见 StatusNode 的注释），下拉里摆一个别处见不到的标识，对选节点的人没有意义。
        // 关键字仍然能匹配到 node_id，只是不展示。
        optionRender={option => (
          <div className="search-bar__option">
            <span className="search-bar__option-entity">{option.data.entity}</span>
            <span className="search-bar__option-desc">{option.data.metrics}</span>
          </div>
        )}
      />
    </div>
  )
}

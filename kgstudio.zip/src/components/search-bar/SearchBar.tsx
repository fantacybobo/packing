import { useEffect, useMemo, useState } from 'react'
import { App as AntApp, Button, InputNumber } from 'antd'
import { useGraphQuerySync } from '@/hooks/useGraphQuery'
import { HOP_DEFAULT, HOP_MAX, HOP_MIN, clampHop } from '@/hooks/queryParams'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import { NodeCombobox, toOption, type NodeOption } from './NodeCombobox'
import './search-bar.css'

export function SearchBar() {
  const { message } = AntApp.useApp()
  // SearchBar 是全应用唯一持有查询 effect 的组件，见 useGraphQuery.ts 的注释
  const { nodeIds, hop, runQuery } = useGraphQuerySync()
  const nodes = useGraphStore(s => s.nodes)
  const status = useGraphStore(s => s.status)
  const openNodeEditor = useUiStore(s => s.openNodeEditor)

  // 草稿态：URL 只负责给出初值，之后改什么都不写回 URL（见 useGraphQuery.ts）
  const [first, setFirst] = useState<string | null>(nodeIds[0] ?? null)
  const [second, setSecond] = useState<string | null>(nodeIds[1] ?? null)
  const [draftHop, setDraftHop] = useState<number>(hop)

  // URL 变化（深链、前进后退）时同步草稿
  useEffect(() => { setFirst(nodeIds[0] ?? null); setSecond(nodeIds[1] ?? null) }, [nodeIds.join(',')])
  useEffect(() => { setDraftHop(hop) }, [hop])

  // 深链回填：种子节点必然在查询结果里，用它补出候选框的显示文案
  // 复用 NodeCombobox 的 toOption：这份映射（label 取 metrics 回退 entity、title 取 entity）
  // 原本在两处各手写一遍，改一处漏一处就会出现「搜出来的选项和回填的选项长得不一样」。
  const seedOptions = useMemo<NodeOption[]>(
    () => nodes.filter(n => nodeIds.includes(n.node_id)).map(toOption),
    [nodes, nodeIds.join(',')],
  )

  const submit = () => {
    if (!first) return
    runQuery(second && second !== first ? [first, second] : [first], clampHop(draftHop))
  }

  return (
    <div className="search-bar">
      <div className="search-bar__group">
        <NodeCombobox
          label="候选节点 1" placeholder="搜索候选节点 1" dotColor="var(--accent-start)"
          value={first} onChange={setFirst} extraOptions={seedOptions}
        />
        <NodeCombobox
          label="候选节点 2" placeholder="搜索候选节点 2（选填）" dotColor="var(--accent-end)"
          value={second} onChange={setSecond} extraOptions={seedOptions}
        />
        <div className="search-bar__hop">
          <span className="search-bar__hop-label" aria-hidden="true">HOP</span>
          <InputNumber
            aria-label="跳数"
            variant="borderless"
            min={HOP_MIN}
            max={HOP_MAX}
            value={draftHop}
            // 清空或非法输入时回落，不让脏值发出去
            onChange={next => setDraftHop(next == null ? HOP_DEFAULT : clampHop(next))}
          />
        </div>
        <Button
          type="primary"
          className="search-bar__submit"
          disabled={!first}
          loading={status === 'loading'}
          onClick={submit}
        >
          搜索
        </Button>
      </div>
      <Button className="search-bar__add" onClick={() => openNodeEditor({ mode: 'create' })}>
        + 新建节点
      </Button>
      {/*
        发版：接口还没定，先把入口摆出来。
        不留空 onClick —— 一个按得动却毫无反应的按钮和一个坏掉的按钮长得一模一样。
        接上真实接口时替换掉这里的 message 即可，按钮本身不用动。
      */}
      <Button className="search-bar__release" onClick={() => message.info('发版功能尚未接入')}>
        发版
      </Button>
    </div>
  )
}

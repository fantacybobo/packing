import { useEffect, useState } from 'react'
import { App as AntApp, Button, InputNumber, Modal, Popconfirm, Space } from 'antd'
import { useGraphStore } from '@/store/useGraphStore'
import { useUiStore } from '@/store/useUiStore'
import { errorMessage } from '@/lib/errors'
import { connectionToPayload, describeEdgeEndpoints } from '@/lib/adapters'
import './edge-editor.css'

const DEFAULT_PRIORITY = 1

export function EdgeEditorModal() {
  const { message } = AntApp.useApp()
  const target = useUiStore(s => s.edgeEditor)
  const close = useUiStore(s => s.closeEdgeEditor)
  const nodes = useGraphStore(s => s.nodes)
  const edges = useGraphStore(s => s.edges)
  const createEdge = useGraphStore(s => s.createEdge)
  const updateEdge = useGraphStore(s => s.updateEdge)
  const deleteEdge = useGraphStore(s => s.deleteEdge)

  const isEdit = target?.mode === 'edit'
  const existing = isEdit ? edges.find(e => e.edge_id === target.edgeId) : undefined

  const [priority, setPriority] = useState<number>(DEFAULT_PRIORITY)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!target) return
    setPriority(existing?.priority ?? DEFAULT_PRIORITY)
  }, [target?.mode, target?.edgeId])

  // 标题说的是「哪个实体的哪个状态，指向哪个实体的哪个状态」。
  // 原来这里直接摆 from_status_id → to_status_id，而卡片上从不显示 id：
  // 用户看着 N01-ST01 → N04-ST01，对不上画布上的任何东西。
  const endpoints = describeEdgeEndpoints(nodes, {
    fromNodeId: existing?.from_node_id ?? target?.draft?.source,
    toNodeId: existing?.to_node_id ?? target?.draft?.target,
    fromStatusId: existing?.from_status_id ?? target?.draft?.sourceHandle,
    toStatusId: existing?.to_status_id ?? target?.draft?.targetHandle,
  })
  const hasEndpoints = Boolean(existing || target?.draft)

  const save = async () => {
    if (!target) return
    setSaving(true)
    try {
      if (isEdit && existing) {
        await updateEdge(existing.edge_id, { ...existing, priority })
        message.success('边已更新')
      } else if (target.draft) {
        const payload = connectionToPayload(target.draft, priority)
        if (!payload) {
          message.error('连线信息不完整，请重新拖动连接')
          return
        }
        await createEdge(payload)
        message.success('边已创建')
      } else {
        // 两个分支都不成立：编辑模式但那条边已不在 store 里（可能被别处删了），
        // 且没有可用的 draft。此时静默 close() 会让用户以为保存成功，
        // 实际什么都没发生 —— 必须显式报错且不关窗。
        message.error('这条边已不存在，请关闭后重新操作')
        return
      }
      close()
    } catch (e) {
      message.error(errorMessage(e, '保存失败'))
    } finally {
      setSaving(false)
    }
  }

  const remove = async () => {
    if (!existing) return
    try {
      await deleteEdge(existing.edge_id)
      message.success('边已删除')
      close()
    } catch (e) {
      message.error(errorMessage(e, '删除失败'))
    }
  }

  return (
    <Modal
      open={!!target}
      onCancel={close}
      width={460}
      title={
        <div>
          <div className="panel__kicker">{isEdit ? 'EDIT EDGE' : 'NEW EDGE'}</div>
          {hasEndpoints && (
            <div className="edge-endpoints">
              <p className="edge-endpoints__line">
                <span className="edge-endpoints__entity">{endpoints.fromEntity}</span>
                <span className="edge-endpoints__arrow" aria-hidden="true">→</span>
                <span className="edge-endpoints__entity">{endpoints.toEntity}</span>
              </p>
              <p className="edge-endpoints__line edge-endpoints__line--status">
                <span>{endpoints.fromStatus}</span>
                <span className="edge-endpoints__arrow" aria-hidden="true">→</span>
                <span>{endpoints.toStatus}</span>
              </p>
            </div>
          )}
        </div>
      }
      footer={
        <div className="panel__footer">
          {isEdit ? (
            <Popconfirm
              title="确认删除这条边？"
              okText="确认删除"
              cancelText="取消"
              okButtonProps={{ danger: true }}
              onConfirm={remove}
            >
              <Button danger>删除边</Button>
            </Popconfirm>
          ) : <span />}
          <Space>
            <Button onClick={close}>关闭</Button>
            <Button type="primary" loading={saving} onClick={save}>保存</Button>
          </Space>
        </div>
      }
    >
      <div className="panel__field">
        <span className="panel__kicker">PRIORITY</span>
        <InputNumber
          aria-label="PRIORITY"
          min={0}
          style={{ width: 120 }}
          value={priority}
          onChange={next => setPriority(next == null ? DEFAULT_PRIORITY : Math.max(0, Math.floor(next)))}
        />
      </div>
    </Modal>
  )
}

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { ConfigProvider, App as AntApp } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import { BrowserRouter } from 'react-router-dom'
import '@xyflow/react/dist/style.css'
import './styles/global.css'
import { antdTheme } from './theme'
import { shouldUseMock } from './lib/env'
import App from './App'

async function bootstrap() {
  if (shouldUseMock(import.meta.env.VITE_USE_MOCK)) {
    const { worker } = await import('./mocks/browser')
    await worker.start({ onUnhandledRequest: 'bypass' })
  }
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      {/* 查询状态只从 URL 读、不写回，用 react-router 的 useSearchParams 就够了，
          不再需要 nuqs 那一层双向绑定的适配器。 */}
      <BrowserRouter>
        <ConfigProvider theme={antdTheme} locale={zhCN} button={{ autoInsertSpace: false }}>
          <AntApp>
            <App />
          </AntApp>
        </ConfigProvider>
      </BrowserRouter>
    </StrictMode>,
  )
}

void bootstrap()

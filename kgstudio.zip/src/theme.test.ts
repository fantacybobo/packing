import { describe, it, expect } from 'vitest'
import type { Tone } from '@/types/graph'
import { SELECTED_COLOR, TONE_COLORS, antdTheme, nodeHighlight } from './theme'

describe('antdTheme', () => {
  it('使用设计稿的画布底色作为全局背景', () => {
    expect(antdTheme.token?.colorBgBase).toBe('#070c12')
  })

  it('容器背景与边框取自设计稿', () => {
    expect(antdTheme.token?.colorBgContainer).toBe('#0d151d')
    expect(antdTheme.token?.colorBorder).toBe('#23323f')
  })

  // 字体栈的唯一真源是 tokens.css，antd 只能指回去。写死字面量就等于又开了一份副本，
  // 将来改 tokens.css 时这里不会有任何信号。
  it('字体指向 tokens.css 的变量，不自带字体栈', () => {
    expect(antdTheme.token?.fontFamily).toBe('var(--font-sans)')
    expect(antdTheme.token?.fontFamilyCode).toBe('var(--font-mono)')
  })
})

describe('TONE_COLORS', () => {
  it('非候选节点用中性边框，标题保持常规强调文字色', () => {
    expect(TONE_COLORS.default.border).toBe('#233442')
    expect(TONE_COLORS.default.title).toBe('var(--color-text-strong)')
  })

  // 颜色与搜索栏两个候选框的圆点同源：候选 1 是 --accent-start（绿），候选 2 是 --accent-end（蓝）。
  // 用户在搜索栏看到的绿/蓝，必须就是画布上高亮的绿/蓝。
  it('两个候选各自对应搜索栏圆点的绿与蓝', () => {
    expect(TONE_COLORS.candidate_1.border).toBe('#4ade80')
    expect(TONE_COLORS.candidate_2.border).toBe('#60a5fa')
  })

  // 边框和标题分开存两个字段，就有了写岔的可能。候选态下两者必须同色 ——
  // 否则「这张卡属于哪个候选」会出现两个互相矛盾的视觉信号。
  it('候选态下标题与边框同色', () => {
    expect(TONE_COLORS.candidate_1.title).toBe(TONE_COLORS.candidate_1.border)
    expect(TONE_COLORS.candidate_2.title).toBe(TONE_COLORS.candidate_2.border)
  })
})

describe('nodeHighlight', () => {
  it('未选中时按 tone 取色', () => {
    expect(nodeHighlight('candidate_1', false).border).toBe(TONE_COLORS.candidate_1.border)
    expect(nodeHighlight('candidate_2', false).border).toBe(TONE_COLORS.candidate_2.border)
    expect(nodeHighlight('default', false).border).toBe(TONE_COLORS.default.border)
  })

  it('未选中时标题也跟着 tone 走，不是只染边框', () => {
    expect(nodeHighlight('candidate_1', false).title).toBe(TONE_COLORS.candidate_1.border)
    expect(nodeHighlight('candidate_2', false).title).toBe(TONE_COLORS.candidate_2.border)
    // 非候选节点的标题保持常规文字色，不会被染成绿色
    expect(nodeHighlight('default', false).title).toBe('var(--color-text-strong)')
  })

  it('选中时边框与标题一律用黄色，盖掉候选色', () => {
    for (const tone of ['default', 'candidate_1', 'candidate_2'] as const) {
      expect(nodeHighlight(tone, true)).toEqual({ border: SELECTED_COLOR, title: SELECTED_COLOR })
    }
  })

  // tone 来自服务端，是不可信输入。类型系统挡不住 JSON 里冒出来的第四个值，
  // 真出现时必须退回 default，而不是把 undefined 当颜色写进 style。
  it('遇到类型之外的 tone 退回 default，不产出 undefined', () => {
    const dirty = 'candidate_99' as Tone
    expect(nodeHighlight(dirty, false)).toEqual(TONE_COLORS.default)
  })
})

import { SearchBar } from '@/components/search-bar/SearchBar'
import { GraphCanvas } from '@/components/graph/GraphCanvas'
import { NodeEditorDrawer } from '@/components/node-editor/NodeEditorDrawer'
import { EdgeEditorModal } from '@/components/edge-editor/EdgeEditorModal'
import { DocumentDrawer } from '@/components/document/DocumentDrawer'
import { useGraphObjectRefSync } from '@/hooks/useGraphQuery'
import './pages.css'

/** 图谱编辑页：查询工具条 + 画布 + 三个编辑面板。应用的主体就是这一页 */
export function GraphPage() {
  // 把 URL 上的 object_id / object_version 同步给 api 层，本页所有请求都会带上它们。
  // 必须在渲染期完成，理由见 useGraphObjectRefSync 的注释。
  useGraphObjectRefSync()

  return (
    <>
      <div className="page-toolbar">
        <SearchBar />
      </div>
      <main className="page page--canvas">
        <GraphCanvas />
        <NodeEditorDrawer />
        <EdgeEditorModal />
        <DocumentDrawer />
      </main>
    </>
  )
}

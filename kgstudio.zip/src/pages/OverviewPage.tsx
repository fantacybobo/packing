import { useCallback, useMemo, useState } from 'react'
import { Button, Empty, Spin } from 'antd'
import { graphPathFor } from '@/components/app-shell/navigation'
import { CategoryTree } from '@/components/overview/CategoryTree'
import { StatusChip } from '@/components/overview/StatusChip'
import { categoryKey, sortCategories } from '@/components/overview/categories'
import { fetchCategoryTree, fetchKnowledgeObjects } from '@/api/overview'
import { useRequest, type RequestState } from '@/hooks/useRequest'
import type { CategoryNode, KnowledgeObjectSummary } from '@/types/overview'
import './pages.css'
import './overview.css'

/**
 * 四张指标卡。
 *
 * TODO(数据层): 这一轮数值写死。提示文案刻意不宣称范围（不写「当前分类合计」之类）——
 * 卡片不跟着左侧分类变而文案说它变了，那是在骗人。接口定下来再一起接。
 */
const STATS = [
  { key: 'graphs', label: '图谱总数', value: '12', unit: '个' },
  { key: 'versions', label: '版本总数', value: '31', unit: '个' },
  { key: 'nodes', label: '节点总数', value: '4,286' },
  { key: 'edges', label: '关系总数', value: '9,517' },
] as const

const COLUMNS = ['图谱名称', '版本', '状态', '操作'] as const

export function OverviewPage() {
  // 选中的分类只活在组件里：点树不改地址，也不写任何持久化。
  // 代价是刷新后回到初始态 —— 这是产品定的，「编修」用新标签页打开，
  // 所以从编修页回来时这个标签页本来就没动过，日常用不到后退恢复。
  const [selected, setSelected] = useState<CategoryNode | null>(null)

  const tree = useRequest('categories', fetchCategoryTree)
  // 排序放这里而不是渲染里：树每次展开/折叠都会重渲染，没必要跟着重排
  const categories = useMemo(() => sortCategories(tree.data ?? []), [tree.data])

  const selectedKey = selected ? categoryKey(selected) : null
  const loadObjects = useCallback(
    () => fetchKnowledgeObjects(selected!.category_id, selected!.domain_id),
    [selected],
  )
  // key 为 null 时 useRequest 停在 idle：不发请求，也不显示加载中
  const objects = useRequest(selectedKey, loadObjects)

  return (
    <div className="page page--overview">
      <aside className="overview__side" aria-labelledby="category-tree-title">
        <h2 className="overview__side-title" id="category-tree-title">分类</h2>

        {tree.status === 'loading' && <p className="overview__side-hint">正在加载分类…</p>}
        {tree.status === 'error' && (
          <div className="overview__side-hint">
            <p>{tree.error}</p>
            <Button size="small" onClick={tree.retry}>重试</Button>
          </div>
        )}
        {tree.status === 'ready' && categories.length === 0 && (
          <p className="overview__side-hint">还没有任何分类</p>
        )}
        {tree.status === 'ready' && categories.length > 0 && (
          <CategoryTree nodes={categories} selectedKey={selectedKey} onSelect={setSelected} />
        )}
      </aside>

      <main className="overview__main">
        <section className="overview__stats" aria-label="关键指标">
          {STATS.map(stat => (
            <article key={stat.key} className="stat-card">
              <p className="stat-card__label">{stat.label}</p>
              <p className="stat-card__value">
                {stat.value}
                {'unit' in stat && <span className="stat-card__unit">{stat.unit}</span>}
              </p>
            </article>
          ))}
        </section>

        <section className="overview__panel" aria-labelledby="overview-graphs-title">
          <header className="overview__panel-head">
            <h2 className="overview__panel-title" id="overview-graphs-title">
              图谱列表
              {selected && <span className="overview__panel-scope">{selected.category_name}</span>}
            </h2>
            {objects.status === 'ready' && (
              <span className="overview__panel-meta">共 {objects.data!.length} 条</span>
            )}
          </header>

          <GraphList state={objects} />
        </section>
      </main>
    </div>
  )
}

/**
 * 列表区的四种状态。
 *
 * idle（还没选分类）和 ready 但为空是两件不同的事，文案必须分开：
 * 前者是「你还没选」，后者是「这个分类下确实没有」。
 * 合成一句的话，用户会以为自己选的分类坏了。
 */
function GraphList({ state }: { state: RequestState<KnowledgeObjectSummary[]> }) {
  if (state.status === 'idle') {
    return (
      <div className="overview__list-state">
        <Empty description="从左侧选择一个分类，查看它下面的图谱" image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    )
  }
  if (state.status === 'loading') {
    return (
      <div className="overview__list-state">
        <Spin />
        <p className="overview__list-hint">正在加载图谱列表…</p>
      </div>
    )
  }
  if (state.status === 'error') {
    return (
      <div className="overview__list-state">
        <Empty description={state.error} image={Empty.PRESENTED_IMAGE_SIMPLE} />
        <Button onClick={state.retry}>重试</Button>
      </div>
    )
  }

  const rows = state.data ?? []
  if (rows.length === 0) {
    return (
      <div className="overview__list-state">
        <Empty description="这个分类下还没有图谱" image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    )
  }

  return (
    <table className="graph-table">
      <thead>
        <tr>
          {COLUMNS.map(column => (
            <th key={column} scope="col" className={column === '操作' ? 'graph-table__actions-col' : undefined}>
              {column}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map(row => (
          <tr key={`${row.object_id}@${row.object_version}`}>
            <td>
              <span className="graph-table__name">{row.knowledge_object_name}</span>
              <span className="graph-table__id">{row.object_id}</span>
            </td>
            <td><span className="graph-table__version">{row.object_version}</span></td>
            <td><StatusChip status={row.status} /></td>
            <td className="graph-table__actions-col">
              {/*
                新标签页打开：总览页原封不动留在原来那个标签，选中的分类不会丢。
                用原生 <a> 而不是 <Link>：这是一次真正的新文档加载，不该走前端路由。
                rel 两个值都是必须的 —— 少了 noopener，新页面能通过 window.opener 操作这一页。
              */}
              <a
                className="graph-table__edit"
                href={graphPathFor(row.object_id, row.object_version)}
                target="_blank"
                rel="noopener noreferrer"
                // 同一个「编修」出现好几次，光靠可见文字读屏分不出是哪一行的；
                // 会开新标签页这件事也要说，否则焦点突然不见了没人知道为什么
                aria-label={`编修 ${row.knowledge_object_name} ${row.object_version}（新标签页打开）`}
              >
                编修
              </a>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

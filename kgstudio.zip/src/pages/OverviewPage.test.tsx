import { describe, it, expect } from 'vitest'
import { screen, within, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { OverviewPage } from './OverviewPage'
import { renderWithProviders } from '@/test/renderWithProviders'

const renderPage = () => renderWithProviders(<OverviewPage />, { initialPath: '/overview' })

const side = () => screen.getByRole('complementary', { name: '分类' })
const dataRows = () =>
  within(screen.getByRole('table')).getAllByRole('row').slice(1)

/** 展开到「履约」这个叶子：风控/运营都是顶层父节点，运营下面才是叶子 */
async function openFulfillment(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await within(side()).findByRole('button', { name: '运营' }))
  return within(side()).getByRole('button', { name: '履约' })
}

describe('OverviewPage 初始态', () => {
  it('还没选分类时列表区明说要先选，而不是显示加载中或一片空白', async () => {
    renderPage()
    expect(await screen.findByText(/从左侧选择一个分类/)).toBeInTheDocument()
    expect(screen.queryByRole('table')).not.toBeInTheDocument()
  })

  it('四张指标卡这一轮是写死的，不随分类变', async () => {
    renderPage()
    const stats = screen.getByRole('region', { name: '关键指标' })
    expect(within(stats).getAllByRole('article')).toHaveLength(4)
  })

  // 一进来全摊开会把叶子顶出视口，而且三层树摊开后根本看不出层级
  it('树默认全收起，只露出顶层', async () => {
    renderPage()
    expect(await within(side()).findByRole('button', { name: '运营' })).toHaveAttribute(
      'aria-expanded',
      'false',
    )
    expect(within(side()).queryByRole('button', { name: '履约' })).not.toBeInTheDocument()
  })

  // category_index 在 mock 里故意不按数组顺序给
  it('同级按 category_index 排，不是按后端返回的数组顺序', async () => {
    renderPage()
    await within(side()).findByRole('button', { name: '运营' })
    const labels = within(side()).getAllByRole('button').map(b => b.textContent)
    expect(labels.slice(0, 3)).toEqual(['运营', '风控', '归档'])
  })
})

describe('OverviewPage 父节点与叶子的分工', () => {
  // 这是这棵树的核心规则：父节点只展开，点它右边不该有任何动静
  it('点父节点只展开 children，不查列表', async () => {
    const user = userEvent.setup()
    renderPage()
    const group = await within(side()).findByRole('button', { name: '运营' })

    await user.click(group)
    expect(group).toHaveAttribute('aria-expanded', 'true')
    expect(within(side()).getByRole('button', { name: '履约' })).toBeInTheDocument()
    // 右边还停在「请先选一个分类」
    expect(screen.getByText(/从左侧选择一个分类/)).toBeInTheDocument()
    expect(screen.queryByRole('table')).not.toBeInTheDocument()
  })

  it('再点一次父节点会把 children 移出 DOM，不留在原地被 Tab 到', async () => {
    const user = userEvent.setup()
    renderPage()
    const group = await within(side()).findByRole('button', { name: '运营' })

    await user.click(group)
    await user.click(group)
    expect(group).toHaveAttribute('aria-expanded', 'false')
    expect(within(side()).queryByRole('button', { name: '履约' })).not.toBeInTheDocument()
  })

  it('点叶子才刷新列表', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    await waitFor(() => expect(screen.getByRole('table')).toBeInTheDocument())
    expect(dataRows()).toHaveLength(3)
    expect(screen.getByRole('heading', { name: /图谱列表/ })).toHaveTextContent('履约')
  })

  // 树可以有三层甚至更深，叶子判定只看 children 空不空，不看深度
  it('第三层的叶子照样能查出列表', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await within(side()).findByRole('button', { name: '风控' }))
    await user.click(within(side()).getByRole('button', { name: '规则引擎' }))
    await user.click(within(side()).getByRole('button', { name: '反洗钱' }))

    await waitFor(() => expect(dataRows()).toHaveLength(2))
  })

  // children: [] 的顶层节点本身就是叶子。只判 undefined 的话它会变成一个点不出东西的父节点
  it('children 为空数组的顶层节点是叶子，点了直接查', async () => {
    const user = userEvent.setup()
    renderPage()
    const archive = await within(side()).findByRole('button', { name: '归档' })

    expect(archive).not.toHaveAttribute('aria-expanded')
    await user.click(archive)
    // 这个分类下确实没有图谱 —— 和「你还没选」是两句不同的话
    expect(await screen.findByText('这个分类下还没有图谱')).toBeInTheDocument()
  })

  it('选中的叶子带 aria-current，且同时只有一个', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    await waitFor(() => expect(screen.getByRole('table')).toBeInTheDocument())
    expect(side().querySelectorAll('[aria-current]')).toHaveLength(1)
    expect(within(side()).getByRole('button', { name: '履约' })).toHaveAttribute('aria-current', 'true')
  })
})

describe('OverviewPage 图谱列表', () => {
  it('表头是名称、版本、状态、操作四列', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    await waitFor(() => expect(screen.getByRole('table')).toBeInTheDocument())
    const headers = within(screen.getByRole('table')).getAllByRole('columnheader').map(th => th.textContent)
    expect(headers).toEqual(['图谱名称', '版本', '状态', '操作'])
  })

  it('每行的「编修」在新标签页打开，并带上这一行的图对象标识', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    const link = await screen.findByRole('link', { name: /^编修 供应链履约图谱 v3/ })
    // 不带 object_id / object_version 进去，图谱页的所有接口都会被后端拒掉
    expect(link).toHaveAttribute('href', '/graph?object_id=KG-2026-0001&object_version=v3')
    expect(link).toHaveAttribute('target', '_blank')
    // 少了 noopener，新标签页能通过 window.opener 反过来操作这一页
    expect(link.getAttribute('rel')).toContain('noopener')
  })

  // 五个「编修」可见文字一模一样；无障碍名不带行信息，读屏用户不知道点的是哪一行。
  // 会开新标签页这件事也要说，否则焦点突然不见了没人知道为什么。
  it('「编修」的无障碍名能定位到行，并说明会开新标签页', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    const links = await screen.findAllByRole('link', { name: /^编修 / })
    const names = links.map(a => a.getAttribute('aria-label'))
    expect(new Set(names).size).toBe(names.length)
    expect(names.every(name => name?.includes('新标签页'))).toBe(true)
  })

  // 状态的颜色由 data-tone 决定，映射表在 components/overview/status.ts
  it('状态列按值染色，认不出来的值不会被猜成某个颜色', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))

    await waitFor(() => expect(screen.getByRole('table')).toBeInTheDocument())
    expect(screen.getByText('已发布')).toHaveAttribute('data-tone', 'positive')
    expect(screen.getByText('草稿')).toHaveAttribute('data-tone', 'progress')
    expect(screen.getByText('已下线')).toHaveAttribute('data-tone', 'neutral')
  })

  it('换一个叶子，列表整个换掉', async () => {
    const user = userEvent.setup()
    renderPage()
    await user.click(await openFulfillment(user))
    await waitFor(() => expect(dataRows()).toHaveLength(3))

    await user.click(within(side()).getByRole('button', { name: '售后' }))
    await waitFor(() => expect(dataRows()).toHaveLength(1))
    expect(screen.getByText('售后工单图谱')).toBeInTheDocument()
  })
})

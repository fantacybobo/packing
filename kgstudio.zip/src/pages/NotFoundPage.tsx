import { Link } from 'react-router-dom'
import { GRAPH_PATH } from '@/components/app-shell/navigation'
import './pages.css'

/**
 * 地址打错时走这里。
 * 不静默重定向到图谱页 —— 那样用户永远不知道自己的链接是错的，
 * 只会觉得「书签怎么跳到别处去了」。
 */
export function NotFoundPage() {
  return (
    <main className="page page--placeholder">
      <div className="placeholder">
        <p className="placeholder__kicker">404</p>
        <h2 className="placeholder__title">没有这个页面</h2>
        <p className="placeholder__hint">
          地址可能打错了。<Link className="placeholder__link" to={GRAPH_PATH}>回到图谱</Link>
        </p>
      </div>
    </main>
  )
}

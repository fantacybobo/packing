import { describe, it, expect } from 'vitest'
import { screen } from '@testing-library/react'
import { useLocation } from 'react-router-dom'
import App from './App'
import { GRAPH_PATH, OVERVIEW_PATH, NAV_ITEMS } from './components/app-shell/navigation'
import { renderWithProviders } from './test/renderWithProviders'

const renderAt = (initialPath: string) => renderWithProviders(<App />, { initialPath })

/** 把 router 当前的 location 暴露给断言。和 <App /> 同在一个 MemoryRouter 下 */
function LocationProbe() {
  const { pathname, search } = useLocation()
  return <div data-testid="location">{pathname + search}</div>
}

const renderWithProbe = (initialPath: string) =>
  renderWithProviders(
    <>
      <App />
      <LocationProbe />
    </>,
    { initialPath },
  )

describe('路由表', () => {
  it('/graph 是图谱页：查询工具条在位', () => {
    renderAt(GRAPH_PATH)
    expect(screen.getByRole('button', { name: '搜索' })).toBeInTheDocument()
    expect(screen.getByLabelText('跳数')).toBeInTheDocument()
  })

  it('/overview 是总览页：分类树、指标卡和图谱列表都在', () => {
    renderAt(OVERVIEW_PATH)
    expect(screen.getByRole('complementary', { name: '分类' })).toBeInTheDocument()
    expect(screen.getByRole('region', { name: '关键指标' })).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: /图谱列表/ })).toBeInTheDocument()
  })

  // 侧边栏不该跟到这一页来：它装的是分类树，是总览页的东西
  it('/graph 没有侧边栏', () => {
    renderAt(GRAPH_PATH)
    expect(screen.queryByRole('complementary', { name: '分类' })).not.toBeInTheDocument()
  })

  it('顶栏每一项都有对应路由，点进去不会落到 404', () => {
    // 往 NAV_ITEMS 里加一项却忘了加路由时，这里会红。
    // 反方向不成立：/graph 有路由但刻意不在导航里。
    for (const item of NAV_ITEMS) {
      const { unmount } = renderAt(item.path)
      expect(screen.queryByText('没有这个页面')).not.toBeInTheDocument()
      unmount()
    }
  })

  it('地址打错时给 404，而不是静默跳走', () => {
    renderAt('/nope')
    expect(screen.getByText('没有这个页面')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: '回到图谱' })).toHaveAttribute('href', GRAPH_PATH)
  })
})

// 多页之后，读屏用户点侧边栏除了 DOM 变化没有任何「我现在在哪一页」的信号。
// 标题是最低成本的那个信号。
describe('标签页标题', () => {
  it('跟着路由变，而不是恒为产品名', () => {
    const { unmount } = renderAt(GRAPH_PATH)
    expect(document.title).toBe('图谱 · KG Studio')
    unmount()

    renderAt(OVERVIEW_PATH)
    expect(document.title).toBe('总览 · KG Studio')
  })

  it('404 的标题说明是找不到页面', () => {
    renderAt('/nope')
    expect(document.title).toBe('页面不存在 · KG Studio')
  })
})

describe('根路径重定向', () => {
  it('裸 / 落到总览页 —— 那是应用的入口', () => {
    renderWithProbe('/')
    expect(screen.getByTestId('location')).toHaveTextContent(OVERVIEW_PATH)
    expect(screen.getByRole('complementary', { name: '分类' })).toBeInTheDocument()
  })

  // 查询状态的唯一真源是 URL，历史深链和书签都是 /?object_id=..&nodes=..&hop=.. 这个形状。
  // 一律送去总览的话，这些链接会在当事人毫无察觉的情况下全部失效：
  // 页面正常打开，只是打开的是另一个地方，而他要的那张图再也回不去了。
  // 断言落点的完整 URL，而不是「在图谱页上」：后者在查询串被丢掉时同样成立。
  it('带查询串的 / 仍然去图谱页，并原样带上查询串', () => {
    renderWithProbe('/?nodes=N01&hop=3')
    expect(screen.getByTestId('location')).toHaveTextContent('/graph?nodes=N01&hop=3')
  })

  // 这一条是上面两条的分界线本身。判据是「有没有查询串」，
  // 写成「永远去总览」或「永远去图谱」都会让其中一条红。
  it('图对象标识也照样带过去', () => {
    renderWithProbe('/?object_id=KG-2026-0001&object_version=v3')
    expect(screen.getByTestId('location')).toHaveTextContent(
      '/graph?object_id=KG-2026-0001&object_version=v3',
    )
  })
})

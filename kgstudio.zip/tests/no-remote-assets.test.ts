import { describe, it, expect } from 'vitest'
import { readFileSync, readdirSync, type Dirent } from 'node:fs'
import { join, resolve } from 'node:path'

/**
 * 交付要求：构建产物不依赖任何需要联网拉取的资源。
 *
 * 这个文件住在 src/ 外面，是因为它要读磁盘上的源文件（node:fs）。
 * src/ 的 tsconfig 刻意只给浏览器类型，好让应用代码误用 process / Buffer 时当场报错；
 * 需要 Node 类型的测试因此放在 tests/ 下，走 tsconfig.tests.json。
 *
 * 这条约束没法靠 code review 守住 —— 一个 <link href="https://fonts.googleapis.com/...">
 * 在能联网的开发机上看不出任何异常，只有到了离线/内网环境才会退化成默认字体。
 * 所以把它变成一条会红的断言：源码里出现任何外部 origin 就失败。
 */

const ROOT = resolve(import.meta.dirname, '..')

// 协议相对的 //cdn... 同样会走网络，一并挡住
const REMOTE_URL = /(?:https?:)?\/\/[a-z0-9.-]+\.[a-z]{2,}/gi

// 注释和文档里提到域名是允许的（本仓库多处注释引用了 mswjs.io、react.dev 等），
// 只有真正会被浏览器拉取的位置才算违规：HTML 属性与 CSS 的 url()/@import。
const HTML_FETCHED_ATTR = /(?:href|src)\s*=\s*"([^"]*)"/gi
const CSS_FETCHED = /(?:@import\s+|url\(\s*)['"]?([^'")\s]+)/gi

function cssFilesUnder(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry: Dirent) => {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) return cssFilesUnder(full)
    return entry.name.endsWith('.css') ? [full] : []
  })
}

function remoteRefs(source: string, pattern: RegExp): string[] {
  return [...source.matchAll(pattern)]
    .map(match => match[1])
    .filter(value => REMOTE_URL.test(value ?? ''))
}

describe('构建产物不引用外部资源', () => {
  it('index.html 里没有指向外部域名的 link/script', () => {
    const html = readFileSync(join(ROOT, 'index.html'), 'utf8')
    expect(remoteRefs(html, HTML_FETCHED_ATTR)).toEqual([])
  })

  it('src 下的样式表没有远程 @import 或 url()', () => {
    const offenders = cssFilesUnder(join(ROOT, 'src')).flatMap(file => {
      const refs = remoteRefs(readFileSync(file, 'utf8'), CSS_FETCHED)
      return refs.map(ref => `${file.slice(ROOT.length + 1)} → ${ref}`)
    })
    expect(offenders).toEqual([])
  })

  it('字体栈只由本机自带字体构成', () => {
    // 去掉注释再断言：注释里提到这两个旧字体名是为了解释为什么把它们换掉，
    // 不去掉的话这条测试会被自己的说明文字绊倒。
    const tokens = readFileSync(join(ROOT, 'src/styles/tokens.css'), 'utf8')
      .replace(/\/\*[\s\S]*?\*\//g, '')
    // 这两个原本从 Google Fonts 拉，本机没装，留在字体栈里只是一句无效声明
    expect(tokens).not.toContain('IBM Plex Sans')
    expect(tokens).not.toContain('JetBrains Mono')
    expect(tokens).toMatch(/--font-sans:\s*system-ui/)
    expect(tokens).toMatch(/--font-mono:\s*ui-monospace/)
  })
})

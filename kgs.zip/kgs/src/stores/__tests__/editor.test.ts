import { describe, it, expect, beforeEach } from 'vitest'
import { useKgStore } from '../useKgStore'
import type { GraphPayload, LinkDetail } from '@/api/types'

beforeEach(() => useKgStore.setState(useKgStore.getInitialState(), true))

const s = () => useKgStore.getState()

const sub: GraphPayload = {
  nodes: [
    { id: 'dbb', label: 'Database B', type: 'Relational DB', domain: 'Data Stores', desc: 'Primary' },
  ],
  edges: [],
  meta: { centerId: 'dbb', hops: 2, truncated: false, nodeCap: 200, totalNodes: 1 },
}

const link: LinkDetail = {
  id: 'e8',
  source: { id: 'gwd', label: 'Gateway D' },
  target: { id: 'dbb', label: 'Database B' },
  label: 'stores',
  predicate: 'stores',
  directed: true,
  createdAt: '',
  updatedAt: '',
}

describe('openNodeEditor', () => {
  it('prefills the draft from the node in the subgraph', () => {
    useKgStore.setState({ leftSub: sub })
    s().openNodeEditor('dbb', 'L')
    expect(s().editor).toMatchObject({
      kind: 'node',
      id: 'dbb',
      side: 'L',
      draft: { label: 'Database B', type: 'Relational DB', domain: 'Data Stores', desc: 'Primary' },
      dirty: false,
    })
  })

  it('starts blank when creating', () => {
    s().openNodeEditor(null, 'R')
    expect(s().editor).toMatchObject({
      kind: 'node',
      id: null,
      side: 'R',
      draft: { label: '', type: '', domain: '', desc: '' },
    })
  })
})

describe('openLinkEditor', () => {
  it('prefills the draft from the selected link', () => {
    useKgStore.setState({ links: [link], sel: { side: 'R', kind: 'edge', id: 'e8' } })
    s().openLinkEditor('e8')
    expect(s().editor).toMatchObject({ kind: 'link', id: 'e8', side: 'R', draft: { label: 'stores' } })
  })
})

describe('setDraft / closeEditor', () => {
  it('marks the editor dirty so closing can warn', () => {
    useKgStore.setState({ leftSub: sub })
    s().openNodeEditor('dbb', 'L')
    expect(s().editor?.dirty).toBe(false)
    s().setDraft({ label: 'changed' })
    expect(s().editor?.dirty).toBe(true)
  })

  it('refuses to close a dirty editor without force', () => {
    useKgStore.setState({ leftSub: sub })
    s().openNodeEditor('dbb', 'L')
    s().setDraft({ label: 'changed' })
    s().closeEditor()
    expect(s().editor).not.toBeNull()
  })

  it('closes a clean editor without fuss', () => {
    useKgStore.setState({ leftSub: sub })
    s().openNodeEditor('dbb', 'L')
    s().closeEditor()
    expect(s().editor).toBeNull()
  })
})

describe('saveEditor — preview only', () => {
  it('closes the editor without touching any other state', () => {
    useKgStore.setState({ leftSub: sub, startId: 'dbb' })
    s().openNodeEditor('dbb', 'L')
    s().setDraft({ label: 'Renamed' })
    s().saveEditor()
    expect(s().editor).toBeNull()
    // 不落数据：子图与中心都不变
    expect(s().leftSub?.nodes[0].label).toBe('Database B')
    expect(s().startId).toBe('dbb')
  })
})

describe('confirm dialog — preview only', () => {
  it('opens and closes via askConfirm / closeConfirm', () => {
    s().askConfirm({ kind: 'deleteLink', id: 'e8' })
    expect(s().confirm).toEqual({ kind: 'deleteLink', id: 'e8' })
    s().closeConfirm()
    expect(s().confirm).toBeNull()
  })

  it('runConfirm only closes the dialog, leaving links untouched', () => {
    useKgStore.setState({ links: [link] })
    s().askConfirm({ kind: 'deleteLink', id: 'e8' })
    s().runConfirm()
    expect(s().confirm).toBeNull()
    expect(s().links).toHaveLength(1)
  })
})

describe('toggleStartEndLink', () => {
  it('refuses when start and end are the same node', () => {
    useKgStore.setState({ startId: 'a101', endId: 'a101' })
    s().toggleStartEndLink()
    expect(s().editor).toBeNull()
    expect(s().notice?.key).toBe('link.sameNode')
  })

  it('does nothing when either endpoint is missing', () => {
    useKgStore.setState({ startId: 'a101', endId: null })
    s().toggleStartEndLink()
    expect(s().editor).toBeNull()
  })

  it('stays out of the way when relations already join the pair', () => {
    useKgStore.setState({
      startId: 'gwd',
      endId: 'dbb',
      path: { found: true, segments: [], directLinks: [link] },
    })
    s().toggleStartEndLink()
    expect(s().editor).toBeNull()
  })

  it('opens a blank relation editor when no relation exists yet', () => {
    useKgStore.setState({
      startId: 'a101',
      endId: 'obj',
      path: { found: false, segments: [], directLinks: [] },
    })
    s().toggleStartEndLink()
    expect(s().editor).toMatchObject({
      kind: 'link',
      id: null,
      endpoints: { source: 'a101', target: 'obj' },
    })
  })
})

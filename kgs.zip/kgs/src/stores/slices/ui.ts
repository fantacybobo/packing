import type { SliceCreator } from '../useKgStore'

export interface Notice {
  /** i18n key，由界面层翻译；text 为服务端原文，优先展示 */
  key?: string
  params?: Record<string, unknown>
  text?: string
  type: 'success' | 'error'
  /** 每次置入都递增，界面据此判断是同一条还是新的一条 */
  at: number
}

export interface UiSlice {
  blocking: boolean
  notice: Notice | null
  notify: (n: Omit<Notice, 'at'>) => void
  clearNotice: () => void
}

export const createUiSlice: SliceCreator<UiSlice> = (set) => ({
  blocking: false,
  notice: null,

  notify: (n) => {
    set((s) => {
      s.notice = { ...n, at: Date.now() + Math.random() }
    })
  },

  clearNotice: () => {
    set((s) => {
      s.notice = null
    })
  },
})

import type { Side } from '@/theme/antdTheme'
import type { SliceCreator } from '../useKgStore'

export interface NodeDraft {
  label: string
  type: string
  domain: string
  desc: string
}
export interface LinkDraft {
  label: string
}

export interface EditorState {
  kind: 'node' | 'link'
  /** null 表示新建 */
  id: string | null
  side: Side
  draft: NodeDraft | LinkDraft
  dirty: boolean
  error: string | null
  /** 新建关系时的两端 */
  endpoints?: { source: string; target: string }
}

export type ConfirmState =
  | { kind: 'deleteNode'; id: string; count?: number }
  | { kind: 'deleteLink'; id: string }
  | { kind: 'reverseLink'; id: string }

const EMPTY_NODE: NodeDraft = { label: '', type: '', domain: '', desc: '' }

/**
 * 纯 UI slice：编辑弹窗与确认框的打开、草稿、关闭。
 * 数据层已摘除（项目仅保留预览与交互）—— saveEditor / runConfirm 只关闭弹窗，
 * 不写任何数据。编辑数据的持久化待重新设计后接回。
 */
export interface EditorSlice {
  editor: EditorState | null
  confirm: ConfirmState | null
  openNodeEditor: (id: string | null, side: Side) => void
  openLinkEditor: (id: string) => void
  setDraft: (patch: Partial<NodeDraft & LinkDraft>) => void
  closeEditor: (force?: boolean) => void
  saveEditor: () => void
  askConfirm: (c: ConfirmState) => void
  closeConfirm: () => void
  runConfirm: () => void
  toggleStartEndLink: () => void
}

export const createEditorSlice: SliceCreator<EditorSlice> = (set, get) => ({
  editor: null,
  confirm: null,

  openNodeEditor: (id, side) => {
    const existing = id
      ? (get().leftSub?.nodes.find((n) => n.id === id) ??
        get().rightSub?.nodes.find((n) => n.id === id))
      : null
    set((s) => {
      s.editor = {
        kind: 'node',
        id,
        side,
        draft: existing
          ? { label: existing.label, type: existing.type, domain: existing.domain, desc: existing.desc }
          : { ...EMPTY_NODE },
        dirty: false,
        error: null,
      }
    })
  },

  openLinkEditor: (id) => {
    const link = get().links.find((l) => l.id === id)
    set((s) => {
      s.editor = {
        kind: 'link',
        id,
        side: s.sel?.side ?? 'L',
        draft: { label: link?.label ?? '' },
        dirty: false,
        error: null,
      }
    })
  },

  setDraft: (patch) => {
    set((s) => {
      if (!s.editor) return
      s.editor.draft = { ...s.editor.draft, ...patch }
      s.editor.dirty = true
      s.editor.error = null
    })
  },

  closeEditor: (force = false) => {
    if (!force && get().editor?.dirty) return // 有未保存改动，交由界面层弹确认
    set((s) => {
      s.editor = null
    })
  },

  /** 预览模式下不落数据：保存即关闭。持久化逻辑待重新设计后在此接回。 */
  saveEditor: () => {
    set((s) => {
      s.editor = null
    })
  },

  askConfirm: (c) => {
    set((s) => {
      s.confirm = c
    })
  },

  closeConfirm: () => {
    set((s) => {
      s.confirm = null
    })
  },

  /** 预览模式下不落数据：确认即关闭。 */
  runConfirm: () => {
    set((s) => {
      s.confirm = null
    })
  },

  /** 允许平行边之后，这颗按钮是「新建」还是「选一条断开」由 directLinks 决定。 */
  toggleStartEndLink: () => {
    const { startId, endId, path } = get()
    if (!startId || !endId) return
    if (startId === endId) {
      get().notify({ type: 'error', key: 'link.sameNode' })
      return
    }
    if (path?.directLinks.length) return // 已有关系，由界面弹出列表让用户选断哪条

    set((s) => {
      s.editor = {
        kind: 'link',
        id: null,
        side: 'L',
        draft: { label: '' },
        dirty: false,
        error: null,
        endpoints: { source: startId, target: endId },
      }
    })
  },
})

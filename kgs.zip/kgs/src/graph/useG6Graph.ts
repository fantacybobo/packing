import { useEffect, useRef, useState } from 'react'
import type { GraphPayload } from '@/api/types'
import { ACCENT, type Side } from '@/theme/antdTheme'
import { buildGraphOptions, SIMPLIFY_THRESHOLD, toG6Data, type G6Data } from './graphOptions'
import { findRewiredEdgeIds } from './edgeRemount'
import type { Selection } from '@/stores/slices/selection'

/** 单击与双击去重窗口。双击会先触发一次 click，那是一次白发的网络请求。 */
const DBLCLICK_GUARD_MS = 250

/** 缩放下限。低于这个比例卡片上的字就读不了了。 */
const MIN_ZOOM = 0.5

/**
 * 图实例挂在容器 DOM 上的属性名。连线画在 canvas 里、DOM 中看不到，
 * 浏览器控制台调试和 e2e 断言图内部状态都只能从这里拿实例。
 */
type GraphHost = HTMLDivElement & { __g6?: GraphLike | null }

export interface G6Handlers {
  onNodeClick: (id: string) => void
  onNodeDblClick: (id: string) => void
  onNodeContextMenu: (id: string) => void
  onEdgeClick: (id: string) => void
  onEdgeContextMenu: (id: string) => void
  onCanvasClick: () => void
}

interface GraphLike {
  setData: (d: unknown) => void
  removeEdgeData: (ids: string[]) => void
  render: () => Promise<unknown>
  destroy: () => void
  fitView: (options?: { when?: 'overflow' | 'always' }, animation?: false) => Promise<unknown>
  getZoom: () => number
  zoomTo: (zoom: number, animation?: false) => Promise<unknown>
  focusElement: (id: string, animation?: false) => Promise<unknown>
  setElementState: (state: Record<string, string[]>) => void | Promise<unknown>
  on: (event: string, cb: (e: { target?: { id?: string } }) => void) => void
}

interface Options {
  payload: GraphPayload | null
  side: Side
  selection: Selection | null
  handlers: G6Handlers
}

export function useG6Graph({ payload, side, selection, handlers }: Options) {
  const containerRef = useRef<HTMLDivElement>(null)
  const graphRef = useRef<GraphLike | null>(null)
  const clickTimer = useRef<number>(undefined)
  // G6 是动态 import 的，实例就绪晚于挂载；就绪翻成 state，
  // 让数据 effect 能在「payload 先到、实例后到」时补跑一次，否则图会永久空白。
  const [graphReady, setGraphReady] = useState(false)
  // handlers 每次渲染都是新对象，用 ref 存住，避免重建图实例。
  // 赋值放在 effect 里：渲染期写 ref 会触发级联渲染告警，而事件回调
  // 只可能在挂载之后触发，那时 effect 已经跑过了。
  const handlersRef = useRef(handlers)
  useEffect(() => {
    handlersRef.current = handlers
  }, [handlers])

  // 上一次喂给 G6 的数据，用来判断哪些边换了端点
  const prevDataRef = useRef<G6Data | null>(null)

  const simplified = (payload?.nodes.length ?? 0) > SIMPLIFY_THRESHOLD

  // 节点类型无法热切换，只有跨越简化阈值时才重建实例
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    let disposed = false
    let graph: GraphLike | null = null

    void (async () => {
      const { Graph } = await import('@antv/g6')
      if (disposed) return

      graph = new Graph({
        container: el,
        ...buildGraphOptions({ side, simplified }),
      } as never) as unknown as GraphLike
      graphRef.current = graph
      ;(el as GraphHost).__g6 = graph
      setGraphReady(true)

      graph.on('edge:click', (e) => {
        const id = e.target?.id
        if (id) handlersRef.current.onEdgeClick(id)
      })
      graph.on('edge:contextmenu', (e) => {
        const id = e.target?.id
        if (id) handlersRef.current.onEdgeContextMenu(id)
      })
      graph.on('canvas:click', () => handlersRef.current.onCanvasClick())
    })()

    // HTML 节点是真实 DOM，用事件委托而不是 G6 的节点事件
    const resolve = (ev: Event) =>
      (ev.target as HTMLElement | null)?.closest?.('[data-node-id]') as HTMLElement | null

    const onClick = (ev: MouseEvent) => {
      const hit = resolve(ev)
      if (!hit) return
      const id = hit.dataset.nodeId!
      window.clearTimeout(clickTimer.current)
      clickTimer.current = window.setTimeout(
        () => handlersRef.current.onNodeClick(id),
        DBLCLICK_GUARD_MS,
      )
    }

    const onDblClick = (ev: MouseEvent) => {
      const hit = resolve(ev)
      if (!hit) return
      window.clearTimeout(clickTimer.current)
      handlersRef.current.onNodeDblClick(hit.dataset.nodeId!)
    }

    const onContextMenu = (ev: MouseEvent) => {
      // 整个图区域内一律屏蔽浏览器右键菜单：右键在这里的语义是「打开编辑弹窗」，
      // 无论点中的是节点、连线还是空白画布。图区域之外的右键行为不受影响。
      ev.preventDefault()

      const hit = resolve(ev)
      if (!hit) return // 连线由 G6 的 edge:contextmenu 处理，空白处只需屏蔽菜单
      ev.stopPropagation()
      handlersRef.current.onNodeContextMenu(hit.dataset.nodeId!)
    }

    // 中键是拖拽键，必须挡掉浏览器的默认行为：
    // Windows / Linux 的 Chrome 会进入自动滚动模式，X11 下还会粘贴主选区。
    const onMiddleDown = (ev: MouseEvent) => {
      if (ev.button === 1) ev.preventDefault()
    }
    const onAuxClick = (ev: MouseEvent) => {
      if (ev.button === 1) ev.preventDefault()
    }

    el.addEventListener('click', onClick)
    el.addEventListener('dblclick', onDblClick)
    el.addEventListener('contextmenu', onContextMenu)
    el.addEventListener('mousedown', onMiddleDown)
    el.addEventListener('auxclick', onAuxClick)

    return () => {
      disposed = true
      window.clearTimeout(clickTimer.current)
      el.removeEventListener('click', onClick)
      el.removeEventListener('dblclick', onDblClick)
      el.removeEventListener('contextmenu', onContextMenu)
      el.removeEventListener('mousedown', onMiddleDown)
      el.removeEventListener('auxclick', onAuxClick)
      try {
        graph?.destroy()
      } catch {
        // 实例可能尚未初始化完成
      }
      graphRef.current = null
      ;(el as GraphHost).__g6 = null
      setGraphReady(false)
      // 实例没了，上一帧的数据快照也随之作废
      prevDataRef.current = null
    }
  }, [side, simplified])

  // 数据变化走差量更新，不销毁重建 —— 否则每次编辑后 d3-force 都会重新散开，
  // 用户会丢失对图的心智位置。
  useEffect(() => {
    const graph = graphRef.current
    if (!graphReady || !graph || !payload) return
    let cancelled = false

    void (async () => {
      const data = toG6Data(payload)
      // 换了端点的边先删掉，让 setData 把它当新边加回来 —— 就地更新会让
      // graphlib 的端点索引漏掉一端，详见 edgeRemount.ts
      const rewired = findRewiredEdgeIds(prevDataRef.current, data)
      if (rewired.length) {
        try {
          graph.removeEdgeData(rewired)
        } catch {
          // 实例状态与快照不一致时直接跳过，setData 仍会把数据补齐
        }
      }
      prevDataRef.current = data

      graph.setData(data)
      await graph.render()
      if (cancelled) return
      try {
        // 只在内容溢出时缩放，避免两三个节点时被放得过大
        await graph.fitView({ when: 'overflow' }, false)
        // 节点多时 fitView 会把字缩到看不清；触底后改为聚焦中心节点，
        // 其余部分交给用户平移，总比全都看不清强。
        if (graph.getZoom() < MIN_ZOOM) {
          await graph.zoomTo(MIN_ZOOM, false)
          const center = payload.meta.centerId
          if (center) await graph.focusElement(center, false)
        }
      } catch {
        // 布局尚未就绪时忽略
      }
    })()

    return () => {
      cancelled = true
    }
  }, [payload, graphReady])

  // 选中态：节点卡片直接改样式，边走 G6 的 state
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const accent = ACCENT[side]

    el.querySelectorAll<HTMLElement>('[data-node-id]').forEach((card) => {
      const isSelected =
        selection?.kind === 'node' && selection.side === side && selection.id === card.dataset.nodeId
      const isCenter = card.dataset.center === '1'
      if (isSelected) {
        card.style.borderColor = '#f59e0b'
        card.style.boxShadow = '0 0 0 2px #f59e0b,0 0 24px #f59e0b33'
      } else {
        card.style.borderColor = isCenter ? accent : '#2b3543'
        card.style.boxShadow = isCenter
          ? `0 0 0 2px ${accent},0 0 26px ${accent}40`
          : '0 2px 10px #00000066'
      }
    })

    const graph = graphRef.current
    if (!graph || !payload) return
    const states: Record<string, string[]> = {}
    payload.edges.forEach((e) => {
      states[e.id] = []
    })
    if (selection?.kind === 'edge' && selection.side === side) states[selection.id] = ['selected']
    // 图尚未渲染完成时这里会失败，同步与异步两条路径都要接住
    try {
      void Promise.resolve(graph.setElementState(states)).catch(() => {})
    } catch {
      /* 实例已销毁 */
    }
  }, [selection, side, payload])

  return { containerRef, simplified }
}

import { http } from './client'
import type { LinkDetail } from './types'

export const getLink = (id: string, signal?: AbortSignal) =>
  http.get<LinkDetail>(`/links/${id}`, { signal }).then((r) => r.data)

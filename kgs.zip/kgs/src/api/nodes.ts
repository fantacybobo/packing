import { http } from './client'
import type { LinkDetail, TreeResponse } from './types'

export const getNodeTree = (params: { q: string; limit?: number }, signal?: AbortSignal) =>
  http.get<TreeResponse>('/nodes/tree', { params, signal }).then((r) => r.data)

export const getNodeLinks = (id: string, signal?: AbortSignal) =>
  http.get<LinkDetail[]>(`/nodes/${id}/links`, { signal }).then((r) => r.data)

# 全局状态设计与迁移梳理

> 基于 `src/stores/` 下 5 个 slice + `urlSync.ts` 的完整梳理。
>
> **当前为预览模式**：node/edge 的增删改查数据逻辑（含前端请求）已剔除，
> 项目仅保留查询、预览与交互。编辑弹窗组件保留为纯 UI —— 保存/确认只关闭弹窗，
> 不落数据。编辑数据的持久化待重新设计后接回（mock 层写接口仍保留，可参考）。

---

## 一、状态树总览

```
KgState
├── GraphSlice
│   ├── startId: string | null          // 左图中心节点 ID
│   ├── endId: string | null            // 右图中心节点 ID
│   ├── hops: number                    // 跳数（默认 2）
│   ├── leftSub: GraphPayload | null    // 左图 neighborhood 数据
│   ├── rightSub: GraphPayload | null   // 右图 neighborhood 数据
│   ├── path: PathResponse | null       // 两节点间路径
│   ├── stats: Stats | null             // 全局统计
│   ├── loading: { L: boolean; R: boolean; path: boolean }
│   └── error: { L: string | null; R: string | null }
│
├── PickerSlice
│   ├── qStart: string                  // 左搜索框文本
│   ├── qEnd: string                    // 右搜索框文本
│   ├── openSide: Side | null           // 当前展开的下拉树属于哪一侧
│   ├── treeL: TreeNode[]               // 左下拉树数据
│   ├── treeR: TreeNode[]               // 右下拉树数据
│   ├── hlId: string | null             // 下拉树中高亮的叶子节点 ID
│   ├── hint: string                    // 搜索无结果提示
│   └── loadingTree: boolean            // 下拉树加载中
│
├── SelectionSlice
│   ├── sel: Selection | null           // { side, kind: 'node'|'edge', id }
│   ├── links: LinkDetail[]             // 下方关系列表
│   └── loadingLinks: boolean           // 关系列表加载中
│
├── EditorSlice（纯 UI，无数据请求）
│   ├── editor: EditorState | null      // 节点/边编辑弹窗状态
│   └── confirm: ConfirmState | null    // 确认对话框状态
│
└── UiSlice
    ├── blocking: boolean               // 全局阻塞蒙层（预览模式下恒为 false）
    └── notice: Notice | null           // 全局通知（Toast）
```

### URL 同步字段（双向绑定）

`startId` / `endId` / `hops` 这三个字段与 URL query 保持同步：
- 挂载时从 URL 读取初值
- 后续任何修改通过 `replaceState` 回写 URL

---

## 二、按场景分类的状态迁移

### 2.1 页面初始化（挂载）

**触发**：`useUrlSync` 首次 effect

**迁移**：
```
URL query ──→ startId / endId / hops（若有值）
   ↓
loadSide('L') ──→ loading.L = true ──→ API /graph/neighborhood ──→ leftSub / error.L / loading.L = false
loadSide('R') ──→ loading.R = true ──→ API /graph/neighborhood ──→ rightSub / error.R / loading.R = false
loadPath()    ──→ loading.path = true ──→ API /graph/path ──→ path / loading.path = false
loadStats()   ──→ stats
```

**附带回填**：`loadSide` 成功后，若对应搜索框为空，自动用中心节点的 `label` 回填 `qStart` / `qEnd`。

---

### 2.2 更换中心节点（下拉树点选 / Search 按钮）

**触发**：`pickNode(side, id)` 或 `runSearch(side, query)`

**迁移**：
```
openSide = null, hlId = null, hint = ''
   ↓
setCenter(side, id)
   ├── startId/endId = id
   ├── loadSide(side) ──→ leftSub/rightSub 更新
   └── loadPath() ──→ path 更新
   ↓
从子图中取新中心的 label 回填 qStart/qEnd
```

---

### 2.3 调整跳数

**触发**：`setHops(n)`

**迁移**：
```
hops = max(1, floor(n))
   ↓
并行触发 loadSide('L') + loadSide('R')
   ↓
leftSub / rightSub / error 更新
URL 自动回写 hops
```

---

### 2.4 图中节点交互

#### 单击节点

**触发**：`onNodeClick` → `selectNode(side, id)`

**迁移**：
```
sel = { side, kind: 'node', id }
   ↓
reloadLinks() ──→ API /nodes/:id/links ──→ links / loadingLinks
```

#### 双击节点

**触发**：`onNodeDblClick` → `focusNode(side, id)`

**迁移**：
```
并行：
  ├── setCenter(side, id) ──→ 子图 + 路径更新
  └── selectNode(side, id) ──→ 关系列表更新
```

#### 右键节点

**触发**：`onNodeContextMenu` → `selectNode` + `openNodeEditor(id, side)`

**迁移**：
```
sel = { side, kind: 'node', id }
links 更新
   ↓
editor = {
  kind: 'node', id, side,
  draft: { label, type, domain, desc }（从子图节点中取现有值）
  dirty: false, error: null
}
```

> 预览模式：弹窗可编辑草稿，点保存仅关闭弹窗，不发请求、不改图。

---

### 2.5 图中边交互

#### 单击边

**触发**：`onEdgeClick` → `selectEdge(side, id)`

**迁移**：
```
sel = { side, kind: 'edge', id }
   ↓
reloadLinks() ──→ API /links/:id ──→ links = [单条边详情] / loadingLinks
```

#### 右键边

**触发**：`onEdgeContextMenu` → `selectEdge` + `openLinkEditor(id)`

**迁移**：
```
sel = { side, kind: 'edge', id }
links 更新
   ↓
editor = {
  kind: 'link', id, side,
  draft: { label: link.label }
  dirty: false, error: null
}
```

---

### 2.6 画布点击

**触发**：`onCanvasClick`

**迁移**：
```
sel = null
links = []
```

---

### 2.7 搜索框输入

**触发**：`setQuery(side, q)`

**迁移**：
```
qStart/qEnd = q
openSide = side
hint = ''
hlId = null
   ↓
loadTree(side) ──→ API /nodes/tree ──→ treeL/treeR / loadingTree
```

---

### 2.8 编辑弹窗与确认框（纯 UI 交互）

> 数据层已摘除：以下流程只改变弹窗自身状态，不发请求、不刷新图。

#### 打开编辑弹窗

- 面板 "+" → `openNodeEditor(null, side)`：空白节点草稿
- 右键节点/边 → `openNodeEditor(id, side)` / `openLinkEditor(id)`：预填草稿
- 起点-终点连接按钮 → `toggleStartEndLink()`：两端不同且无直连时，打开带 `endpoints` 的空白关系草稿；两端相同则 `notify('link.sameNode')`

#### 编辑草稿

`setDraft(patch)`：合并进 `editor.draft`，置 `dirty = true`，清 `error`。

#### 关闭

- `closeEditor()`：`dirty` 时拒绝（界面层弹「放弃改动」确认）；`closeEditor(true)` 强制关闭
- `saveEditor()`：**仅关闭弹窗**（`editor = null`），不落数据
- `runConfirm()`：**仅关闭确认框**（`confirm = null`），不落数据

---

### 2.9 下拉树键盘导航

**触发**：`moveHighlight(side, direction)`

**迁移**：
```
openSide = side
hlId = 下一个/上一个叶子节点的 nodeId（循环）
```

---

## 三、关键设计决策

| 决策 | 说明 |
|---|---|
| **预览模式无写路径** | 编辑弹窗/确认框全部保留，但保存与确认仅关闭弹窗。store 不再 import 任何写 API，前端 api 层只保留读接口（tree / links / neighborhood / path / stats）。 |
| **过期请求丢弃** | `loadSide` / `loadTree` / `reloadLinks` / `loadPath` 都使用 `requestSeq` 机制，非最新 ticket 的响应直接丢弃，避免竞态。 |
| **URL 即状态** | `startId` / `endId` / `hops` 与 URL query 双向同步，刷新页面不丢上下文。 |
| **选中态与关系列表绑定** | `selectNode` / `selectEdge` 都会触发 `reloadLinks()`；`sel` 变化时图上的高亮样式同步更新。 |
| **编辑数据层待重新设计** | mock 层（msw handlers + 内存 db）仍保留完整写接口与约束（UNIQUE / 自环 / 级联删除），可作为重新设计时的参照。 |

---

## 四、状态影响面速查

| 状态字段 | 影响哪些 UI |
|---|---|
| `startId` / `endId` | 两侧图的数据源、URL、搜索框回填 |
| `leftSub` / `rightSub` | `GraphPanel` 的图渲染、`TruncationNotice` |
| `path` | `PathStatus` 组件、`LinkToggle` 的直连列表 |
| `stats` | 概览页或统计展示（当前未在 Studio 页直接展示） |
| `sel` | 图上节点/边高亮、`RelationList` 的标题 |
| `links` | `RelationList` 的内容 |
| `editor` | `NodeEditModal` / `LinkEditModal` 的显隐与内容 |
| `confirm` | `ConfirmDialog` 的显隐与类型 |
| `blocking` | `BlockingOverlay` 蒙层（预览模式下不触发） |
| `notice` | `useNoticeBridge` → AntD Message |
| `qStart` / `qEnd` | `NodePicker` 输入框 |
| `treeL` / `treeR` | `NodePicker` 下拉树 |
| `openSide` / `hlId` | `NodePicker` 下拉树展开态与高亮项 |

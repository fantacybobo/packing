# Graph 渲染组件与 Neighborhood 接口字段绑定梳理

> 目标：搞清楚 `GraphPayload`（`/graph/neighborhood` 返回）里的每个字段被渲染层用到了什么程度，方便后续改字段名或裁剪字段。

---

## 一、渲染入口：`useG6Graph` 的参数

```ts
interface Options {
  payload: GraphPayload | null   // ← 来自 neighborhood 接口
  side: Side                     // 'L' | 'R'，决定主题色（accent）
  selection: Selection | null    // 当前选中态（节点/边/id）
  handlers: G6Handlers           // 点击/双击/右键回调
}
```

**关键结论**：`payload` 是唯一来自接口的数据源；其余三个参数全是 UI 状态/回调，与接口字段无关。

---

## 二、`GraphPayload` → G6 的转换链路

### 2.1 整体转换函数

```ts
// graphOptions.ts → toG6Data(payload)
function toG6Data(payload: GraphPayload): G6Data {
  return {
    nodes: payload.nodes.map((n) => ({
      id: n.id,
      data: { ...n, center: n.id === payload.meta.centerId },
    })),
    edges: payload.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      data: { label: e.label },
    })),
  }
}
```

### 2.2 字段绑定矩阵

#### Nodes（`payload.nodes: KgNode[]`）

| 字段 | 被谁消费 | 作用 | 是否必须 |
|---|---|---|---|
| `id` | `toG6Data` → G6NodeDatum.id | G6 内部索引、事件命中 | **是** |
| `id` | `buildNodeCard` → `data-node-id` | DOM 属性，用于事件委托、选中态匹配 | **是** |
| `label` | `buildNodeCard` → 卡片标题 | 展示 | **是** |
| `label` | `graphOptions.ts` → 简化模式标签 | `simplified` 为 true 时圆点下方文字 | **是**（简化模式依赖） |
| `type` | `buildNodeCard` → Type 行 | 展示 | 否（空值显示为 `—`） |
| `domain` | — | 当前渲染层未使用 | **否** |
| `desc` | `buildNodeCard` → Desc 行 | 展示 | 否（空值显示为 `—`） |
| `degree` | — | 当前渲染层未使用 | **否** |
| `props` | — | 当前渲染层未使用 | **否** |

> **注**：`center` 不是接口字段，是 `toG6Data` 内部通过 `n.id === payload.meta.centerId` 计算出的派生标记，随后作为 `data.center` 注入 G6。

#### Meta（`payload.meta: GraphMeta`）

| 字段 | 被谁消费 | 作用 | 是否必须 |
|---|---|---|---|
| `centerId` | `toG6Data` | 计算每个 node 的 `center` 布尔标记 | **是** |
| `centerId` | `useG6Graph` → `focusElement` | 缩放触底后聚焦中心节点 | **是** |
| `truncated` | `TruncationNotice` | 展示截断提示条 | 否 |
| `nodeCap` | `TruncationNotice` | 提示条里写「上限」数字 | 否 |
| `totalNodes` | `TruncationNotice` | 提示条里写「实际总数」数字 | 否 |
| `hops` | — | 当前渲染层未使用（UI 的 hops 存在 store 里） | **否** |

#### Edges（`payload.edges: KgEdge[]`）

| 字段 | 被谁消费 | 作用 | 是否必须 |
|---|---|---|---|
| `id` | `toG6Data` → G6EdgeDatum.id | G6 内部索引、事件命中、选中态匹配 | **是** |
| `source` | `toG6Data` → G6EdgeDatum.source | G6 画线起点 | **是** |
| `target` | `toG6Data` → G6EdgeDatum.target | G6 画线终点 | **是** |
| `label` | `toG6Data` → edge.data.label | 边标签文字 | 否（空值不显示） |
| `predicate` | — | 当前渲染层未使用 | **否** |
| `directed` | — | 当前渲染层未使用（代码里 `endArrow: true` 是全局写死的） | **否** |
| `props` | — | 当前渲染层未使用 | **否** |

---

## 三、渲染层对字段的依赖深度

### 3.1 结构层（G6 必需）

以下字段改名**必须同步改代码**，否则图渲染直接失败：

- `nodes[].id`
- `edges[].id`
- `edges[].source`
- `edges[].target`
- `meta.centerId`（也用于聚焦）

### 3.2 展示层（卡片/标签）

以下字段改名只需改一处消费代码，不影响图的结构：

- `nodes[].label` → `graphOptions.ts`（简化模式） + `nodeCard.ts`（卡片标题）
- `nodes[].type` → `nodeCard.ts`
- `nodes[].desc` → `nodeCard.ts`
- `edges[].label` → `graphOptions.ts`

### 3.3 当前完全未被渲染层消费

以下字段即使改名/删除，**只要保证接口仍返回合法 JSON**，渲染层无感知：

- `nodes[].domain`
- `nodes[].degree`
- `nodes[].props`
- `edges[].predicate`
- `edges[].directed`
- `edges[].props`
- `meta.hops`
- `meta.nodeCap`
- `meta.totalNodes`
- `meta.truncated`

> 但注意：`meta.nodeCap` / `meta.totalNodes` / `meta.truncated` 虽不影响图本身，却被 `TruncationNotice` 组件用于展示「显示 200 / 共 1,243」提示条。

---

## 四、关键派生逻辑一览

| 派生值 | 计算位置 | 公式 |
|---|---|---|
| `simplified` | `useG6Graph` | `payload.nodes.length > SIMPLIFY_THRESHOLD(120)` |
| `center` | `toG6Data` | `node.id === payload.meta.centerId` |
| `isSelected`（节点） | `useG6Graph` effect | `selection.id === card.dataset.nodeId` |
| `isSelected`（边） | `useG6Graph` effect | `selection.id === edge.id` |
| `rewired edges` | `findRewiredEdgeIds` | 比较前后两次 `source + ' ' + target` |

---

## 五、调整字段名的影响速查

假设你要改接口返回的字段名，以下是必须同步修改的代码位置：

| 若改名 | 需改文件 | 行号区间/函数 |
|---|---|---|
| `nodes[].id` | `graphOptions.ts` | `toG6Data` |
| `nodes[].id` | `nodeCard.ts` | `buildNodeCard` 中 `data-node-id` |
| `nodes[].label` | `graphOptions.ts` | `simplified` 模式的 `labelText` |
| `nodes[].label` | `nodeCard.ts` | `buildNodeCard` 标题 |
| `nodes[].type` | `nodeCard.ts` | `buildNodeCard` Type 行 |
| `nodes[].desc` | `nodeCard.ts` | `buildNodeCard` Desc 行 |
| `edges[].id` | `graphOptions.ts` | `toG6Data` |
| `edges[].source` | `graphOptions.ts` | `toG6Data` |
| `edges[].target` | `graphOptions.ts` | `toG6Data` |
| `edges[].label` | `graphOptions.ts` | `edge.style.labelText` |
| `meta.centerId` | `graphOptions.ts` | `toG6Data` 中 `center` 计算 |
| `meta.centerId` | `useG6Graph.ts` | `focusElement(center)` |
| `meta.*`（截断相关） | `TruncationNotice.tsx` | 组件 props 解构 |

---

## 六、简化阈值与字段需求的关联

```
节点数 ≤ 120（非简化模式）
  └─ 渲染 HTML 卡片，依赖：id, label, type, desc, center

节点数 > 120（简化模式）
  └─ 渲染圆点，仅依赖：id, label
```

这意味着：如果接口返回的节点数很大，即使 `type`/`desc` 缺失，图依然能正常渲染；只有节点数少、进入卡片模式时，这两个字段的缺失才会在视觉上体现为 `—`。

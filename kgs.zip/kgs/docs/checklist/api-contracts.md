# API 接口清单

> 来源：`src/api/` 下的 client、types、graph、nodes、links 及 `src/mocks/handlers.ts`

## 通用约定

### 响应信封

所有接口返回统一信封：

```ts
interface Envelope<T> {
  code: number    // 0 为成功，非 0 为业务错误
  data: T
  message: string
}
```

HTTP 层已做 `unwrapEnvelope` 处理，调用方拿到的是 `T`；错误统一抛为 `ApiError(code, message, status?)`。

### 业务错误码

| 码 | 含义 |
|---|---|
| 401 | UNAUTHORIZED |
| 404 | NOT_FOUND |
| 409 | DUPLICATE（如重复关系） |
| 422 | SELF_LOOP（自环） |
| 500 | 内部错误 |

---

## Graph 接口

### GET `/graph/stats`

**输入**：无

**输出**：`Stats`

```ts
interface Stats {
  nodeCount: number
  linkCount: number
}
```

---

### GET `/graph/neighborhood`

**输入（Query）**：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| centerId | string | 是 | 中心节点 ID |
| hops | number | 否 | 跳数，默认 2 |
| limit | number | 否 | 节点上限，默认 200 |

**输出**：`GraphPayload`

```ts
interface GraphPayload {
  nodes: KgNode[]
  edges: KgEdge[]
  meta: GraphMeta
}

interface KgNode {
  id: string
  label: string
  type: string
  domain: string
  desc: string
  degree?: number        // 空搜索词时按度数取 Top N
  props?: Record<string, unknown>
}

interface KgEdge {
  id: string
  source: string
  target: string
  label: string          // 展示用标签
  predicate: string      // 语义标识，参与唯一约束
  directed: true
  props?: Record<string, unknown>
}

interface GraphMeta {
  centerId: string
  hops: number
  truncated: boolean     // 结果被 nodeCap 截断
  nodeCap: number
  totalNodes: number     // 未截断时的真实规模
}
```

---

### GET `/graph/path`

**输入（Query）**：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| from | string | 是 | 起点节点 ID |
| to | string | 是 | 终点节点 ID |

**输出**：`PathResponse`

```ts
interface PathResponse {
  found: boolean
  segments: PathSegment[]
  directLinks: LinkDetail[]   // 起点与终点之间已存在的全部关系
}

interface PathSegment {
  node: LinkEndpoint
  edge?: {
    id: string
    label: string
    reversed: boolean   // true 表示逆着边的方向走
  }
}

interface LinkEndpoint {
  id: string
  label: string
}
```

---

## Nodes 接口

### GET `/nodes/tree`

**输入（Query）**：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| q | string | 是 | 搜索词 |
| limit | number | 否 | 默认 50 |

**输出**：`TreeResponse`

```ts
interface TreeResponse {
  total: number
  tree: TreeNode[]
}

interface TreeNode {
  key: string
  label: string
  count?: number
  nodeId?: string        // 仅叶子节点有值
  meta?: string
  children?: TreeNode[]
}
```

---

### GET `/meta/taxonomy`

**输入**：无

**输出**：`Taxonomy`

```ts
interface Taxonomy {
  domains: string[]
  types: string[]
}
```

---

### GET `/nodes/:id/links`

**输入（Path）**：`id` — 节点 ID

**输出**：`LinkDetail[]`

```ts
interface LinkDetail {
  id: string
  source: LinkEndpoint
  target: LinkEndpoint
  label: string
  predicate: string
  directed: true
  props?: Record<string, unknown>
  createdAt: string
  updatedAt: string
}
```

---

### POST `/nodes`

**输入（Body）**：`NodeInput`

```ts
interface NodeInput {
  label: string
  type: string
  domain: string
  desc: string
}
```

**输出**：`KgNode`

---

### PATCH `/nodes/:id`

**输入**：
- Path：`id`
- Body：`Partial<NodeInput>`（可只传部分字段）

**输出**：`KgNode`

---

### DELETE `/nodes/:id`

**输入（Path）**：`id`

**输出**：`DeleteNodeResult`

```ts
interface DeleteNodeResult {
  deletedNodeId: string
  deletedLinkIds: string[]   // 连带删除的关系 ID
}
```

---

## Links 接口

### GET `/links/:id`

**输入（Path）**：`id`

**输出**：`LinkDetail`

---

### POST `/links`

**输入（Body）**：`LinkInput`

```ts
interface LinkInput {
  source: string    // 源节点 ID
  target: string    // 目标节点 ID
  label: string
  predicate?: string
}
```

**输出**：`LinkDetail`

---

### PATCH `/links/:id`

**输入**：
- Path：`id`
- Body：

```ts
{
  label?: string
  predicate?: string
}
```

**输出**：`LinkDetail`

---

### POST `/links/:id/reverse`

**输入（Path）**：`id`

**输出**：`LinkDetail`（source/target 已互换）

---

### DELETE `/links/:id`

**输入（Path）**：`id`

**输出**：`DeleteLinkResult`

```ts
interface DeleteLinkResult {
  deletedLinkId: string
}
```

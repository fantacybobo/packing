# NodePicker 下拉面板被对侧 blur 定时器误杀 —— 根因与修复记录

> 原始版本遗留 bug：左框选完节点后直接点右框，右侧下拉面板无法正常显示（闪现即消失）。
> 本文件记录根因、修复位置与回归验证，供后续改动下拉交互时参考。

---

## 一、现象

- 首次使用任一输入框：下拉树正常展示、正常点选。
- 在左框选完节点后，**直接**点击右框：右侧下拉面板只闪一下就关闭，无法正常展示。
- 若在右框打字过滤：面板在 ~200ms 时消失，又在防抖请求返回后闪回（抖动）。

## 二、根因

两个 `NodePicker` 实例共享 store 中唯一的打开态 `openSide`；同时每个实例的 `onBlur`
都会排一个 **200ms 后无条件执行 `closePicker()` 的定时器**（延迟的本意是让「点击树项」
先于 blur 生效，见组件内 `BLUR_CLOSE_MS` 注释）。

失败时序：

```
t=0      左框选完节点（面板的 onMouseDown preventDefault 使焦点仍留在左框）
t=0      用户点击右框
         ├─ 左框 onBlur：排下 t=200ms 的 closePicker()
         └─ 右框 onFocus：openPicker('R') → openSide='R'，右侧面板打开
t=200ms  左框的过期定时器触发 → openSide=null → 右侧面板被误杀
```

首次使用正常，是因为此前没有任何输入框持有焦点，不存在悬而未决的 blur 定时器。
打字场景：输入防抖 300ms > 关闭窗口 200ms，所以面板先被关掉、又被 `setQuery` 重开，表现为抖动。

## 三、修复位置

| 文件 | 改动 |
|---|---|
| `src/stores/slices/picker.ts` | `closePicker` 增加可选参数 `side`：**仅当该侧仍是当前打开侧时才真正关闭**（`if (side && s.openSide !== side) return`），否则作为过期调用落空。 |
| `src/components/node-picker/NodePicker.tsx` | blur 延迟关闭与 Escape 都改为 `closePicker(side)`，带上自己的侧标识。 |

修复后的同一时序里，左框的过期关闭到达时发现 `openSide === 'R'`，自动作废；
而「点击页面空白处关闭面板」的原有行为不受影响（那时 `openSide` 仍是自己的侧）。

## 四、回归测试与验证

新增 3 个用例：

- `src/stores/__tests__/picker.test.ts`
  - `closePicker` 带匹配的 side 时正常关闭；
  - **对侧已接管打开态时，过期 blur 关闭落空**（核心回归）。
- `src/components/node-picker/__tests__/NodePicker.test.tsx`
  - 渲染左右两个选择器，点击左框后直接点击右框，挺过 200ms 关闭窗口后断言右侧面板仍在。

反向验证：把组件临时改回旧的 `window.setTimeout(closePicker, BLUR_CLOSE_MS)` 写法，
上述组件级用例如期失败，确认复现的正是该 bug。

浏览器实测链路：左框选 Database B → 直接点右框 → 600ms 后下拉面板仍正常展示 →
输入过滤并点选 Application C → `endId` 更新、路径联动正常。

# G6 动态 import 竞态导致图永久空白 —— 根因与修复记录

> 原始版本遗留 bug：慢环境下两个图面板永久空白（无 canvas、无节点卡片），
> 但 store 数据完全正常（`leftSub` / `rightSub` / `path` 都已就位、无报错）。
> 本文件记录根因、修复位置与验证方式，供后续改动图挂载逻辑时参考。

---

## 一、现象

- 页面打开后，路径栏、搜索框回填、关系统计全部正常，唯独两个图面板空白。
- DOM 中既没有 `<canvas>` 也没有任何 `[data-node-id]` 节点卡片。
- 直接查 store：`leftSub` / `rightSub` 节点数正常、`loading` 全部归位、`error` 为空
  —— 数据链路完好，纯粹是渲染没发生。
- 慢环境必现（无头浏览器、vite 冷启动首次转换大 chunk）；e2e 的 playwright
  有 GPU 与热缓存通常能跑赢竞态，所以长期未暴露。

## 二、根因

`src/graph/useG6Graph.ts` 里 G6 是**动态 import** 的，两个 effect 之间存在时间窗：

```
挂载          payload=null → 数据 effect 提前 return（!payload）
   ↓
~120ms      MSW 响应到达 → payload 就位
            → 数据 effect 触发，但 graphRef.current 仍为 null
              （~1MB 的 G6 chunk 尚未加载完）→ 再次提前 return（!graph）
   ↓
更晚         G6 import 完成，实例创建 —— 但实例就绪走的是 ref，
            不会触发任何 effect；payload 此后没再变化
            → 数据 effect 永远不会补跑 → 图永久空白
```

核心问题：**实例就绪是不可见的**（只写 ref），「数据已到但实例未到」的中间态
没有任何机制在实例就绪后回补。

## 三、修复位置

全部在 `src/graph/useG6Graph.ts`（共 4 处、约 6 行）：

| 位置 | 改动 |
|---|---|
| 顶部 | 新增 `graphReady` **state**（不是 ref）：实例就绪要参与 effect 依赖，必须走渲染周期 |
| 挂载 effect | 实例创建完成后 `setGraphReady(true)` |
| 卸载 cleanup | `setGraphReady(false)`，与 `graphRef.current = null` 同步 |
| 数据 effect | 守卫改为 `if (!graphReady \|\| !graph \|\| !payload) return`，依赖改为 `[payload, graphReady]` |

这样「payload 先到、实例后到」时，`graphReady` 翻转会补跑一次数据 effect，
把待渲染的数据喂进去；实例先于数据就绪时行为不变。

## 四、验证

- 修复前在同一环境复现：`document.querySelectorAll('canvas').length === 0`、
  节点卡片 0 张，store 数据正常 —— 确认是渲染竞态而非数据问题。
- 修复后：16 张节点卡片渲染成功（左 7 + 右 9），后续完整交互链冒烟通过
  （单击刷新关系列表、双击换中心、右键弹编辑窗、路径栏联动）。
- 单测：`GraphPanel` 等既有用例全部通过（mock 的 G6 是同步类，`graphReady`
  翻转只多一次 effect 补跑，不改变断言结果）。
